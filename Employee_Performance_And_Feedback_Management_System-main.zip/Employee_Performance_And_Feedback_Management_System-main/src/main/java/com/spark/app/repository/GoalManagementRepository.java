package com.spark.app.repository;
 
import java.time.LocalDate;
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
 
import com.spark.app.model.GoalManagement;
 
@Repository
public interface GoalManagementRepository  extends JpaRepository<GoalManagement,Long>{
	List<GoalManagement> findByEmployeeId_EmployeeId(Long employeeId);
 
	boolean existsByEmployeeId_EmployeeIdAndGoalDescription(long employeeId, String goalDescription);
 
	List<GoalManagement> findByEmployeeIdEmployeeIdAndTargetDateBetween(long employeeId, LocalDate startDate,
			LocalDate endDate);
	
}
 
 