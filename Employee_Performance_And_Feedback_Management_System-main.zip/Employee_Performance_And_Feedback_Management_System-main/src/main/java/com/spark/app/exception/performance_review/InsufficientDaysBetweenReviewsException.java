package com.spark.app.exception.performance_review;

public class InsufficientDaysBetweenReviewsException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public InsufficientDaysBetweenReviewsException(String message) {
		super(message);
	}
}
