package com.spark.app.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spark.app.dto.FeedbackResponseDTO;
import com.spark.app.model.Feedback;

@Component
public class FeedbackDTOMapper {

    @Autowired
    private ModelMapper modelMapper;
    

    public FeedbackResponseDTO toDto(Feedback feedback) {
        return modelMapper.map(feedback, FeedbackResponseDTO.class);
    }
}
