package com.spark.app.exception.performance_review;

public class NullRequestDTOException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public NullRequestDTOException(String message) {
		super(message);
	}
}
