package com.spark.app.dto;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.spark.app.model.FeedbackCommentType;
import com.spark.app.model.FeedbackType;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FeedbackRequestDTO {

    @NotNull(message = "From Employee ID is required")
    private long fromEmployeeId;

    @NotNull(message = "To Employee ID is required")
    private long toEmployeeId;

    @NotNull(message = "Feedback type is required")
    private FeedbackType feedbackType;

    @FutureOrPresent
    @JsonFormat(pattern="dd-MM-yyyy")
    @DateTimeFormat(pattern = "dd-MM-yyyy")
    private LocalDate date;

    @NotNull(message = "Comments type is required")
    private FeedbackCommentType comments;

    private String reason;
}
