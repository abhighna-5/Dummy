package com.spark.app.exception.authentication;

public class BadCredentialsException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	/**
	 * This Exception is Raised When End User try to login with bad credentials
	 */
	
	public BadCredentialsException(String errorMessage) {
		super(errorMessage);
	}
}
