package com.spark.app.event;

import com.spark.app.model.PerformanceReview;
import org.springframework.context.ApplicationEvent;

public class PerformanceReviewEvent extends ApplicationEvent {
    private final PerformanceReview performanceReview;

    public PerformanceReviewEvent(Object source, PerformanceReview performanceReview) {
        super(source);
        this.performanceReview = performanceReview;
    }

    public PerformanceReview getPerformanceReview() {
        return performanceReview;
    }
}
