package com.spark.app.exception.employee_profile;

public class EmployeeProfileNotFoundException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public EmployeeProfileNotFoundException(String errorMessage) {
		super(errorMessage);
	}

}
