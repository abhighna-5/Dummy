package com.spark.app.dao;
 
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
 
import java.util.stream.Collectors;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import com.spark.app.dto.PerformanceReviewRequestDTO;
import com.spark.app.dto.PerformanceReviewResponseDTO;

import com.spark.app.event.PerformanceReviewEvent;

import com.spark.app.exception.performance_review.DuplicateReviewException;
import com.spark.app.exception.performance_review.IncompleteReviewException;
import com.spark.app.exception.performance_review.InsufficientDaysBetweenReviewsException;
import com.spark.app.exception.performance_review.InvalidEmployeeIdException;
import com.spark.app.exception.performance_review.InvalidManagerIdException;
import com.spark.app.exception.performance_review.NullRequestDTOException;
import com.spark.app.exception.performance_review.ReviewNotFoundException;
import com.spark.app.exception.performance_review.UnauthorizedException;
import com.spark.app.exception.performance_review.UpdateFailedException;


import com.spark.app.mapper.PerformanceReviewMapper;

import com.spark.app.model.PerformanceReview;
import com.spark.app.model.Role;
import com.spark.app.repository.EmployeeProfileRepository;
import com.spark.app.repository.PerformanceReviewRepository;

import com.spark.app.service.PerformanceReviewService;


import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class PerformanceReviewServiceImpl implements PerformanceReviewService{

 
	// Injecting the instance of PerformanceReviewRepository
	@Autowired
	private PerformanceReviewRepository performanceReviewRepository;
	// Injecting the instance of EmployeeProfileRepository
	@Autowired
	private EmployeeProfileRepository employeeProfileRepository;
	// Injecting the instance of PerformanceReviewMapper
	@Autowired
	private PerformanceReviewMapper performanceReviewMapper;

	

	@Autowired
	private ApplicationEventPublisher eventPublisher;


	// Implementing the addPerformanceReview method 
	@Override
	public PerformanceReviewResponseDTO addPerformanceReview(PerformanceReviewRequestDTO performanceReviewRequestDTO) {
		
		
		/**
		 * Adding performance review for a employee
		 */

		// Checking whether requestDTO is null
		if(performanceReviewRequestDTO == null) {
			throw new NullRequestDTOException("RequestDTO is null");
		}
		long employeeId = performanceReviewRequestDTO.getEmployeeId();
		long managerId = performanceReviewRequestDTO.getManagerId();
		LocalDate date = performanceReviewRequestDTO.getDate();
		// Checking whether the employee id is valid
		if(employeeProfileRepository.findById(employeeId).isEmpty()) {
			throw new InvalidEmployeeIdException("Provide valid Employee ID.");
		}
		// Checking whether the manager id is valid
		if(employeeProfileRepository.findById(managerId).isEmpty()) {
			throw new InvalidManagerIdException("Provide valid Manager ID.");
		}
		// Checking whether the manager has the correct role
		if(employeeProfileRepository.findById(managerId).get().getRole() != Role.PROJECT_MANAGER) {
			throw new UnauthorizedException("Only Manager can schedule reviews");
		}
		// Checking whether manager scheduling review for himself
		if(managerId == employeeId) {
			throw new UnauthorizedException("Manager cannot be able to schedule reviews for himself");
		}
		// Checking for a duplicate review
		boolean reviewExists = performanceReviewRepository.existsByEmployeeIdEmployeeIdAndManagerIdEmployeeIdAndDate(
				employeeId, 
				managerId, 
				date);
	    if (reviewExists) {
	        throw new DuplicateReviewException("A review for this employee, manager, and date already exists.");
	    }

	    // Checking for incomplete reviews and sufficient days between reviews
	    LocalDate recentReviewDate = performanceReviewRepository.recentReview(employeeId);
		if(recentReviewDate != null) {
			String recentReviewFeedback = performanceReviewRepository.recentFeedback(employeeId, recentReviewDate);
			if(recentReviewFeedback == null) {
				throw new IncompleteReviewException("New review will be created only after the completion of existing review.");
			}
		    long daysBetween = Math.abs(ChronoUnit.DAYS.between(recentReviewDate, date));
		    if(daysBetween <= 10) {
		    	throw new InsufficientDaysBetweenReviewsException("Only " + daysBetween + " days between reviews. A minimum of 10 days is required.");
		    }
	    }
		// Mapping the request DTO to the entity and saving it
		PerformanceReview performanceReview = performanceReviewMapper.toEntity(performanceReviewRequestDTO);
		performanceReview = performanceReviewRepository.save(performanceReview);

		log.info("Review for employee {} is successfully saved.",employeeId);
		
		// Returning the saved review as a response DTO
		return performanceReviewMapper.toDto(performanceReview);
	}
 
	// Implementing the viewReviewsEmployee method
	@Override
	public List<PerformanceReviewResponseDTO> viewReviewsEmployee(long employeeId) {
		
		/**
		 * Listing all the reviews of a specific employee
		 */
		
		// Checking whether the employee id is valid
		if(employeeProfileRepository.findById(employeeId).isEmpty()) {
			throw new InvalidEmployeeIdException("Provide valid Employee ID.");
		}

		// Fetching the list of performance reviews for the given employee id
		List<PerformanceReviewResponseDTO> reviewList = performanceReviewRepository.findByEmployeeIdEmployeeId(employeeId)
												.stream()
												.map(review -> performanceReviewMapper.toDto(review))
												.collect(Collectors.toList());

		
		log.info("Fetched {} reviews of employee {}",reviewList.size(),employeeId);

		// Returning the list of performance review response DTOs
		return reviewList;
	}	
	
	// Implementing the viewReviewsManager method
	@Override
	public List<PerformanceReviewResponseDTO> viewReviewsManager(long managerId) {
		
		/**
		 * Listing all the reviews scheduled by manager
		 */
		
		// Checking whether the manager id is valid
		if(employeeProfileRepository.findById(managerId).isEmpty()) {
			throw new InvalidManagerIdException("Provide valid Manager ID.");
		}
		
		// Checking whether the manager has the correct role
		if(employeeProfileRepository.findById(managerId).get().getRole() != Role.PROJECT_MANAGER) {
			throw new UnauthorizedException("Only Manager can view all scheduled reviews");
		}
		
		// Fetching the list of performance reviews scheduled by the given employee id
		List<PerformanceReviewResponseDTO> reviewList = performanceReviewRepository.findByManagerIdEmployeeId(managerId)
												.stream()
												.map(review -> performanceReviewMapper.toDto(review))
												.collect(Collectors.toList());
		
		log.info("Fetched {} reviews scheduled by manager {}",managerId);
		// Returning the list of performance review response DTOs
		return reviewList;
	}
 
	// Implementing the deleteReview method
	@Override
	public void deleteReview(long reviewId, long managerId) {
		
		/**
		 * Deleting a specific review
		 */
		
		// Checking whether the review exists for this review id
		PerformanceReview review = performanceReviewRepository.findById(reviewId).
							orElseThrow(()-> new ReviewNotFoundException("Review with ID " + reviewId + " not found"));
		
		// Checking whether the manager id matches the manager id associated with the review
		if(review.getManagerId().getEmployeeId() != managerId) {
			throw new UnauthorizedException("Manager ID is not matched.");
		}
		
		// Deleting the review from the repository
		performanceReviewRepository.delete(review);
		log.info("Review {} is successfully deleted",reviewId);
		
	}
 
	// Implementing the updateReview method
	@Override
	public PerformanceReviewResponseDTO updateReview(long reviewId, long managerId, LocalDate date) {
		
		/**
		 * Changing the date of a review
		 */
		
		// Checking whether the review exists for this review id
		PerformanceReview review = performanceReviewRepository.findById(reviewId).
				orElseThrow(()-> new ReviewNotFoundException("Review with ID " + reviewId + " not found"));
		
		// Checking whether the manager id matches the manager id associated with the review
		if(review.getManagerId().getEmployeeId() != managerId) {
			throw new UnauthorizedException("Manager ID is not matched.");
		}
		
		// Checking whether the review is already completed
		if(review.getFeedback() != null || review.getPerformanceScore() != 0) {
			throw new UpdateFailedException("Cannot able to update date for completed reviews");
		}
		
		
		// Checking whether the new date and old date is same
		LocalDate oldDate = review.getDate();
		
		if(oldDate.isEqual(date)) {
			throw new UpdateFailedException("Cannot able to update because new date and old date are not different.");
		}
		
		// Checking for sufficient days between reviews
		LocalDate recentReviewDate = performanceReviewRepository.recentCompletedReview(review.getEmployeeId().getEmployeeId());
	    
		if(recentReviewDate != null) {
			
		    long daysBetween = Math.abs(ChronoUnit.DAYS.between(recentReviewDate, date));
		    if(daysBetween <= 10) {
		    	throw new InsufficientDaysBetweenReviewsException("Only " + daysBetween + " days between reviews. A minimum of 10 days is required.");
		    }
		    
	    }


		// Updating the review date and saving the updated review
		review.setDate(date);
	    performanceReviewRepository.save(review);
	    log.info("Review date of review {} is successfully changed and saved",reviewId);	
	    

	    // Returning the updated review as a response DTO
		return performanceReviewMapper.toDto(review);
	}
 
	// Implementing the providePerformanceScoreAndFeedback method
	@Override
	public PerformanceReviewResponseDTO providePerformanceScoreAndFeedback(long reviewId, long managerId, float productivity, float teamwork,
			float skillProficiency, String feedback) {
		
		/**
		 * Updating the PerformanceScore and Feedback of the review
		 */
		
		// Checking whether the review exists for this review id
		PerformanceReview review = performanceReviewRepository.findById(reviewId).
				orElseThrow(()-> new ReviewNotFoundException("Review with ID " + reviewId + " not found"));
		
		// Checking whether the manager id matches the manager id associated with the review
		if(review.getManagerId().getEmployeeId() != managerId) {
			throw new UnauthorizedException("Manager ID is not matched.");
		}
		
		// Checking whether the current date is before the review date
		LocalDate reviewDate = review.getDate();
		LocalDate currDate = LocalDate.now();
		
		if(currDate.isBefore(reviewDate)) {
			throw new IncompleteReviewException("Feedback and PerformanceScore can be updated only after the completion of review");
		}
		
		// Checking whether the feedback and performance score have already been provided
		if(review.getFeedback() != null || review.getPerformanceScore() != 0) {
			throw new UpdateFailedException("Cannot able to update after receiving score and feedback");
		}
		
		// Calculating the performance score
		float performanceScore = (productivity + teamwork + skillProficiency) / 3;
		
 
		// Setting the performance score and feedback, and saving the updated review
		review.setPerformanceScore(performanceScore);
		review.setFeedback(feedback);
		performanceReviewRepository.save(review);
		log.info("PerformanceScore and Feedback of review {} is successfully added and saved",reviewId);
		
		eventPublisher.publishEvent(new PerformanceReviewEvent(this,review));
		
		// Returning the updated review as a response DTO
		return performanceReviewMapper.toDto(review);
	}
 
}
 
 