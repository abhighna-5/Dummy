package com.spark.app.model;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class GoalManagement {
	
	@Id
	@GeneratedValue
	private long goalId;
	private String goalDescription;
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private LocalDate targetDate;
	private ProgressStatus progressStatus=ProgressStatus.NOT_STARTED;
	@ManyToOne
	@JoinColumn(name="employee_id")
	private EmployeeProfile employeeId;
}
