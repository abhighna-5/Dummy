package com.spark.app.model;

import java.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Feedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feedbackId; 

    @ManyToOne //Many Feedbacks One Employee
    @JoinColumn(name = "from_employee_id", nullable = false)
    private EmployeeProfile fromEmployee;

    @ManyToOne
    @JoinColumn(name = "to_employee_id", nullable = false)
    private EmployeeProfile toEmployee;

    @Enumerated(EnumType.STRING) // Store as a string in the database
    private FeedbackType feedbackType; 

    @DateTimeFormat(pattern = "dd-MM-yyyy")
    private LocalDate date = LocalDate.now();

    @Enumerated(EnumType.STRING) // Store as a string in the database
    private FeedbackCommentType comments;
    
    @Column(nullable=true)
    private String reason;
    
    public Feedback() {
        this.date = LocalDate.now();  // ✅ Assign when instantiated
    }
}
