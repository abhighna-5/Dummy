package com.spark.app.security;

import java.util.List;
import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.spark.app.exception.authentication.EndUserAlreadyExistException;
import com.spark.app.exception.authentication.EndUserDoesNotExistException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EndUserService {
	/**
	 * Contains Service Methods for End User Entity
	 */
	private EndUserRepository endUserRepository;

	private PasswordEncoder encoder;
	
	public EndUserService(EndUserRepository endUserRepository, PasswordEncoder encoder) {
		this.endUserRepository = endUserRepository;
		this.encoder= encoder; 
	}
	public EndUser registerEndUser(EndUser endUser) {
		/**
		 * Register a New End User
		 * @param endUser - Object of End User containing details of new End User
		 * @return EndUser
		 */
		
		// Check if User already exists
		Optional<EndUser> container = endUserRepository.findById(endUser.getEmailAddress());
		if(container.isPresent()) throw new EndUserAlreadyExistException("End User already exists");
		
		// User do not Exist
		//Encode the Password into unreadable format
		endUser.setPassword(encoder.encode(endUser.getPassword()));
		EndUser saved = endUserRepository.save(endUser) ;
		log.info("Created End User {}",saved.getEmailAddress());
		return saved;
	}
	public Optional<EndUser> findByEmailAddress(String emailAddress) {
		/**
		 * Find End User by Email Address
		 * @param String emailAddress
		 * @return Optional<EndUser>
		 */
		Optional<EndUser> user = endUserRepository.findById(emailAddress);
		log.info("End user fetch operation is successful");
		return user;
	}
	
	public boolean activateEndUser(EndUser endUser) {
		/**
		 * Activate the end user credentials
		 * @param - End User Object
		 * @return Boolean - updated activation status
		 */
		// Valid user existence
		Optional<EndUser> container = endUserRepository.findById(endUser.getEmailAddress());
		if(container.isEmpty()) throw new EndUserDoesNotExistException("Cannot activate end user who do not exist");
		endUser.setActivated(true);
		log.info("End User {} is activated",endUser.getEmailAddress());
		return endUserRepository.save(endUser).isActivated();
	}
	
	
	public boolean deActivateEndUser(EndUser endUser) {
		/**
		 * Activate the end user credentials
		 * @param - End User Object
		 * @return Boolean - updated activation status
		 */
		// Valid user existence
		Optional<EndUser> container = endUserRepository.findById(endUser.getEmailAddress());
		if(container.isEmpty()) throw new EndUserDoesNotExistException("Cannot deactivate end user who do not exist");
		// User exists
		endUser.setActivated(false);
		log.info("End User {} is deactivated",endUser.getEmailAddress());
		return endUserRepository.save(endUser).isActivated();
	}
	
	public boolean updatePassword(EndUser endUser, String password) {
		/**
		 * Update Login Password for an End User
		 * @param EndUser and updated Password
		 * @return true if password is updated successfully
		 */
		// Valid user existence
		Optional<EndUser> container = endUserRepository.findById(endUser.getEmailAddress());
		if(container.isEmpty()) throw new EndUserDoesNotExistException("Cannot update password of end user with email:"+endUser.getEmailAddress()+"who do not exist");
		// User exists
		endUser.setPassword(encoder.encode(password));
		endUser = endUserRepository.save(endUser);
		log.info("End user {} password updated successfully");
		return endUser.getPassword().equals(password);
	}
	
	public void deleteById(String emailId) {
		/**
		 * Delete End User by email id
		 * @param String email address
		 */
		// Valid user existence
		Optional<EndUser> container = endUserRepository.findById(emailId);
		if(container.isEmpty()) throw new EndUserDoesNotExistException("Cannot delete end user with email:"+emailId+" who do not exist");
		// User exists
		endUserRepository.deleteById(emailId);
		log.info("End user {} deleted successfully",emailId);
	}
	
	public void deleteByIds(List<String> emailIds) {
		/**
		 * Delete End Users by their email Ids
		 * @param list of email Ids
		 */
		// Validate that each email Id exists
		List<String> absentEmails = emailIds.stream().filter(email->{
				Optional<EndUser> container = endUserRepository.findById(email);
				return container.isEmpty();}
				).toList();
		if(!absentEmails.isEmpty()) {
			throw new EndUserDoesNotExistException("End users with email ids: "+absentEmails+" do not exist");
		}
		endUserRepository.deleteAllById(emailIds);
		log.info("End users {} deleted sucessfully",emailIds);
	}
	

}
