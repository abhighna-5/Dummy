package com.spark.app.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.spark.app.dto.EmployeeProfileRequestDTO;
import com.spark.app.dto.EmployeeProfileResponseDTO;
import com.spark.app.model.EmployeeProfile;

@Component
public class EmployeeProfileMapper {
/**
 * Converts EmployeeProfile DTO to Entity and Vice-versa
 *  
 */
	
	private ModelMapper modelMapper;
	
	public EmployeeProfileMapper(ModelMapper modelMapper) {
		this.modelMapper = modelMapper;
	}
	
	public EmployeeProfile toEntity(EmployeeProfileRequestDTO employeeProfileDto) {
		/**
		 * Converts Employee Profile DTO to Entity
		 */
		return modelMapper.map(employeeProfileDto, EmployeeProfile.class);	
	}
	
	public EmployeeProfileResponseDTO toDTO(EmployeeProfile employeeProfile) {
		/**
		 * Converts Employee Profile to DTO
		 */
		return modelMapper.map(employeeProfile, EmployeeProfileResponseDTO.class);	
	}
	
	
	
}
