package com.spark.app.exception;

import org.springframework.web.bind.annotation.RestControllerAdvice;


import com.spark.app.exception.goal_management.GoalNotFoundException;

import com.spark.app.exception.performance_review.DuplicateReviewException;
import com.spark.app.exception.performance_review.IncompleteReviewException;
import com.spark.app.exception.performance_review.InsufficientDaysBetweenReviewsException;
import com.spark.app.exception.performance_review.InvalidEmployeeIdException;
import com.spark.app.exception.performance_review.InvalidManagerIdException;
import com.spark.app.exception.performance_review.NullRequestDTOException;
import com.spark.app.exception.performance_review.ReviewNotFoundException;
import com.spark.app.exception.performance_review.UnauthorizedException;
import com.spark.app.exception.performance_review.UpdateFailedException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	/**
	 * Handles All the Exceptions that Occur in the Application
	 */

   

//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<String> handleGlobalException(Exception ex, WebRequest request) {
//        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
//    }
}
