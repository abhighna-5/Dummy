package com.spark.app.exception.employee_profile;

public class UpdateRequestStatusUpdationFailedException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public UpdateRequestStatusUpdationFailedException(String errorMessage) {
		super(errorMessage);
	}

}
