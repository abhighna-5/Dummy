package com.spark.app.security.jwt;

import java.io.IOException;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.spark.app.security.EndUserUtil;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JWTFilter extends OncePerRequestFilter {
/**
 * JSON Web Token Filter
 * extends abstract class OncePerRequestFilter
 */
	
	private JWTUtil jwtUtil;
	
	private EndUserUtil endUserUtil;
	
	// Constructor Injection
	public JWTFilter(JWTUtil jwtUtil, EndUserUtil endUserUtil) {
		this.jwtUtil = jwtUtil;
		this.endUserUtil = endUserUtil;
	}
	
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		/**
		 * Filters Requests which do not have valid JWT
		 */
		final String authHeader = request.getHeader("Authorization");
		String emailAddress = null;
		String token = null;
		if(authHeader!=null && authHeader.startsWith("Bearer ")) {
			token = authHeader.substring(7);
			
			try {
			  emailAddress = jwtUtil.extractUserName(token); 
			  log.info("Validating JWT of user {}",emailAddress);
			}
			catch(Exception e) {
				log.error("Exception {} with message {} occured at JWT Filter",e,e.getMessage());
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				return;
			}
		}
		if(emailAddress!=null && SecurityContextHolder.getContext().getAuthentication()==null) {
			UserDetails user = endUserUtil.loadUserByUsername(emailAddress);
			
			if(jwtUtil.isValidToken(token, user)) {
				log.info("JSON Web Token is validated sucessfully");
				UsernamePasswordAuthenticationToken authToken = 
						new UsernamePasswordAuthenticationToken(user,null,user.getAuthorities());
				authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(authToken);
			}
			log.info("JSON Web token is invalid");
		}
		filterChain.doFilter(request,response);
		
	}
	

}
