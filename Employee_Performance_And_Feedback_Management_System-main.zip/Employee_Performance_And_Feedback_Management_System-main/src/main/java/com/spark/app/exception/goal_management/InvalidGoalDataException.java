package com.spark.app.exception.goal_management;

public class InvalidGoalDataException extends RuntimeException {
    public InvalidGoalDataException(String message) {
        super(message);
    }
}
