package com.spark.app.exception.handlers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.spark.app.exception.performance_review.DuplicateReviewException;
import com.spark.app.exception.performance_review.IncompleteReviewException;
import com.spark.app.exception.performance_review.InsufficientDaysBetweenReviewsException;
import com.spark.app.exception.performance_review.InvalidEmployeeIdException;
import com.spark.app.exception.performance_review.InvalidManagerIdException;
import com.spark.app.exception.performance_review.NullRequestDTOException;
import com.spark.app.exception.performance_review.ReviewNotFoundException;
import com.spark.app.exception.performance_review.UnauthorizedException;
import com.spark.app.exception.performance_review.UpdateFailedException;

@RestControllerAdvice
public class PerformanceReviewExceptionHandler {

	 @ExceptionHandler(DuplicateReviewException.class)
	    public ResponseEntity<String> handleDuplicateReviewException(DuplicateReviewException ex, WebRequest request) {
	        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.CONFLICT);
	    }

	    @ExceptionHandler(IncompleteReviewException.class)
	    public ResponseEntity<String> handleIncompleteReviewException(IncompleteReviewException ex, WebRequest request) {
	    	return new ResponseEntity<String>(ex.getMessage(), HttpStatus.CONFLICT);
	    }
	           
	    @ExceptionHandler(UpdateFailedException.class)
	    public ResponseEntity<String> handleUpdateFailedException(UpdateFailedException ex, WebRequest request) {
	        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.BAD_REQUEST);
	    }

	    @ExceptionHandler(ReviewNotFoundException.class)
	    public ResponseEntity<String> handleReviewNotFoundException(ReviewNotFoundException ex, WebRequest request) {
	        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_FOUND);
	    }

	    @ExceptionHandler(InsufficientDaysBetweenReviewsException.class)
	    public ResponseEntity<String> handleInsufficientDaysBetweenReviewsException(InsufficientDaysBetweenReviewsException ex, WebRequest request) {
	        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.BAD_REQUEST);
	    }

	    @ExceptionHandler(UnauthorizedException.class)
	    public ResponseEntity<String> handleUnauthorizedException(UnauthorizedException ex, WebRequest request) {
	        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.FORBIDDEN);
	    }

	    @ExceptionHandler(InvalidManagerIdException.class)
	    public ResponseEntity<String> handleInvalidManagerIdException(InvalidManagerIdException ex, WebRequest request) {
	        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_FOUND);
	    }

	    @ExceptionHandler(InvalidEmployeeIdException.class)
	    public ResponseEntity<String> handleInvalidEmployeeIdException(InvalidEmployeeIdException ex, WebRequest request) {
	        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_FOUND);
	    }

	    @ExceptionHandler(NullRequestDTOException.class)
	    public ResponseEntity<String> handleNullRequestDTOException(NullRequestDTOException ex, WebRequest request) {
	        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.BAD_REQUEST);
	    }
}
