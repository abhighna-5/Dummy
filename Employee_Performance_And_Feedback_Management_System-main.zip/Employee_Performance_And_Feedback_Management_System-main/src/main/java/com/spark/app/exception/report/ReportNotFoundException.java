package com.spark.app.exception.report;

public class ReportNotFoundException extends RuntimeException  
{
	public ReportNotFoundException(String message)
	{
		super(message);
	}
}
