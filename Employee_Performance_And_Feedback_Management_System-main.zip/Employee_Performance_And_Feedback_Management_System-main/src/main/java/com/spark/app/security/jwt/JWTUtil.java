package com.spark.app.security.jwt;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JWTUtil {
	/**
	 * Contains necessary methods for JSON Web Token
	 */
	
	private static final String SECRET = "secretshouldbeusedbyteamSPARKonl";
	// JWT alive time = 1 Hour = 3600000 milli seconds
	private static final long EXPIRATION = 3600000;
	
	
	public String generateJWT(UserDetails userDetails) {
		/**
		 * Generate JWT for given User
		 * @param UserDetails - credentials
		 * @Return String - JWT generated
		 */
		String token = null;
		
		Map<String,Object> claims = new HashMap<>();
		claims.put("roles", userDetails.getAuthorities());
		
		token = Jwts.builder()
				.setClaims(claims)
				.setSubject(userDetails.getUsername())
				.setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis()+EXPIRATION))
				.signWith(Keys.hmacShaKeyFor(SECRET.getBytes()), SignatureAlgorithm.HS256)
				.compact();
		log.info("Generated JWT for {}",userDetails.getUsername());
		return token;
	}
	
	private Claims extractClaimsFromToken(String token) {
		/**
		 * Accepts the JWT to return Claims
		 * @param String - JWT
		 * @return Claims - Claims registered in JWT
		 */
		return Jwts.parserBuilder()
				.setSigningKey(Keys.hmacShaKeyFor(SECRET.getBytes()))
				.build()
				.parseClaimsJws(token)
				.getBody();
	}
	
	private boolean isTokenExpired(String token) {
		/**
		 * Accept the JWT to verify Token is expired or not
		 */
		Claims claims = extractClaimsFromToken(token);
		return claims.getExpiration().before(new Date());
	}
	
	protected boolean isValidToken(String token, UserDetails userDetails) {
		Claims claims = extractClaimsFromToken(token);
		return claims.getSubject().equals(userDetails.getUsername()) && !isTokenExpired(token);
	}
	
	protected String extractUserName(String token) {
		Claims claims = extractClaimsFromToken(token);
		return claims.getSubject();
	}
}
