package com.spark.app.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.spark.app.dto.EmployeeProfileRequestDTO;
import com.spark.app.dto.EmployeeProfileResponseDTO;
import com.spark.app.exception.employee_profile.DuplicateEmployeeProfileException;
import com.spark.app.exception.employee_profile.EmployeeProfileNotFoundException;
import com.spark.app.exception.employee_profile.UpdateRequestAlreadyExistsException;
import com.spark.app.exception.employee_profile.UpdateRequestStatusUpdationFailedException;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.UpdateRequest;
import com.spark.app.model.UpdateRequestId;
import com.spark.app.service.EmployeeProfileService;
import com.spark.app.service.UpdateRequestService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/employee-profile")
@CrossOrigin("*")
public class EmployeeProfileController {
	/**
	 * Class that acts as Controller for operations with "EmployeeProfile" Entity
	 */
	
	private final EmployeeProfileService employeeProfileService;
	
	private final UpdateRequestService updateRequestService;
	
	public EmployeeProfileController(EmployeeProfileService employeeProfileService, UpdateRequestService updateRequestService) {
		this.employeeProfileService = employeeProfileService;
		this.updateRequestService = updateRequestService;
	}
	
	
	@PostMapping("/addOne")
	public ResponseEntity<EmployeeProfileResponseDTO> addSingleEmployeeProfile(@Valid @RequestBody EmployeeProfileRequestDTO employeeProfileDTO) throws DuplicateEmployeeProfileException{
		/**
		 * Save Single Employee Profile to the Database
		 * @param - EmployeeProfileDTO object to be added
		 * @throws - throws DuplicateEmployeeProfileException if employee already exists
		 */
		EmployeeProfileResponseDTO savedEmployeeProfileDTO = employeeProfileService.addEmployeeProfile(employeeProfileDTO);
		return new ResponseEntity<>(savedEmployeeProfileDTO,HttpStatus.CREATED);
	}
	
	@PostMapping("/addMultiple")
	public ResponseEntity<List<EmployeeProfileResponseDTO>> addMultipleEmployeeProfile(@Valid @RequestBody List<EmployeeProfileRequestDTO> listOfProfiles){
		/**
		 * Save Multiple Employee Profiles to the Database
		 * @param - List of EmployeeProfileDTO objects to be added
		 * @returns - List of Newly added employee profiles
		 */
		List<EmployeeProfileResponseDTO> savedEmployeeProfiles = employeeProfileService.addMultipleEmployeeProfiles(listOfProfiles);
		return new ResponseEntity<>(savedEmployeeProfiles,HttpStatus.CREATED);
	}
	
	@GetMapping("/fetchAll")
	public ResponseEntity<List<EmployeeProfileResponseDTO>> fetchAllTheEmployeeProfiles(){
		/**
		 * Fetch all the Employee Profiles from the Database
		 */
		List<EmployeeProfileResponseDTO> listOfEmployeeProfiles = employeeProfileService.retrieveAllTheEmployeeProfiles();
		return new ResponseEntity<>(listOfEmployeeProfiles,HttpStatus.OK);
	}
	
	@GetMapping("/fetchOne/{emailAddress}")
	public ResponseEntity<EmployeeProfileResponseDTO> findOneEmployeeProfileByEmail(@PathVariable @Email String emailAddress){
		/**
		 * Fetch Employee Profile with given email adddress if exists
		 * @param String email address
		 */
		// Check Whether User exists or not
		Optional<EmployeeProfileResponseDTO> container = employeeProfileService.findEmployeeProfileByEmail(emailAddress);
		if(container.isEmpty()) {
			// User do not exist
			throw new EmployeeProfileNotFoundException("Employee with given email address not found");
		}
		return new ResponseEntity<> (container.get(),HttpStatus.OK);
		}
		
	
	@PutMapping("/activateOne")
	public ResponseEntity<Boolean> activateEmployeeProfileCredentials(@Email @RequestParam String emailAddress){
		/**
		 * Activate End User account for given email address
		 * @param - String emailAddress
		 */
		boolean flag = employeeProfileService.activateSingleEmployeeProfileCredentials(emailAddress);
		return new ResponseEntity<>(flag,HttpStatus.NO_CONTENT);
	}
	
	@PutMapping("/deactivateOne")
	public ResponseEntity<Boolean> deActivateEmployeeProfileCredentials(@Email @RequestParam String emailAddress){
		/**
		 * Deactivate End User account for given email address
		 * @param - String emailAddress
		 */
		boolean flag = employeeProfileService.deActivateSingleEmployeeProfileCredentials(emailAddress);
		return new ResponseEntity<>(flag,HttpStatus.NO_CONTENT);
	}
	
	@PutMapping("/activateMultiple")
	public ResponseEntity<Boolean> activateMultipleEmployeeProfileCredentials(@RequestBody List<@Email String> emailIds){
		/**
		 * Activate End User accounts for multiple email addresses
		 */
		emailIds.stream()
			.forEach(employeeProfileService::activateSingleEmployeeProfileCredentials);
		return new ResponseEntity<>(true,HttpStatus.NO_CONTENT);
	}
	
	@PutMapping("/deactivateMultiple")
	public ResponseEntity<Boolean> deActivateMultipleEmployeeProfileCredentials( @RequestBody List<@Email String> emailIds){
		/**
		 * Deactivate End User accounts for multiple email addresses
		 */
		emailIds.stream()
			.forEach(employeeProfileService::deActivateSingleEmployeeProfileCredentials);
		return new ResponseEntity<>(false,HttpStatus.NO_CONTENT);
	}
	
	@PostMapping("/updateOne")
	public ResponseEntity<UpdateRequest> updateEmployeeProfile(@Valid @RequestBody EmployeeProfileRequestDTO updatedProfile){
		/**
		 * Create update request for employee profile
		 * @param - employee profile with new updates
		 * @return - Updated employee profile
		 */
		//Check whether user exist or not
		Optional<EmployeeProfileResponseDTO> container = employeeProfileService.findEmployeeProfileByEmail(updatedProfile.getContactDetails());
		if(container.isEmpty()) {
			// User do not exist
			throw new EmployeeProfileNotFoundException("Employee with given email address not found");
		}
		EmployeeProfile entity = updatedProfile.toEntity();
		entity.setEmployeeId(container.get().getEmployeeId());
		UpdateRequestId reqId = new UpdateRequestId();
		reqId.setEmployeeId(entity.getEmployeeId());
		reqId.setRequestDate(LocalDate.now());
		Optional<UpdateRequest> updateRequest = updateRequestService.findByRequestId(reqId);
		if(updateRequest.isPresent()) throw new UpdateRequestAlreadyExistsException("Only one update request per day is allowed");
		return new ResponseEntity<>(updateRequestService.createUpdateRequest(entity),HttpStatus.CREATED);
	}

	@GetMapping("/viewUpdateRequests")
	public ResponseEntity<List<UpdateRequest>> viewAllUpdateRequests(){
		/**
		 * View all the Update requests irrespective of Approval Status
		 */
		List<UpdateRequest> updateRequests = updateRequestService.viewAllUpdateRequests();
		return new ResponseEntity<>(updateRequests,HttpStatus.OK);
	}
	
	@PutMapping("/approveUpdateRequest")
	public ResponseEntity<Boolean> approveUpdateRequest(@RequestBody UpdateRequestId requestId)
	{	
		/**
		 * Approve update request based on request id
		 */
		boolean flag = updateRequestService.approveUpdateRequest(requestId);
		if(!flag) {
			throw new UpdateRequestStatusUpdationFailedException("Update Request Approval Failed");
		}
		return new ResponseEntity<>(true,HttpStatus.NO_CONTENT);
		
	}
	@PutMapping("/rejectUpdateRequest")
	public ResponseEntity<Boolean> rejectUpdateRequest(@RequestBody UpdateRequestId requestId)
	{
		/**
		 * Reject update request based on request id
		 */
		boolean flag = updateRequestService.rejectUpdateRequest(requestId);
		if(!flag) {
			throw new UpdateRequestStatusUpdationFailedException("Update Request Rejection Failed");
		}
		return new ResponseEntity<>(true,HttpStatus.NO_CONTENT);
		
	}
	
	@GetMapping("/viewPendingUpdateRequests")
	public ResponseEntity<List<UpdateRequest>> viewPendingUpdateRequests(){
		/**
		 * View all the update requests with status - ApprovalStatus.STATUS_PENDING
		 */
		List<UpdateRequest> updateRequests = updateRequestService.viewPendingUpdateRequests();
		return new ResponseEntity<>(updateRequests,HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteOne/{employeeId}")
	public ResponseEntity<String> deleteOneEmployeeProfile(@PathVariable long employeeId) {
		/**
		 * Delete employee profile based on given employee ID
		 * @param - long employee Id
		 * @return - String indicating status
		 */
		employeeProfileService.deleteEmployeeProfileById(employeeId);
		return new ResponseEntity<>("Deletion Successful",HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/deleteMultiple")
	public ResponseEntity<String> deleteMultipleEmployeeProfile(@RequestBody List<Long> employeeIds){
		/**
		 * Delete employee profiles with given employeeIds
		 * @param - List of employee IDs
		 * @return - String indicating status
		 */
		employeeProfileService.deleteEmployeeProfilesByIds(employeeIds);
	return new ResponseEntity<>("Deletion Successful",HttpStatus.NO_CONTENT);
	}
	
	
}
