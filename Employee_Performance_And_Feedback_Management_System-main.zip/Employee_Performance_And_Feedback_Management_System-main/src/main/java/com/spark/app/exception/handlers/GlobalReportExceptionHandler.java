package com.spark.app.exception.handlers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.spark.app.exception.report.NotHRManagerException;
import com.spark.app.exception.report.NotProjectManagerException;
import com.spark.app.exception.report.ReportNotFoundException;

@RestControllerAdvice
public class GlobalReportExceptionHandler {

    @ExceptionHandler(ReportNotFoundException.class)
    public ResponseEntity<String> handleReportNotFoundException(ReportNotFoundException ex) 
    {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }


    @ExceptionHandler(NotHRManagerException.class)
    public ResponseEntity<String> handleNotHRManagerException(NotHRManagerException ex) 
    {
    	return new ResponseEntity<>(ex.getMessage(), HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(NotProjectManagerException.class)
    public ResponseEntity<String> handleNotProjectManagerException(NotProjectManagerException ex) 
    {
    	return new ResponseEntity<>(ex.getMessage(), HttpStatus.FORBIDDEN);
    }

    
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGenericException(Exception ex) 
    {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
