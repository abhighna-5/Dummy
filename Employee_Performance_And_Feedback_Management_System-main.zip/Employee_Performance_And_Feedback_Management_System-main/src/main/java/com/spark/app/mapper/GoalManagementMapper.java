package com.spark.app.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spark.app.dto.GoalManagementRequestDTO;


import com.spark.app.dto.GoalManagementResponseDTO;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.GoalManagement;
import com.spark.app.repository.EmployeeProfileRepository;


import com.spark.app.exception.performance_review.InvalidEmployeeIdException;


@Component 
public class GoalManagementMapper {
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private EmployeeProfileRepository employeeProfileRepository;
	
	public GoalManagementResponseDTO toDTO(GoalManagement goalManagement) {
		
		return modelMapper.map(goalManagement, GoalManagementResponseDTO.class);
	}

	public GoalManagement toEntity(GoalManagementRequestDTO goalManagementDTO) {
		
		GoalManagement goal = new GoalManagement();
		
		EmployeeProfile employee = employeeProfileRepository.findById(goalManagementDTO.getEmployeeId())
									.orElseThrow(() -> new InvalidEmployeeIdException("Employee not found"));
		
		
		
		goal.setGoalDescription(goalManagementDTO.getGoalDescription());
		goal.setTargetDate(goalManagementDTO.getTargetDate());
		goal.setProgressStatus(goalManagementDTO.getProgressStatus());
		goal.setEmployeeId(employee);
		return goal;
	}
	
	
}
