package com.spark.app.dto;

import com.spark.app.model.Department;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.Role;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class EmployeeProfileRequestDTO{
	
	
	@NotBlank
	@Pattern(regexp="[A-Za-z ]+")
	private String name;
	@NotNull
	private Department department;
	@NotNull
	private Role role;
	@Email
	@NotBlank
	private String contactDetails;
	
	
	public EmployeeProfile toEntity() {
		EmployeeProfile entity = new EmployeeProfile();
		entity.setContactDetails(contactDetails);
		entity.setDepartment(department);
		entity.setName(name);
		entity.setRole(role);
		return entity;
	}
	
	
	
	
	
	
	
}