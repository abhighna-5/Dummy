package com.spark.app.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportHRResponseDTO 
{
    private long employeeId;
    private String employeeName;
    private double averageScore;
}
