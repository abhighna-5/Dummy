package com.spark.app.exception.authentication;

public class EndUserAlreadyExistException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public EndUserAlreadyExistException(String errorMessage) {
		super(errorMessage);
	}

}
