package com.spark.app.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.spark.app.dto.EndUserDTO;
import com.spark.app.security.EndUser;

@Component
public class EndUserMapper {
	
	private ModelMapper modelMapper;
	
	EndUserMapper(ModelMapper modelMapper){
		this.modelMapper = modelMapper;
	}
	
	public EndUser toEntity(EndUserDTO endUserDTO) {
		/**
		 * Convert DTO object to Entity
		 */
		return modelMapper.map(endUserDTO, EndUser.class);
	}
	
	public EndUserDTO toDTO(EndUser endUser) {
		/**
		 * Convert Entity to DTO
		 */
		return modelMapper.map(endUser,EndUserDTO.class);
	}

}
