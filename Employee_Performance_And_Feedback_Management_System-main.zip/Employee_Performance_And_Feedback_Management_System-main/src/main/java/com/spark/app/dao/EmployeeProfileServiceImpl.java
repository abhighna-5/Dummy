package com.spark.app.dao;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import com.spark.app.model.Department;

import java.util.function.Predicate;

import com.spark.app.dto.EmployeeProfileRequestDTO;
import com.spark.app.dto.EmployeeProfileResponseDTO;
import com.spark.app.exception.employee_profile.DuplicateEmployeeProfileException;
import com.spark.app.exception.employee_profile.EmployeeProfileNotFoundException;
import com.spark.app.mapper.EmployeeProfileMapper;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.repository.EmployeeProfileRepository;
import com.spark.app.security.EndUser;
import com.spark.app.security.EndUserService;
import com.spark.app.service.EmployeeProfileService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmployeeProfileServiceImpl implements EmployeeProfileService{
	
	// Dependency Declaration 
	private final EmployeeProfileRepository employeeProfileRepository;
	
	private final EndUserService endUserService;
	
	private final EmployeeProfileMapper employeeProfileMapper;
	
	// Function that converts entity to DTO
	private Function<EmployeeProfile,EmployeeProfileResponseDTO> mapToDTO;
	
	// Function that converts DTO to entity
	private Function<EmployeeProfileRequestDTO,EmployeeProfile> mapToEntity;
	
	// Predicate that return true if Employee exists in the database
	Predicate<EmployeeProfile> employeeAlreadyExists;
	
	
	
	// Constructor Injection
	public EmployeeProfileServiceImpl(EmployeeProfileRepository employeeProfileRepository, EndUserService endUserService, EmployeeProfileMapper employeeProfileMapper) {
		this.employeeProfileRepository = employeeProfileRepository;
		this.endUserService = endUserService;
		this.employeeProfileMapper = employeeProfileMapper;
		mapToDTO = this.employeeProfileMapper::toDTO;
		mapToEntity = this.employeeProfileMapper::toEntity;	
		employeeAlreadyExists = employee->{
			Optional<EmployeeProfile> container = this.employeeProfileRepository.findByContactDetails(employee.getContactDetails());
			return container.isPresent();
		};
	}

	@Override
	public EmployeeProfileResponseDTO addEmployeeProfile(EmployeeProfileRequestDTO employeeDto) throws DuplicateEmployeeProfileException {
		/**
		 * Add Single Employee Profile to the Database and creates EndUser profile for login with employee name as default password
		 * @param EmployeeProfileRequestDTO - Details of new employee
		 * @return EmployeeProfileResponseDTO - Saved details of new employee with generated employee id
		 * @throws DuplicateEmployeeProfileException - When employee profile already exists
		 */
		
		EmployeeProfile entity = mapToEntity.apply(employeeDto);
		
		// Check existence of entity in database
		Optional<EmployeeProfile> container = employeeProfileRepository.findByContactDetails(entity.getContactDetails());
		if(container.isPresent()) throw new DuplicateEmployeeProfileException("Employee with email:"+entity.getContactDetails()+" already exists");
		
		// Entity is not present, so save it
		EmployeeProfile savedEntity = employeeProfileRepository.save(entity);
		log.info("Employee Profile for {} saved successfully",entity.getContactDetails());
		
		// Create an End User for Employee for login
		var createdUser = convertToEndUser(savedEntity);
		endUserService.registerEndUser(createdUser);
		log.info("End User {} created successfully",createdUser.getEmailAddress());
		
		return mapToDTO.apply(savedEntity);
	}
	
	private EndUser convertToEndUser(EmployeeProfile entity) {
		/**
		 * Convert Entity to EndUser
		 * - Default Password will be entity name
		 */
		var user = new EndUser();
		user.setActivated(false);
		user.setEmailAddress(entity.getContactDetails());
		user.setPassword(entity.getName());
		user.setRole(entity.getRole());
		return user;
	}
	

	@Override
	public List<EmployeeProfileResponseDTO> findEmployeesByDepartment(Department department) 
	{
		return employeeProfileRepository.findByDepartment(department) // Get all the Employee Profiles
				.stream() // Convert List to Stream
				.map(mapToDTO) // Convert Entity to DTO
				.collect(Collectors.toList());
	}


	@Override
	public List<EmployeeProfileResponseDTO> addMultipleEmployeeProfiles(List<EmployeeProfileRequestDTO> listOfEmployeeProfileDTOs) throws DuplicateEmployeeProfileException {
		/**
		 * Adds Multiple Employee Profiles to the database and creates end user profiles for each to login
		 * @param List<EmployeeProfileRequestDTO> - List with details of new employees
		 * @return List<EmployeeProfileResponseDTO> - List with saved details of new employee with generated employee id
		 * @throws DuplicateEmployeeProfileException - When any employee profile already exists
		 */
		// Convert DTOs to Entities
		List<EmployeeProfile> listOfEntities = listOfEmployeeProfileDTOs
													.stream()
													.map(mapToEntity)
													.toList();
		
		// Check for any existing employee profiles in the list		
		var existingEntities = listOfEntities.stream().filter(employeeAlreadyExists).toList();
		if(!existingEntities.isEmpty()) {
			var emailsOfExistingEntities = existingEntities.stream().map(e->e.getContactDetails()).toList();
			throw new DuplicateEmployeeProfileException("Employees with contact details: "+emailsOfExistingEntities+" already exists");
		}
		
		// All are new Employee profiles
		var savedEntities =  employeeProfileRepository.saveAll(listOfEntities);
		log.info("All the Employee profiles are saved sucessfully");
		
		// Register all saved employees as End User for Login
		savedEntities.stream().forEach(
				savedEntity->{
			var createdUser = convertToEndUser(savedEntity);
			endUserService.registerEndUser(createdUser);
		});
		log.info("End users are created successfully");
		
		return savedEntities
		.stream()
		.map(mapToDTO)
		.toList();
	}
	
	@Override
	public Optional<EmployeeProfileResponseDTO> findEmployeeProfileById(long employeeId) {
		/**
		 * Find Single Employee Profile by employee Id
		 * @param long employeeId
		 * @return Optional object of EmployeeProfileResponseDTO
		 */
		Optional<EmployeeProfile> entityContainer = employeeProfileRepository.findById(employeeId);
		if(entityContainer.isPresent()) {
			// Employee Exists
			return Optional.of(mapToDTO.apply(entityContainer.get()));
		}
		// Employee Profile is not present so return empty optional
		return Optional.empty();
	}

	@Override
	public List<EmployeeProfileResponseDTO> retrieveAllTheEmployeeProfiles() {
		/**
		 * Fetch all the employee profiles as list
		 * @return - List of Employee Profiles
		 */
		return employeeProfileRepository.findAll() // Get all the Employee Profiles
				.stream() // Convert List to Stream
				.map(mapToDTO) // Convert Entity to DTO
				.toList();
	}

	@Override
	public EmployeeProfileResponseDTO updateEmployeeProfile(long employeeId, EmployeeProfileRequestDTO employeeProfileDTO) throws EmployeeProfileNotFoundException{
		/**
		 * Updates EmployeeProfile with new details
		 * @param employee id and new details
		 * @return saved employee details
		 */
		// Check existence of employee profile
		Optional<EmployeeProfile> entityContainer = employeeProfileRepository.findById(employeeId);
		var existingEntity = entityContainer.orElseThrow(()->{throw new EmployeeProfileNotFoundException("Employee Profile with employee id: "+employeeId+" do not exist");});
		
		// Assign Existing Entity employee Id to new update profile entity
		EmployeeProfile newProfile = employeeProfileMapper.toEntity(employeeProfileDTO);
		newProfile.setEmployeeId(existingEntity.getEmployeeId());
		return mapToDTO.apply(employeeProfileRepository.save(newProfile));
	}

	@Override
	public void deleteEmployeeProfileById(long employeeId) throws EmployeeProfileNotFoundException {
		/**
		 * Deletes Employee Profile by employee Id
		 * @param Long employeeId
		 * @throws EmployeeProfileNotFoundException when employee profile is not found
		 */
		
		// Check Employee Profile existence
		Optional<EmployeeProfile> entityContainer = employeeProfileRepository.findById(employeeId);
		var entity = entityContainer.orElseThrow(()->{throw new EmployeeProfileNotFoundException("Employee Profile with employeeId:"+employeeId+" do not exist");});
		String emailAddress = entity.getContactDetails();
		
		// Delete From Employee Profile Database
		employeeProfileRepository.delete(entity);
		log.info("Deleted employee profile {}",entity.getContactDetails());
		// Delete From End User Database
		endUserService.deleteById(emailAddress);
	}
	
	

	@Override
	public void deleteEmployeeProfilesByIds(List<Long> employeeIds) throws EmployeeProfileNotFoundException{
		/**
		 * Delete Employee Profiles by given IDs
		 * @param List of employee IDs
		 * @throws EmployeeProfileNotFoundException when employee profile is not found
		 */
		// Predicate which return true if employee profile is not present
		Predicate<Long> entityIsAbsent = employeeId -> employeeProfileRepository.findById(employeeId).isEmpty();
		
		// Verify whether all employee profiles exist
		var absentEntities = employeeIds.stream()
			.filter(entityIsAbsent)
			.toList();
		if(!absentEntities.isEmpty()) throw new EmployeeProfileNotFoundException("Employees with IDs: "+absentEntities+" do not exist");
		
		// All entities are present, so delete
		List<String> emailIds = employeeIds.stream().map(employeeProfileRepository::findById).map(container->container.get().getContactDetails()).toList();
		employeeProfileRepository.deleteAllById(employeeIds);
		log.info("Delete all the employee profiles");
		endUserService.deleteByIds(emailIds);
	}

	@Override
	public boolean activateSingleEmployeeProfileCredentials(String emailAddress) throws EmployeeProfileNotFoundException{
		/**
		 * @param String emailAddress
		 * @return Activation status of employee profile credentials after operation
		 * @throws EmployeeProfileNotFoundException - When employee does not exist with given email address
		 */
		// Check whether the user existence
		Optional<EndUser> container = endUserService.findByEmailAddress(emailAddress);
		EndUser endUser = container.orElseThrow(()->{throw new EmployeeProfileNotFoundException("Employee with email:"+emailAddress+"do not exist");});
		return endUserService.activateEndUser(endUser);
		}

	@Override
	public boolean deActivateSingleEmployeeProfileCredentials(String emailAddress) throws EmployeeProfileNotFoundException{
		/**
		 * @param String emailAddress
		 * @return Activation status of employee profile credentials after operation
		 * @throws EmployeeProfileNotFoundException - When employee does not exist with given email address
		 */
		// Check whether the user existence
		Optional<EndUser> container = endUserService.findByEmailAddress(emailAddress);
		EndUser endUser = container.orElseThrow(()->{throw new EmployeeProfileNotFoundException("Employee with email:"+emailAddress+"do not exist");});
		return endUserService.deActivateEndUser(endUser);
		}
	
	@Override
	public Optional<EmployeeProfileResponseDTO> findEmployeeProfileByEmail(String email) {
		/**
		 * Find Employee Profile By Email
		 * @param String - emailAddress
		 * @return Optional - EmployeeProfileResponseDTO
		 */
		Optional<EmployeeProfile> container = employeeProfileRepository.findByContactDetails(email);
		if(container.isPresent()) {
			EmployeeProfile entity = container.get();
			return Optional.of(mapToDTO.apply(entity));
		}
		return Optional.empty();
	}

}
