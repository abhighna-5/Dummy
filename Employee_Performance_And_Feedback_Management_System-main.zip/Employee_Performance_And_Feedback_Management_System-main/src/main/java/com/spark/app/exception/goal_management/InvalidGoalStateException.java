package com.spark.app.exception.goal_management;

public class InvalidGoalStateException extends RuntimeException {
    public InvalidGoalStateException(String message) {
        super(message);
    }
}