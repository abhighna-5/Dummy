package com.spark.app.exception.goal_management;

public class GoalAlreadyAssignedException extends RuntimeException{
	public GoalAlreadyAssignedException(String message) {
		super(message);
	}
}
