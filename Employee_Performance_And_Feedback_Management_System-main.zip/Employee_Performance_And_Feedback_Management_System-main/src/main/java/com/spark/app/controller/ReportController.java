package com.spark.app.controller;

import com.spark.app.dto.ReportHRResponseDTO;
import com.spark.app.dto.ReportResponseDTO;
import com.spark.app.exception.employee_profile.EmployeeProfileNotFoundException;
import com.spark.app.exception.report.NotHRManagerException;
import com.spark.app.exception.report.NotProjectManagerException;
import com.spark.app.exception.report.ReportNotFoundException;
import com.spark.app.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/reports")
@CrossOrigin("*")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<ReportResponseDTO>> getAllReportsByEmployee(@PathVariable long employeeId) 
    {
    	/*
    	 * Returns All the Reports of an Employee
    	 * @param - EmployeeId for fetching reports
    	 */
    		List<ReportResponseDTO> reports = reportService.viewReportsByEmployee(employeeId);	
    		return new ResponseEntity<>(reports, HttpStatus.OK);
    }

    @GetMapping("/hr/{employeeId}")
    public ResponseEntity<List<ReportHRResponseDTO>> getAllReportsByHR(@PathVariable long employeeId) 
    {
    	/*
    	 * Returns All the Reports of Each Employee to the HR
    	 * @param - EmployeeId of the HR_MANAGER
    	 */
            List<ReportHRResponseDTO> reports = reportService.viewReportsByHRId(employeeId);
            return new ResponseEntity<>(reports, HttpStatus.OK);

    }
    
    @GetMapping("/manager/{employeeId}")
    public ResponseEntity<List<ReportResponseDTO>> getAllReportsByManager(@PathVariable long employeeId) 
    {
    	/*
    	 * Returns All the Reports of Each Employee to the Project Manager
    	 * @param - EmployeeId of the HR_MANAGER
    	 */
       
            List<ReportResponseDTO> reports = reportService.viewReportsByManagerId(employeeId);
            return new ResponseEntity<>(reports, HttpStatus.OK);
    }


}
