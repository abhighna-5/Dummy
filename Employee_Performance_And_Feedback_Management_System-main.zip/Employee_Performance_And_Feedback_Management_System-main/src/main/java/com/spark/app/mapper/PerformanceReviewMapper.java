package com.spark.app.mapper;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
 
import com.spark.app.dto.PerformanceReviewRequestDTO;

import com.spark.app.dto.PerformanceReviewResponseDTO;
import com.spark.app.exception.performance_review.InvalidEmployeeIdException;
import com.spark.app.exception.performance_review.InvalidManagerIdException;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.PerformanceReview;
import com.spark.app.repository.EmployeeProfileRepository;
 
 
@Component
public class PerformanceReviewMapper {
 
 
	
	@Autowired
	private EmployeeProfileRepository employeeProfileRepository;

	@Autowired
	private ModelMapper modelMapper;

	
	public PerformanceReview toEntity(PerformanceReviewRequestDTO performanceReviewRequestDTO) {
 
		
		PerformanceReview review = new PerformanceReview();
		
		EmployeeProfile employee = employeeProfileRepository.findById(performanceReviewRequestDTO.getEmployeeId())
									.orElseThrow(() -> new InvalidEmployeeIdException("Employee not found"));
		
		EmployeeProfile manager = employeeProfileRepository.findById(performanceReviewRequestDTO.getManagerId())
									.orElseThrow(() -> new InvalidManagerIdException("Manager not found"));
		
		review.setEmployeeId(employee);
		review.setManagerId(manager);
		review.setDate(performanceReviewRequestDTO.getDate());
		review.setPerformanceScore(0);
		review.setFeedback(null);
		
		
		return review;
		
	}
	
	public PerformanceReviewResponseDTO toDto(PerformanceReview performanceReview) {
		
		var responseDTO = modelMapper.map(performanceReview, PerformanceReviewResponseDTO.class);
	    
	    return responseDTO;
	}

}
 