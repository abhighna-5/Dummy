package com.spark.app.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class EndUserDTO {
	/**
	 * DTO version of End User Entity
	 */
	
	@Email
	@NotBlank
	private String emailAddress;
	@NotBlank
	private String password;
	private boolean isActivated;

}
