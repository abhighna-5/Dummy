package com.spark.app.security;

import java.util.List;
import java.util.Optional;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EndUserUtil implements UserDetailsService{
	/**
	 * Class Responsible to Bind End User Object with the session
	 * Overloads loadByUserName() method of UserDetailsService
	 */
	
	private EndUserRepository endUserRepository;
	
	public EndUserUtil(EndUserRepository endUserRepository) {
		this.endUserRepository = endUserRepository;
	}
	
	@Override
	public UserDetails loadUserByUsername(String emailAddress) throws UsernameNotFoundException {
		Optional<EndUser> endUserContainer = endUserRepository.findById(emailAddress);
		if(endUserContainer.isEmpty()) {
			// There is no End User with given email Address
			log.error("Unable to load user {} as user do not exist",emailAddress);
			throw new UsernameNotFoundException("No User exists with the given email address");			
		}
		// End User Exists, so define authorities of the user
		EndUser endUser = endUserContainer.get();
		var grantedAuthority = new SimpleGrantedAuthority("ROLE_"+endUser.getRole());
		
		// Creating Collection as User Constructor need Collection of authorities
		List<SimpleGrantedAuthority> grantedAuthorities = List.of(grantedAuthority);
		
		// Bind the End User and Return Spring Security User 
		// Format: User(user name, password, activated,accountNotExpired,accountNotLocked,credentialsNotExpired,authorities)
		log.info("User {} loaded successfully",emailAddress);
		return new User(endUser.getEmailAddress(),endUser.getPassword(),endUser.isActivated(),true,true,true,grantedAuthorities);
	}
	
	
	

}
