package com.spark.app.listener;

import com.spark.app.event.PerformanceReviewEvent;
import com.spark.app.model.PerformanceReview;
import com.spark.app.service.ReportService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class PerformanceReviewListener {

    @Autowired
    private ReportService reportService;


    @EventListener
    public void handlePerformanceReviewEvent(PerformanceReviewEvent event) {
        PerformanceReview performanceReview = event.getPerformanceReview();
       
        reportService.createReport(performanceReview);
       
    }
}

