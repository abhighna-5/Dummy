package com.spark.app.repository;

import java.time.LocalDate;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.spark.app.model.Feedback;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
    
    public List<Feedback> findByFromEmployeeEmployeeId(long fromEmployeeId);
    
    public List<Feedback> findByToEmployeeEmployeeId(long toEmployeeId);
    
    public boolean existsByFromEmployeeEmployeeIdAndToEmployeeEmployeeIdAndDate(
        long fromEmployeeId, long toEmployeeId, LocalDate date
    );
    
    @Query("SELECT f.date FROM Feedback f WHERE f.toEmployee.employeeId = ?1 ORDER BY f.date DESC LIMIT 1")
    public LocalDate recentFeedbackDate(long employeeId);
    
    @Query("SELECT f.comments FROM Feedback f WHERE f.toEmployee.employeeId = ?1 AND f.date = ?2")
    public String recentFeedbackComments(long employeeId, LocalDate date);
    
    @Query("SELECT f.date FROM Feedback f WHERE f.toEmployee.employeeId = ?1 AND f.comments IS NOT NULL ORDER BY f.date DESC LIMIT 1")
    public LocalDate recentCompletedFeedback(long employeeId);
}
