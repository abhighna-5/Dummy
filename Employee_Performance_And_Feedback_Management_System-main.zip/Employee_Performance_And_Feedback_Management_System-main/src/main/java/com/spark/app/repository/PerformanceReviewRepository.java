package com.spark.app.repository;
 
import java.time.LocalDate;

import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
 
import org.springframework.data.jpa.repository.Query;

import org.springframework.stereotype.Repository;
 
 
import com.spark.app.model.PerformanceReview;
 
 
@Repository

public interface PerformanceReviewRepository extends JpaRepository<PerformanceReview, Long>{
	
	List<PerformanceReview> findByEmployeeIdEmployeeId(long employeeId);
	
	List<PerformanceReview> findByManagerIdEmployeeId(long managerId);
	
	boolean existsByEmployeeIdEmployeeIdAndManagerIdEmployeeIdAndDate(long employeeId, long managerId, LocalDate date);
	
	
	@Query("SELECT MAX(r.date) FROM PerformanceReview r WHERE r.employeeId.employeeId = ?1 ")
	LocalDate recentReview(long employeeId);
	
	@Query("SELECT r.feedback FROM PerformanceReview r WHERE r.employeeId.employeeId = ?1 AND r.date = ?2")
	String recentFeedback(long employeeId, LocalDate date);
	
	@Query("SELECT MAX(r.date) FROM PerformanceReview r WHERE r.employeeId.employeeId = ?1 AND r.feedback IS NOT NULL ")
	LocalDate recentCompletedReview(long employeeId); 
	


 
}

 