package com.spark.app.controller;
 
import java.time.LocalDate;

import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.format.annotation.DateTimeFormat;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.GetMapping;
 
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;
 
 
import com.spark.app.dto.PerformanceReviewRequestDTO;

import com.spark.app.dto.PerformanceReviewResponseDTO;

import com.spark.app.exception.performance_review.ReviewNotFoundException;

import com.spark.app.service.PerformanceReviewService;
 
import jakarta.validation.Valid;

import jakarta.validation.constraints.FutureOrPresent;

import jakarta.validation.constraints.Max;

import jakarta.validation.constraints.Min;

import jakarta.validation.constraints.NotBlank;
 
@Validated

@RestController

@RequestMapping("/reviews")
@CrossOrigin("*")
public class PerformanceReviewController {
 
	

	// Injects an instance of PerformanceReviewService to the controller

	@Autowired
	private PerformanceReviewService performanceReviewService;
	
	
	
	// Endpoint to add a new Performance review
	@PostMapping("/addReview")
	public ResponseEntity<PerformanceReviewResponseDTO> addReview(@Valid @RequestBody PerformanceReviewRequestDTO performanceReviewRequestDTO) {
		
		/**
		 * Adding new performance review for a employee
		 * 
		 */
		
		var savedReview = performanceReviewService.addPerformanceReview(performanceReviewRequestDTO);
		
		return new ResponseEntity<PerformanceReviewResponseDTO>(savedReview,HttpStatus.CREATED);
	}
	

	// Endpoint to get the reviews of specific employee
	@GetMapping("/getReviewsEmployee")
	public ResponseEntity<List<PerformanceReviewResponseDTO>> getReviewsEmployee(@RequestParam long employeeId){
		
		/**
		 * List all the reviews of a specific employee
		 * 
		 */
		
		var reviewList = performanceReviewService.viewReviewsEmployee(employeeId);
		
		return new ResponseEntity<List<PerformanceReviewResponseDTO>>(reviewList,HttpStatus.OK);
	}

	// Endpoint to get the reviews scheduled by specific manager

	@GetMapping("/getReviewsManager")

	public ResponseEntity<List<PerformanceReviewResponseDTO>> getReviewsManager(@RequestParam long managerId){

		/**

		 * List all the reviews scheduled by the manager

		 */

		var reviewList = performanceReviewService.viewReviewsManager(managerId);

		return new ResponseEntity<List<PerformanceReviewResponseDTO>>(reviewList,HttpStatus.OK);

	}

	// Endpoint to delete a review

	@DeleteMapping("/deleteReview")

	public ResponseEntity<Void> deleteReview(@RequestParam long reviewId, @RequestParam long managerId) {

		/**

		 * Deleting the specific review

		 */

		try {

			performanceReviewService.deleteReview(reviewId, managerId);

			return ResponseEntity.noContent().build();

		}catch(ReviewNotFoundException e) {

			return ResponseEntity.notFound().build();

		}

	}

	// Endpoint to update the review date

	@PutMapping("/updateReview")

	public ResponseEntity<PerformanceReviewResponseDTO> updateReview(@RequestParam long reviewId, @RequestParam long managerId,

			@RequestParam @FutureOrPresent @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate date) {

		/**

		 * Changing the date of a specific review

		 */

		var updatedReview = performanceReviewService.updateReview(reviewId, managerId, date);

		return new ResponseEntity<PerformanceReviewResponseDTO>(updatedReview,HttpStatus.OK);

	}

 
	// Endpoint to provide score and feedback for review

	@PutMapping("/provideScoreAndFeedback")

	public ResponseEntity<PerformanceReviewResponseDTO> provideScoreAndFeedback(@RequestParam long reviewId, 

			@RequestParam long managerId,

			@RequestParam @Min(0) @Max(10) float productivity, 

			@RequestParam @Min(0) @Max(10) float teamwork,

			@RequestParam @Min(0) @Max(10) float skillProficiency, 

			@RequestParam @NotBlank String feedback) {

		/**

		 * Providing the PerformanceScore and Feedback for a review

		 */

		var completedReview = performanceReviewService.providePerformanceScoreAndFeedback(reviewId, managerId, productivity, teamwork, skillProficiency, feedback);

		return new ResponseEntity<PerformanceReviewResponseDTO>(completedReview,HttpStatus.OK);

	}

}
 