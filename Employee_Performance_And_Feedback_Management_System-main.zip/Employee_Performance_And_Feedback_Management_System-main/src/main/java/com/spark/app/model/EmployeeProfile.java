package com.spark.app.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class EmployeeProfile{
	
	@Id
	@GeneratedValue
	private long employeeId;
	
	private String name;
	
	@Enumerated(EnumType.STRING)
	private Department department;
	
	@Enumerated(EnumType.STRING)
	private Role role;
	
	@Column(name="email_address",unique=true, nullable=false)
	private String contactDetails;
}
