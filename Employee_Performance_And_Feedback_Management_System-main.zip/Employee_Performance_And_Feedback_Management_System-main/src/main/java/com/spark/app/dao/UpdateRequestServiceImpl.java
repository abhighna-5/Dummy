package com.spark.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.spark.app.exception.employee_profile.UpdateRequestAlreadyExistsException;
import com.spark.app.exception.employee_profile.UpdateRequestDoNotExistException;
import com.spark.app.exception.employee_profile.UpdateRequestIsNotPendingException;
import com.spark.app.model.ApprovalStatus;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.UpdateRequest;
import com.spark.app.model.UpdateRequestId;
import com.spark.app.repository.EmployeeProfileRepository;
import com.spark.app.repository.UpdateRequestRepository;
import com.spark.app.service.UpdateRequestService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UpdateRequestServiceImpl implements UpdateRequestService{

	private UpdateRequestRepository updateRequestRepository; 
	
	private EmployeeProfileRepository employeeProfileRepository;
	
	
	public UpdateRequestServiceImpl(UpdateRequestRepository updateRequestRepository, EmployeeProfileRepository employeeProfileRepository) {
		this.updateRequestRepository = updateRequestRepository;
		this.employeeProfileRepository = employeeProfileRepository;
	}
	
	@Override
	public UpdateRequest createUpdateRequest(EmployeeProfile updatedProfile) {
		/**
		 * Create a Update Request
		 */
		UpdateRequest request = new UpdateRequest();
		request.setName(updatedProfile.getName());
		request.setRole(updatedProfile.getRole());
		request.setContactDetails(updatedProfile.getContactDetails());
		request.setDepartment(updatedProfile.getDepartment());
		UpdateRequestId reqId = new UpdateRequestId();
		request.setRequestId(reqId);
		reqId.setEmployeeId(updatedProfile.getEmployeeId());
		reqId.setRequestDate(LocalDate.now());
		// Check if Update Request already exists
		Optional<UpdateRequest> container = findByRequestId(reqId);
		if(container.isPresent()) throw new UpdateRequestAlreadyExistsException("Update Request already exists");
		log.info("Update request for {} created successfully",updatedProfile.getContactDetails());
		return updateRequestRepository.save(request);
	}
	
	@Override
	public Optional<UpdateRequest> findByRequestId(UpdateRequestId reqId){
		/**
		 * Find Update Request by Request Id
		 */
		log.info("Update request fetch is successful");
		return updateRequestRepository.findById(reqId);
	}

	@Override
	public List<UpdateRequest> viewAllUpdateRequests(){
		/**
		 * View all the update requests of ApprovalStatus STATUS_PENDING, STATUS_APPROVED, STATUS_REJECTED
		 */
		log.info("Update requests are fetched successfully");
		return updateRequestRepository.findAll();
	}

	@Override
	public boolean approveUpdateRequest(UpdateRequestId requestId) {
		/**
		 * Approve Update Request on requestId
		 */
		Optional<UpdateRequest> container = updateRequestRepository.findById(requestId);
		UpdateRequest request = container.orElseThrow(()-> new UpdateRequestDoNotExistException("Update Request do not exist"));
		if(request.getStatus()!=ApprovalStatus.STATUS_PENDING) {
			throw new UpdateRequestIsNotPendingException("Cannot Reject Update Request that is not currently pending");
		}
		request.setStatus(ApprovalStatus.STATUS_APPROVED);
		
		// Reflect Changes in Employee Profile Database
		Optional<EmployeeProfile> entityContainer = employeeProfileRepository.findById(request.getRequestId().getEmployeeId());
		if(entityContainer.isPresent()) {
			EmployeeProfile entity = entityContainer.get();
		modifyEntity(entity,request);
		employeeProfileRepository.save(entity);}
		log.info("Update request approved sucessfully");
		return updateRequestRepository.save(request).getStatus()==ApprovalStatus.STATUS_APPROVED;	
	}
	
	
	private void modifyEntity(EmployeeProfile entity, UpdateRequest request) {
		/**
		 * Update an Entity with details of request
		 */
		entity.setContactDetails(request.getContactDetails());
		entity.setDepartment(request.getDepartment());
		entity.setName(request.getName());
		entity.setRole(request.getRole());
	}
	
	@Override
	public boolean rejectUpdateRequest(UpdateRequestId requestId) {
		/**
		 * Reject an Update Request
		 * @param UpdateRequestID
		 */
		// Obtain the Update Request
		Optional<UpdateRequest> container = updateRequestRepository.findById(requestId);
		UpdateRequest request = container.orElseThrow(()-> new UpdateRequestDoNotExistException("Update Request do not exist"));
		if(request.getStatus()!=ApprovalStatus.STATUS_PENDING) {
			throw new UpdateRequestIsNotPendingException("Cannot Reject Update Request that is not currently pending");
		}
		request.setStatus(ApprovalStatus.STATUS_REJECTED);
		log.info("Update request rejected sucessfully");
		return updateRequestRepository.save(request).getStatus()==ApprovalStatus.STATUS_REJECTED;	
	}

	@Override
	public List<UpdateRequest> viewPendingUpdateRequests() {
		/**
		 * Returns all the Update Requests with Approval Status as "STATUS_PENDING"
		 */
		log.info("Pending update requests fetched sucessfully");
		return updateRequestRepository.findAll().stream()
				.filter(ur-> ur.getStatus().equals(ApprovalStatus.STATUS_PENDING))
				.toList();
	}

	
	
	
	
	
}
