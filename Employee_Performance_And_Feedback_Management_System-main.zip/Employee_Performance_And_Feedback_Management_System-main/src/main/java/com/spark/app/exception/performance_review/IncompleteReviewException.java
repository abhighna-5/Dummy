package com.spark.app.exception.performance_review;

public class IncompleteReviewException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public IncompleteReviewException(String message) {
		super(message);
	}
}
