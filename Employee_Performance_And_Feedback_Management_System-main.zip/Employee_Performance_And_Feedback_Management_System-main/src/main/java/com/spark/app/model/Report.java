package com.spark.app.model;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Report {
 
	@Id
	@SequenceGenerator(name="reportId_sequence_generator",initialValue=1000 ,sequenceName="reportId_sequence_generator",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="reportId_sequence_generator")
	private long reportId;
	@DateTimeFormat(pattern="dd-MM-yyyy")
	private LocalDate reportDate = LocalDate.now();
	private String performanceSummary;
	private String feedbackSummary;
	
	@ManyToOne
	@JoinColumn(name="employee_id",nullable=false)
	private EmployeeProfile employeeId;
	
	
}
