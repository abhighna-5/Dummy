package com.spark.app.dao;

import java.time.LocalDate;
import java.util.List;

import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spark.app.dto.GoalManagementRequestDTO;
import com.spark.app.dto.GoalManagementResponseDTO;

import com.spark.app.exception.performance_review.InvalidEmployeeIdException;
import com.spark.app.exception.performance_review.UnauthorizedException;
import com.spark.app.exception.goal_management.GoalAlreadyAssignedException;
import com.spark.app.exception.goal_management.GoalNotFoundException;
import com.spark.app.exception.goal_management.InvalidGoalDataException;
import com.spark.app.exception.goal_management.InvalidGoalStateException;
import com.spark.app.mapper.GoalManagementMapper;

import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.GoalManagement;
import com.spark.app.model.ProgressStatus;
import com.spark.app.model.Role;
import com.spark.app.repository.EmployeeProfileRepository;
import com.spark.app.repository.GoalManagementRepository;
import com.spark.app.service.GoalManagementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class GoalManagementServiceImpl implements GoalManagementService{
	
	@Autowired
	private GoalManagementRepository goalManagementRepository;
	
	@Autowired
	private GoalManagementMapper goalManagementMapper;
	
		
	@Autowired
	private EmployeeProfileRepository employeeProfileRepository;
	
	private static final Logger logger = LoggerFactory.getLogger(GoalManagementServiceImpl.class);

	@Override
	public GoalManagementResponseDTO createGoal(GoalManagementRequestDTO goalManagementDTO) {
	    logger.info("Creating a new goal for employee ID: {}", goalManagementDTO.getEmployeeId());
 
	    EmployeeProfile employee = employeeProfileRepository.findById(goalManagementDTO.getEmployeeId())
	            .orElseThrow(() -> {
	                logger.error("Invalid Employee ID: {}", goalManagementDTO.getEmployeeId());
	                return new InvalidEmployeeIdException("Employee not found");
	            });
 
	    boolean isGoalAssigned = goalManagementRepository.existsByEmployeeId_EmployeeIdAndGoalDescription(
	            goalManagementDTO.getEmployeeId(), goalManagementDTO.getGoalDescription());
 
	    if (isGoalAssigned) {
	        logger.warn("Goal already assigned for Employee ID: {}, Goal: {}", goalManagementDTO.getEmployeeId(), goalManagementDTO.getGoalDescription());
	        throw new GoalAlreadyAssignedException("Employee already has the same goal: " + goalManagementDTO.getGoalDescription());
	    }
	    
	    if(employee.getRole()==Role.EMPLOYEE) {
	    	GoalManagement goalManagement = goalManagementMapper.toEntity(goalManagementDTO);
		    goalManagementRepository.save(goalManagement);
		    logger.info("Goal successfully created for Employee ID: {}", goalManagementDTO.getEmployeeId());
		    return goalManagementMapper.toDTO(goalManagement);
	    }
	    else {
	    	throw new UnauthorizedException("Employees are only allowed to have assigned goals.");
	    }
	}


	@Override
	public List<GoalManagementResponseDTO> getGoalsByEmployeeId(Long employeeId) {
	    logger.info("Fetching goals for Employee ID: {}", employeeId);

	    if (!employeeProfileRepository.existsById(employeeId)) {
	        logger.error("Invalid Employee ID: {}", employeeId);
	        throw new InvalidEmployeeIdException("Employee not found with ID: " + employeeId);
	    }

	    List<GoalManagement> goals = goalManagementRepository.findByEmployeeId_EmployeeId(employeeId);
	    logger.info("Found {} goals for Employee ID: {}", goals.size(), employeeId);

	    return goals.stream().map(goalManagementMapper::toDTO).collect(Collectors.toList());
	}



	@Override
	public GoalManagementResponseDTO updateGoalDeadline(Long goalId, LocalDate newDeadLine) {
	    logger.info("Updating goal deadline for Goal ID: {} to new deadline: {}", goalId, newDeadLine);
	    
	    GoalManagement goal = goalManagementRepository.findById(goalId)
	        .orElseThrow(() -> {
	            logger.error("Goal not found with ID: {}", goalId);
	            return new GoalNotFoundException("Goal not found with id: " + goalId);
	        });

	    if (goal.getProgressStatus() == ProgressStatus.COMPLETED) {
	        logger.warn("Cannot update deadline for a completed goal with ID: {}", goalId);
	        throw new InvalidGoalStateException("Goal is already completed and cannot be modified.");
	    }
	    
	    
	    if (goal.getProgressStatus() == ProgressStatus.UNDER_REVIEW) {
	        logger.warn("Cannot update deadline while goal is under review. Awaiting manager approval for Goal ID: {}", goalId);
	        throw new InvalidGoalStateException("Goal is under review and cannot be modified until manager approval.");
	    }

	    goal.setTargetDate(newDeadLine);
	    goalManagementRepository.save(goal);
	    logger.info("Successfully updated deadline for Goal ID: {}", goalId);
	    
	    return goalManagementMapper.toDTO(goal);
	}



	@Override
	public void deleteGoalById(Long goalId) {
	    logger.info("Attempting to delete goal with ID: {}", goalId);

	    if (!goalManagementRepository.existsById(goalId)) {
	        logger.error("Goal not found with ID: {}", goalId);
	        throw new GoalNotFoundException("Goal not found with id: " + goalId);
	    }

	    goalManagementRepository.deleteById(goalId);
	    logger.info("Successfully deleted goal with ID: {}", goalId);
	}


	@Override
	public List<GoalManagementResponseDTO> getAllGoals() {
	    logger.info("Fetching all goals.");
	
	    List<GoalManagement> goals = goalManagementRepository.findAll();
	
	    if (goals.isEmpty()) {
	        logger.warn("No goals found.");
	    } else {
	        logger.info("Retrieved {} goals.", goals.size());
	    }
	
	    return goals.stream().map(goalManagementMapper::toDTO).collect(Collectors.toList());
	}

	
	
	@Override
	public GoalManagementResponseDTO markAsComplete(long goalId) {
	    logger.info("Marking goal as UNDER REVIEW for Goal ID: {}", goalId);

	    GoalManagement goal = goalManagementRepository.findById(goalId)
	        .orElseThrow(() -> {
	            logger.error("Goal not found with ID: {}", goalId);
	            return new GoalNotFoundException("Goal not found with id: " + goalId);
	        });

	    goal.setProgressStatus(ProgressStatus.UNDER_REVIEW);
	    goal = goalManagementRepository.save(goal);

	    logger.info("Successfully marked Goal ID {} as UNDER REVIEW", goalId);

	    return goalManagementMapper.toDTO(goal);
	}

	
	@Override
	public Optional<GoalManagement> findGoalById(long goalId) {
	    logger.info("Searching for goal with ID: {}", goalId);

	    Optional<GoalManagement> goal = goalManagementRepository.findById(goalId);

	    if (goal.isEmpty()) {
	        logger.error("Goal not found with ID: {}", goalId);
	        throw new GoalNotFoundException("Goal not found with id: " + goalId);
	    }

	    logger.info("Goal found with ID: {}", goalId);
	    return goal;
	}


	@Override
	public List<GoalManagementResponseDTO> getAllGoalsUnderReview() {
	    logger.info("Fetching all goals that are UNDER REVIEW.");

	    List<GoalManagement> goals = goalManagementRepository.findAll();

	    List<GoalManagementResponseDTO> underReviewGoals = goals.stream()
	        .filter(g -> g.getProgressStatus() == ProgressStatus.UNDER_REVIEW)
	        .map(goalManagementMapper::toDTO)
	        .collect(Collectors.toList());

	    if (underReviewGoals.isEmpty()) {
	        logger.warn("No goals found with UNDER REVIEW status.");
	    } else {
	        logger.info("Retrieved {} goals with UNDER REVIEW status.", underReviewGoals.size());
	    }

	    return underReviewGoals;
	}

	@Override
	public GoalManagementResponseDTO approveOrRejectGoal(Long goalId, boolean approve) {
	    logger.info("{} goal under review with ID: {}", approve ? "Approving" : "Rejecting", goalId);

	    GoalManagement goal = goalManagementRepository.findById(goalId)
	        .orElseThrow(() -> {
	            logger.error("Goal not found with ID: {}", goalId);
	            return new GoalNotFoundException("Goal not found with id: " + goalId);
	        });

	    if (goal.getProgressStatus() != ProgressStatus.UNDER_REVIEW) {
	        logger.warn("Goal ID {} is not under review, no action taken.", goalId);
	        throw new InvalidGoalDataException("Goal is not in UNDER REVIEW status.");
	    }

	   
	    goal.setProgressStatus(approve ? ProgressStatus.COMPLETED : ProgressStatus.IN_PROGRESS);

	    goalManagementRepository.save(goal);
	    logger.info("Successfully {} goal ID: {}", approve ? "approved" : "rejected", goalId);

	    return goalManagementMapper.toDTO(goal);
	}

	@Override
	public List<GoalManagementResponseDTO> getGoalsByEmployeeAndDateRange(long employeeId, LocalDate startDate, LocalDate endDate) {
	    logger.info("Fetching goals for Employee ID: {} between {} and {}", employeeId, startDate, endDate);

	    List<GoalManagement> goals = goalManagementRepository.findByEmployeeIdEmployeeIdAndTargetDateBetween(employeeId, startDate, endDate);

	    if (goals.isEmpty()) {
	        logger.warn("No goals found for Employee ID: {}", employeeId);
	        throw new GoalNotFoundException("Goals not assigned to employee: " + employeeId);
	    }

	    logger.info("Retrieved {} goals for Employee ID: {}", goals.size(), employeeId);
	    return goals.stream().map(goalManagementMapper::toDTO).collect(Collectors.toList());
	}
	
	

	

}


	
	

