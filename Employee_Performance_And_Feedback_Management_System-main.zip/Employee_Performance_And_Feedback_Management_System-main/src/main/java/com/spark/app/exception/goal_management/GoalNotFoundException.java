package com.spark.app.exception.goal_management;

public class GoalNotFoundException extends RuntimeException{
	public GoalNotFoundException(String message) {
		super(message);
	}

}
