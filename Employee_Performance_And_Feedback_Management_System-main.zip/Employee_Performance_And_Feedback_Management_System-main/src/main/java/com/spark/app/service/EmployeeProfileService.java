package com.spark.app.service;

import java.util.List;

import com.spark.app.model.Department;
import java.util.Optional;

import com.spark.app.dto.EmployeeProfileRequestDTO;
import com.spark.app.dto.EmployeeProfileResponseDTO;
import com.spark.app.exception.employee_profile.DuplicateEmployeeProfileException;

public interface EmployeeProfileService {
	
	EmployeeProfileResponseDTO addEmployeeProfile(EmployeeProfileRequestDTO emplopyeeDto) throws DuplicateEmployeeProfileException;
	
	List<EmployeeProfileResponseDTO> addMultipleEmployeeProfiles(List<EmployeeProfileRequestDTO> listOfEmployeeProfileDTO);
	
	Optional<EmployeeProfileResponseDTO> findEmployeeProfileById(long employeeId);
	
	List<EmployeeProfileResponseDTO> retrieveAllTheEmployeeProfiles();
	
	EmployeeProfileResponseDTO updateEmployeeProfile(long employeeId, EmployeeProfileRequestDTO employeeProfileDTO);
	
	void deleteEmployeeProfileById(long employeeId);
	
	void deleteEmployeeProfilesByIds(List<Long> employeeIds);
	
	boolean activateSingleEmployeeProfileCredentials(String emailAddress);
	
	boolean deActivateSingleEmployeeProfileCredentials(String emailAddress);
	
	Optional<EmployeeProfileResponseDTO> findEmployeeProfileByEmail(String email);

	List<EmployeeProfileResponseDTO> findEmployeesByDepartment(Department department);

}
