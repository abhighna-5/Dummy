package com.spark.app.exception.employee_profile;

public class UpdateRequestDoNotExistException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UpdateRequestDoNotExistException(String errorMessage) {
		super(errorMessage);
	}
	
}
