package com.spark.app.exception.handlers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.spark.app.exception.employee_profile.DuplicateEmployeeProfileException;
import com.spark.app.exception.employee_profile.EmployeeProfileNotFoundException;
import com.spark.app.exception.employee_profile.UpdateRequestAlreadyExistsException;
import com.spark.app.exception.employee_profile.UpdateRequestIsNotPendingException;
import com.spark.app.exception.employee_profile.UpdateRequestStatusUpdationFailedException;

@RestControllerAdvice
public class EmployeeProfileExceptionHandler {
/**
 * Handles Exceptions caused in the Employee Profile Controller
 */	
	@ExceptionHandler(exception=EmployeeProfileNotFoundException.class)
	public ResponseEntity<Map<String,String>> handleEmployeeProfileNotFoundException(EmployeeProfileNotFoundException exception, WebRequest request){
		/**
		 * Handles EmployeeProfileNotFoundException
		 * BadCredentialsException Occurs When any Employee Profile does not exist with given email
		 */
		Map<String,String> payload = buildPayload(
						"Employee Do not Exist",
						"Employee Profile does not exist with the given email",
						exception.getMessage());
	
		return new ResponseEntity<>(payload,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(exception=DuplicateEmployeeProfileException.class)
	public ResponseEntity<Map<String,String>> handleDuplicateEmployeeProfileException(DuplicateEmployeeProfileException exception, WebRequest request){
		/**
		 * Handles DuplicateEmployeeProfileException
		 * DuplicateEmployeeProfileException occurs when tried to create employee profile with already existing details
		 */
		Map<String,String> payload = buildPayload(
				"Duplicate Employee Profile",
				"Employee Profile already exists",
				exception.getMessage());

		return new ResponseEntity<>(payload,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(exception=UpdateRequestAlreadyExistsException.class)
	public ResponseEntity<Map<String,String>> handleUpdateRequestAlreadyExistsException(UpdateRequestAlreadyExistsException exception, WebRequest request){
		/**
		 * Handles UpdateRequestAlreadyExistsException
		 * UpdateRequestAlreadyExistsException occurs when already an profile update request exists in the database
		 */
		Map<String,String> payload = buildPayload(
				"Update Request Already Exists",
				"Update Request can be made only once per day",
				exception.getMessage());
		
		return new ResponseEntity<>(payload,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(exception=UpdateRequestStatusUpdationFailedException.class)
	public ResponseEntity<Map<String,String>> handleUpdateRequestStatusUpdationFailedException(UpdateRequestStatusUpdationFailedException exception, WebRequest request){
		/**
		 * Handles UpdateRequestStatusUpdationFailedException
		 * UpdateRequestStatusUpdationFailedException occurs when update request approval or rejection is failed
		 */
		Map<String,String> payload = buildPayload(
				"Update Request Status Updation is Failed",
				"Try Again",
				exception.getMessage());
		
		return new ResponseEntity<>(payload,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(exception=UpdateRequestIsNotPendingException.class)
	public ResponseEntity<Map<String,String>> handleUpdateRequestIsNotPendingException(UpdateRequestIsNotPendingException exception, WebRequest request){
		/**
		 * Handles UpdateRequestIsNotPendingException
		 * UpdateRequestIsNotPendingException occurs when update request which is either already approved or rejected is tried to update again
		 */
		Map<String,String> payload = buildPayload(
				"Update Request is not Pending",
				"Cannot approve/reject Update request which is already approved/rejected",
				exception.getMessage());
		
		return new ResponseEntity<>(payload,HttpStatus.BAD_REQUEST);
	}
	
	private Map<String,String> buildPayload(String payLoadTitle, String payLoadMessage, String payLoadException){
		/**
		 * Builds Payload with title, message and exception message
		 * @param payLoadTitle - title of the payload
		 * @param payLoadMessage - message to send with payload
		 * @param payLoadException - exception message to send payload
		 * @return Map<String,String> - Constructed Payload
		 */
		Map<String,String> payload = new HashMap<>();
		payload.put("title", payLoadTitle);
		payload.put("message", payLoadMessage);
		payload.put("exception", payLoadException);
		return payload;
	}
		
}
