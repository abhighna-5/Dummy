package com.spark.app.mapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spark.app.dto.FeedbackRequestDTO;
import com.spark.app.exception.performance_review.InvalidEmployeeIdException;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.Feedback;
import com.spark.app.repository.EmployeeProfileRepository;

@Component
public class FeedbackMapper {

    @Autowired
    private EmployeeProfileRepository employeeProfileRepository;

    public Feedback toEntity(FeedbackRequestDTO feedbackRequestDTO) {
        if (feedbackRequestDTO == null) {
            throw new IllegalArgumentException("FeedbackRequestDTO cannot be null");
        }

        Feedback feedback = new Feedback();

        EmployeeProfile fromEmployee = employeeProfileRepository.findById(feedbackRequestDTO.getFromEmployeeId())
                .orElseThrow(() -> new InvalidEmployeeIdException("From Employee not found"));

        EmployeeProfile toEmployee = employeeProfileRepository.findById(feedbackRequestDTO.getToEmployeeId())
                .orElseThrow(() -> new InvalidEmployeeIdException("To Employee not found"));

        feedback.setFromEmployee(fromEmployee);
        feedback.setToEmployee(toEmployee);
        feedback.setFeedbackType(feedbackRequestDTO.getFeedbackType());
        feedback.setDate(feedbackRequestDTO.getDate());
        feedback.setComments(feedbackRequestDTO.getComments());
        feedback.setReason(feedbackRequestDTO.getReason());

        return feedback;
    }
}
