package com.spark.app.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.spark.app.dto.DeleteFeedbackRequestDTO;
//import com.spark.app.dto.FeedbackDateRangeRequestDTO;
import com.spark.app.dto.FeedbackRequestDTO;
import com.spark.app.dto.FeedbackResponseDTO;
//import com.spark.app.dto.FeedbackUpdateRequestDTO;
import com.spark.app.service.FeedbackService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;

@Validated
@RestController
@CrossOrigin("*")
@RequestMapping("/feedback")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;

    // End point to add a new feedback
    @PostMapping("/addFeedback")
    public ResponseEntity<FeedbackResponseDTO> addFeedback(@Valid @RequestBody FeedbackRequestDTO feedbackRequestDTO) {
        var savedFeedback = feedbackService.addFeedback(feedbackRequestDTO);
        return new ResponseEntity<>(savedFeedback, HttpStatus.CREATED);
        
    }
    
    // End point to get feedback given by a specific employee
    @PostMapping("/getGivenFeedback")
    public ResponseEntity<List<FeedbackResponseDTO>> getGivenFeedback(@RequestBody FeedbackRequestDTO feedbackRequestDTO) {
        var feedbackList = feedbackService.viewGivenFeedback(feedbackRequestDTO.getFromEmployeeId());
        return new ResponseEntity<>(feedbackList, HttpStatus.OK);
    }

    // Delete Feedback 
    @DeleteMapping("/deleteFeedback")
    public ResponseEntity<String> deleteFeedback(@RequestBody DeleteFeedbackRequestDTO requestDTO) {
        feedbackService.deleteFeedback(requestDTO.getFeedbackId(), requestDTO.getFromEmployeeId());
        return new ResponseEntity<>("Feedback deleted successfully.", HttpStatus.OK);
    }


	/*
	 * // End point to get received feedback for a specific employee
	 * 
	 * @PostMapping("/getReceivedFeedback") public
	 * ResponseEntity<List<FeedbackResponseDTO>> getReceivedFeedback(@RequestBody
	 * FeedbackRequestDTO feedbackRequestDTO) { var feedbackList =
	 * feedbackService.viewReceivedFeedback(feedbackRequestDTO.getToEmployeeId());
	 * return new ResponseEntity<>(feedbackList, HttpStatus.OK); }
	 */

    


	/*
	 * //End point to update feedback
	 * 
	 * @PutMapping("/updateFeedback") public ResponseEntity<FeedbackResponseDTO>
	 * updateFeedback(@Valid @RequestBody FeedbackUpdateRequestDTO
	 * feedbackRequestDTO) { FeedbackResponseDTO updatedFeedback =
	 * feedbackService.updateFeedback( feedbackRequestDTO.getFeedbackId(),
	 * feedbackRequestDTO.getComments() );
	 * 
	 * return new ResponseEntity<>(updatedFeedback, HttpStatus.OK); }
	 */
    
    
	/*
	 * @PostMapping("/getFeedbackByDateRange") public
	 * ResponseEntity<List<FeedbackResponseDTO>> getFeedbackByDateRange(@RequestBody
	 * FeedbackDateRangeRequestDTO feedbackRequestDTO) { List<FeedbackResponseDTO>
	 * feedbackList = feedbackService.getFeedbackByDateRange(
	 * feedbackRequestDTO.getEmployeeId(), feedbackRequestDTO.getStartDate(),
	 * feedbackRequestDTO.getEndDate() );
	 * 
	 * return new ResponseEntity<>(feedbackList, HttpStatus.OK); }
	 */


    
	/*
	 * @PostMapping("/retrieveRecentFeedback") public
	 * ResponseEntity<FeedbackResponseDTO> retrieveRecentFeedback(@RequestBody
	 * FeedbackRequestDTO feedbackRequestDTO) { var recentFeedback =
	 * feedbackService.retrieveRecentFeedback(feedbackRequestDTO.getFromEmployeeId()
	 * ); return new ResponseEntity<>(recentFeedback, HttpStatus.OK); }
	 */

}

