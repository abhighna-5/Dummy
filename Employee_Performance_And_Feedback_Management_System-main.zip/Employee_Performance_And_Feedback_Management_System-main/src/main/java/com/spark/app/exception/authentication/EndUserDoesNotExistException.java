package com.spark.app.exception.authentication;

public class EndUserDoesNotExistException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public EndUserDoesNotExistException(String errorMessage) {
		super(errorMessage);
	}
}
