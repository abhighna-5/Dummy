package com.spark.app.controller;

import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spark.app.dto.EndUserDTO;
import com.spark.app.exception.authentication.EndUserDoesNotExistException;
import com.spark.app.security.EndUser;
import com.spark.app.security.EndUserService;
import com.spark.app.security.jwt.JWTUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/auth")
@CrossOrigin("*")
@Slf4j
public class AuthenticationController {
/**
 * Controller Responsible for Authentication 
 */
	
	// Dependencies are made final because, they do not change after initialization
	private final AuthenticationManager authenticationManager;
	
	private final JWTUtil jwtUtil;
	
	private final EndUserService endUserService;
	
	// Constructor Level injection: We do this to prevent object not to be in invalid state
	public AuthenticationController(AuthenticationManager authenticationManager, JWTUtil jwtUtil, EndUserService endUserService) {
		this.authenticationManager = authenticationManager;
		this.jwtUtil = jwtUtil;
		this.endUserService = endUserService;
	}
	
	@PostMapping("/login")
	public ResponseEntity<String> handleLogin(@RequestBody EndUserDTO credentials) throws AuthenticationException{
		/**
		 * Accepts and validates End User Credentials
		 * @param EndUserDTO - Contains credentials
		 * @return ResponseEntity<String> - JWT Token
		 */
		log.info("User {} made login request",credentials.getEmailAddress());
		Authentication auth = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(credentials.getEmailAddress(),credentials.getPassword()));
		
		UserDetails endUser = (UserDetails)auth.getPrincipal();
		String token = jwtUtil.generateJWT(endUser);
		log.info("User {} successfully logged in",credentials.getEmailAddress());
		return new ResponseEntity<>(token,HttpStatus.OK);
	}
	
	@PutMapping("/updatePassword")
	public ResponseEntity<String> updatePassword(@RequestBody EndUserDTO credentials){
		/**
		 * Update Password of an End User
		 * @param EndUserDTO - Contains updated credentials
		 * @return ResponseEntity<String> - Status message
		 */
		log.info("User {} requested for password updation",credentials.getEmailAddress());
		String returnMessage = null;
		boolean successFlag = false;
		// Check whether end user exist or not
		Optional<EndUser> container = endUserService.findByEmailAddress(credentials.getEmailAddress());
		if(container.isEmpty()) {
			log.error("User {} password updation request failed due to {}",credentials.getEmailAddress(),"EndUserDoesNotExistException");
			throw new EndUserDoesNotExistException("End User does not exist");
		}
		successFlag = endUserService.updatePassword(container.get(),credentials.getPassword());
		if(successFlag) {
			returnMessage = "success";
		}
		else {
			returnMessage = "failed";
		}
		log.info("User {} password updation request is {}",returnMessage,credentials.getEmailAddress());
		return new ResponseEntity<>(returnMessage,HttpStatus.NO_CONTENT);		
	}
	
	
	
}
