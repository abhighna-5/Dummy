package com.spark.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spark.app.dto.FeedbackRequestDTO;
import com.spark.app.dto.FeedbackResponseDTO;
import com.spark.app.exception.*;
import com.spark.app.exception.feedback.DuplicateFeedbackException;
import com.spark.app.exception.feedback.FeedbackNotFoundException;
import com.spark.app.exception.performance_review.InvalidEmployeeIdException;
import com.spark.app.exception.performance_review.UnauthorizedException;
import com.spark.app.mapper.FeedbackDTOMapper;
import com.spark.app.mapper.FeedbackMapper;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.Feedback;
import com.spark.app.repository.FeedbackRepository;
import com.spark.app.repository.EmployeeProfileRepository;
import com.spark.app.service.FeedbackService;

@Slf4j 
@Service
public class FeedbackServiceImpl implements FeedbackService {

    @Autowired
    private FeedbackRepository feedbackRepository;

    @Autowired
    private EmployeeProfileRepository employeeProfileRepository;

    @Autowired
    private FeedbackMapper feedbackMapper;

    @Autowired
    private FeedbackDTOMapper feedbackDTOMapper;
    
    @Override
    public FeedbackResponseDTO addFeedback(FeedbackRequestDTO feedbackRequestDTO) {
        long fromEmployeeId = feedbackRequestDTO.getFromEmployeeId();
        long toEmployeeId = feedbackRequestDTO.getToEmployeeId();
        log.info("Adding feedback from employee {} to employee {}", feedbackRequestDTO.getFromEmployeeId(), feedbackRequestDTO.getToEmployeeId());
        // Validate Employee IDs exist using findById()
        EmployeeProfile fromEmployee = employeeProfileRepository.findById(fromEmployeeId)
            .orElseThrow(() -> {
                log.error("Invalid fromEmployeeId: {}", fromEmployeeId);
                return new InvalidEmployeeIdException("Provide valid From Employee ID.");
            });

        EmployeeProfile toEmployee = employeeProfileRepository.findById(toEmployeeId)
            .orElseThrow(() -> {
                log.error("Invalid toEmployeeId: {}", toEmployeeId);
                return new InvalidEmployeeIdException("Provide valid To Employee ID.");
            });

        LocalDate currentDate = LocalDate.now(); // Auto-set the current date
        log.info("Checking for duplicate feedback entry on {}", currentDate);

        // Check for existing feedback
        if (feedbackRepository.existsByFromEmployeeEmployeeIdAndToEmployeeEmployeeIdAndDate(fromEmployeeId, toEmployeeId, currentDate)) {
            log.error("Duplicate feedback detected for employee {} to employee {} on {}", fromEmployeeId, toEmployeeId, currentDate);
            throw new DuplicateFeedbackException("Feedback for this employee and date already exists.");
        }

        log.info("Mapping DTO to entity and saving feedback...");
        Feedback feedback = feedbackMapper.toEntity(feedbackRequestDTO);

        // Set date if missing
        if (feedback.getDate() == null) {
            feedback.setDate(currentDate);
        }

        feedback = feedbackRepository.save(feedback);
        log.info("Feedback saved successfully with ID {}", feedback.getFeedbackId());

        return feedbackDTOMapper.toDto(feedback);
    }
    @Override
        public List<FeedbackResponseDTO> viewReceivedFeedback(long toEmployeeId) {
            log.info("Fetching received feedback for employeeId: {}", toEmployeeId);

            if (!employeeProfileRepository.existsById(toEmployeeId)) {
                log.error("Invalid employeeId: {}", toEmployeeId);
                throw new InvalidEmployeeIdException("Provide valid Employee ID.");
            }

            List<FeedbackResponseDTO> feedbackList = feedbackRepository.findByToEmployeeEmployeeId(toEmployeeId)
                    .stream()
                    .map(feedbackDTOMapper::toDto)
                    .collect(Collectors.toList());

            log.info("Total feedback received for employee {}: {}", toEmployeeId, feedbackList.size());
            return feedbackList;
        }

        @Override
        public List<FeedbackResponseDTO> viewGivenFeedback(long fromEmployeeId) {
            log.info("Fetching given feedback for employeeId: {}", fromEmployeeId);

            if (!employeeProfileRepository.existsById(fromEmployeeId)) {
                log.error("Invalid fromEmployeeId: {}", fromEmployeeId);
                throw new InvalidEmployeeIdException("Provide valid From Employee ID.");
            }

            List<FeedbackResponseDTO> feedbackList = feedbackRepository.findByFromEmployeeEmployeeId(fromEmployeeId)
                    .stream()
                    .map(feedbackDTOMapper::toDto)
                    .collect(Collectors.toList());

            log.info("Total feedback given by employee {}: {}", fromEmployeeId, feedbackList.size());
            return feedbackList;
        }

        @Override
        public void deleteFeedback(long feedbackId, long fromEmployeeId) {
            log.info("Attempting to delete feedback with ID {} by employee {}", feedbackId, fromEmployeeId);

            Feedback feedback = feedbackRepository.findById(feedbackId)
                    .orElseThrow(() -> {
                        log.error("Feedback with ID {} not found", feedbackId);
                        return new FeedbackNotFoundException("Feedback with ID " + feedbackId + " not found");
                    });

            if (feedback.getFromEmployee().getEmployeeId() != fromEmployeeId) {
                log.error("Unauthorized deletion attempt by employee {} for feedback {}", fromEmployeeId, feedbackId);
                throw new UnauthorizedException("Only the sender can delete feedback.");
            }

            feedbackRepository.delete(feedback);
            log.info("Feedback with ID {} successfully deleted by employee {}", feedbackId, fromEmployeeId);
        }
    


    
//    @Override
//    public List<FeedbackResponseDTO> viewReceivedFeedback(long toEmployeeId) {
//        if (!employeeProfileRepository.existsById(toEmployeeId)) {
//            throw new InvalidEmployeeIdException("Provide valid Employee ID.");
//        }
//
//        return feedbackRepository.findByToEmployeeEmployeeId(toEmployeeId)
//                .stream()
//                .map(feedbackDTOMapper::toDto)
//                .collect(Collectors.toList());
//    }
//
//
//    @Override
//    public List<FeedbackResponseDTO> viewGivenFeedback(long fromEmployeeId) {
//        if (!employeeProfileRepository.existsById(fromEmployeeId)) {
//            throw new InvalidEmployeeIdException("Provide valid From Employee ID.");
//        }
//
//        return feedbackRepository.findByFromEmployeeEmployeeId(fromEmployeeId)
//                .stream()
//                .map(feedbackDTOMapper::toDto)
//                .collect(Collectors.toList());
//    }
//
//    @Override
//    public void deleteFeedback(long feedbackId, long fromEmployeeId) {
//        Feedback feedback = feedbackRepository.findById(feedbackId)
//                .orElseThrow(() -> new FeedbackNotFoundException("Feedback with ID " + feedbackId + " not found"));
//
//        if (feedback.getFromEmployee().getEmployeeId() != fromEmployeeId) {
//            throw new UnauthorizedException("Only the sender can delete feedback.");
//        }
//
//        feedbackRepository.delete(feedback);
//    }

//    @Override
//    public FeedbackResponseDTO updateFeedback(long feedbackId, String comments) {
//        Feedback feedback = feedbackRepository.findById(feedbackId)
//                .orElseThrow(() -> new FeedbackNotFoundException("Feedback with ID " + feedbackId + " not found"));
//
//        feedback.setComments(comments);
//        feedback.setDate(LocalDate.now());
//        feedbackRepository.save(feedback);
//
//        return feedbackDTOMapper.toDto(feedback);
//    }


//    @Override
//    public FeedbackResponseDTO retrieveRecentFeedback(long employeeId) {
//        LocalDate recentDate = feedbackRepository.recentFeedbackDate(employeeId);
//        if (recentDate == null) {
//            throw new FeedbackNotFoundException("No feedback found for Employee ID " + employeeId);
//        }
//
//        String recentComments = feedbackRepository.recentFeedbackComments(employeeId, recentDate);
//        return new FeedbackResponseDTO(0, 0, employeeId, recentDate, recentComments);
//    }


    @Override
    public List<FeedbackResponseDTO> getFeedbackByDateRange(long employeeId, LocalDate startDate, LocalDate endDate) {
        log.info("Fetching feedback for employeeId {} within date range {} to {}", employeeId, startDate, endDate);

        // ✅ Validate employee existence
        if (!employeeProfileRepository.existsById(employeeId)) {
            log.error("Invalid employeeId: {}", employeeId);
            throw new InvalidEmployeeIdException("Provide valid Employee ID.");
        }

        // ✅ Validate date range
        if (startDate.isAfter(endDate)) {
            log.error("Invalid date range: startDate {} is after endDate {}", startDate, endDate);
            throw new IllegalArgumentException("Start date must be before or equal to End date.");
        }

        List<FeedbackResponseDTO> feedbackList = feedbackRepository.findByToEmployeeEmployeeId(employeeId)
                .stream()
                .filter(f -> !f.getDate().isBefore(startDate) && !f.getDate().isAfter(endDate))
                .map(feedbackDTOMapper::toDto)
                .collect(Collectors.toList());

        log.info("Total feedback entries found for employee {} in range {} - {}: {}", employeeId, startDate, endDate, feedbackList.size());

        return feedbackList;
    }



    
//    @Override
//    public List<FeedbackResponseDTO> getFeedbackByDateRange(long employeeId, LocalDate startDate, LocalDate endDate) {
//        if (!employeeProfileRepository.existsById(employeeId)) { // ✅ Check for valid employee
//            throw new InvalidEmployeeIdException("Provide valid Employee ID.");
//        }
//
//        // ✅ Validate date range
//        if (startDate.isAfter(endDate)) {
//            throw new IllegalArgumentException("Start date must be before or equal to End date.");
//        }
//        
//        return feedbackRepository.findByToEmployeeEmployeeId(employeeId)
//                .stream()
//                .filter(f -> !f.getDate().isBefore(startDate) && !f.getDate().isAfter(endDate))
//                .map(feedbackDTOMapper::toDto)
//                .collect(Collectors.toList());
//    }


}
