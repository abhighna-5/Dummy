package com.spark.app.model;

public enum Department {
	HR,ADM
}
