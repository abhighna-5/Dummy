package com.spark.app.exception.performance_review;

public class DuplicateReviewException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public DuplicateReviewException(String message) {
		super(message);
	}
}
