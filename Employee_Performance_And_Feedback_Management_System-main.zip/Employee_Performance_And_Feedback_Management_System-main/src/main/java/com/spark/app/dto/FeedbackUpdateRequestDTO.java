/*
 * package com.spark.app.dto;
 * 
 * import jakarta.validation.constraints.NotBlank; import
 * jakarta.validation.constraints.NotNull; import lombok.Getter; import
 * lombok.Setter;
 * 
 * @Getter
 * 
 * @Setter public class FeedbackUpdateRequestDTO {
 * 
 * @NotNull(message = "Feedback ID is required") private Long feedbackId;
 * 
 * @NotBlank(message = "Comments cannot be empty") private String comments; }
 */