package com.spark.app.exception.employee_profile;

public class DuplicateEmployeeProfileException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public DuplicateEmployeeProfileException(String errorMessage) {
		super(errorMessage);
	}

}
