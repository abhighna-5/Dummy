package com.spark.app.model;


import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class UpdateRequest {
	
	
	@Id
	@EmbeddedId
	private UpdateRequestId requestId;
	
	private String name;
	@Enumerated(EnumType.STRING)
	private Department department;
	@Enumerated(EnumType.STRING)
	private Role role;
	private String contactDetails;
	
	@Enumerated(EnumType.STRING)
	private ApprovalStatus status= ApprovalStatus.STATUS_PENDING;


}
