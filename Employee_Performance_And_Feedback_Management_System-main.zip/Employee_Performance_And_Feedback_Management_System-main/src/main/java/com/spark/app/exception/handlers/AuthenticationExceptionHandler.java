package com.spark.app.exception.handlers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.spark.app.exception.authentication.EndUserAlreadyExistException;
import com.spark.app.exception.authentication.EndUserDoesNotExistException;

@RestControllerAdvice
public class AuthenticationExceptionHandler {
/**
 * Handles Exceptions causes in the process of Authentication
 */
	
	@ExceptionHandler(exception=BadCredentialsException.class)
	public ResponseEntity<Map<String,String>> handleBadCredentialsException(BadCredentialsException exception, WebRequest request){
		/**
		 * Handles BadCredentialsException
		 * BadCredentialsException Occurs When Wrong Credentials are Provided
		 */
		Map<String,String> payload = buildPayload(
				"Bad Credentials used for Authentication",
				"Use correct credentials to login",
				exception.getMessage());
		
		return new ResponseEntity<>(payload,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(exception=DisabledException.class)
	public ResponseEntity<Map<String,String>> handleEndUserDisabledException(DisabledException exception, WebRequest request){
		/**
		 * Handles User DisabledException
		 * DisabledException occurs when User do not have their credentials activated
		 */
		Map<String,String> payload = buildPayload(
				"User is not Activated",
				"Activate credentials to login",
				exception.getMessage());

		return new ResponseEntity<>(payload,HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler(exception=EndUserDoesNotExistException.class)
	public ResponseEntity<Map<String,String>> handleEndUserDoesNotExistException(EndUserDoesNotExistException exception, WebRequest request){
		/**
		 * Handles EndUserDoesNotExistException
		 * EndUserDoesNotExistException Occurs When End User do not exist with the given email
		 */
		Map<String,String> payload = buildPayload(
				"End User do not Exist",
				"Use correct details",
				exception.getMessage());
	
		return new ResponseEntity<>(payload,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(exception=EndUserAlreadyExistException.class)
	public ResponseEntity<Map<String,String>> handleEndUserAlreadyExistException(EndUserAlreadyExistException exception, WebRequest request){
		/**
		 * Handles EndUserAlreadyExistException
		 * EndUserAlreadyExistException Occurs When End User already exist with the given email
		 */
		Map<String,String> payload = buildPayload(
				"End User Already Exists",
				"Cannot register the end user",
				exception.getMessage());

		return new ResponseEntity<>(payload,HttpStatus.BAD_REQUEST);
	}
	
	private Map<String,String> buildPayload(String payLoadTitle, String payLoadMessage, String payLoadException){
		/**
		 * Builds Payload with title, message and exception message
		 * @param payLoadTitle - title of the payload
		 * @param payLoadMessage - message to send with payload
		 * @param payLoadException - exception message to send payload
		 * @return Map<String,String> - Constructed Payload
		 */
		Map<String,String> payload = new HashMap<>();
		payload.put("title", payLoadTitle);
		payload.put("message", payLoadMessage);
		payload.put("exception", payLoadException);
		return payload;
	}
}
