package com.spark.app.exception.handlers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.spark.app.exception.goal_management.GoalAlreadyAssignedException;
import com.spark.app.exception.goal_management.GoalNotFoundException;
import com.spark.app.exception.goal_management.InvalidGoalDataException;
import com.spark.app.exception.goal_management.InvalidGoalStateException;

@RestControllerAdvice
public class GoalManagementExceptionHandler {
	@ExceptionHandler(GoalNotFoundException.class)
    public ResponseEntity<String> handleGoalNotFoundException(GoalNotFoundException ex, WebRequest request) {
        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }
	
	@ExceptionHandler(GoalAlreadyAssignedException.class)
    public ResponseEntity<String> handleGoalAlreadyAssignedException(GoalAlreadyAssignedException ex, WebRequest request) {
        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }
	
	@ExceptionHandler(InvalidGoalDataException.class)
	public ResponseEntity<String> handleInvalidGoalDataException(InvalidGoalDataException ex, WebRequest request) {
	    return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(InvalidGoalStateException.class)
    public ResponseEntity<String> handleInvalidGoalStateException(InvalidGoalStateException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }

}
