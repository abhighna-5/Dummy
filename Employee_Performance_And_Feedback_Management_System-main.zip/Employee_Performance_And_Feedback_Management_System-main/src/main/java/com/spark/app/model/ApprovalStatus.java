package com.spark.app.model;

public enum ApprovalStatus {

	STATUS_PENDING, STATUS_APPROVED, STATUS_REJECTED;
}
