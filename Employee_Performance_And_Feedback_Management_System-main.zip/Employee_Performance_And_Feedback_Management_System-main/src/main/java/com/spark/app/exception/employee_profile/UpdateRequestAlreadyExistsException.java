package com.spark.app.exception.employee_profile;

public class UpdateRequestAlreadyExistsException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public UpdateRequestAlreadyExistsException(String errorMessage) {
		super(errorMessage);
	}

}
