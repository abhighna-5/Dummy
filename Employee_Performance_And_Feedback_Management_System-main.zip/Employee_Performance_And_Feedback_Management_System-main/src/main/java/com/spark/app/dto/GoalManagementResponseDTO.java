package com.spark.app.dto;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.spark.app.model.ProgressStatus;

import lombok.Data;

@Data

public class GoalManagementResponseDTO {
	
	private long goalId;
	@JsonFormat(pattern="dd-MM-yyyy")
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private LocalDate date;
	private String goalDescription;
	private ProgressStatus progressStatus;
	private long employeeId;
}
