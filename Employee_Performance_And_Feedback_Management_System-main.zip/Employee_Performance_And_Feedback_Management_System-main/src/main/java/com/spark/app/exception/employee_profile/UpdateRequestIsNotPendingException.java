package com.spark.app.exception.employee_profile;

public class UpdateRequestIsNotPendingException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public UpdateRequestIsNotPendingException(String errorMessage) {
		super(errorMessage);
	}

}
