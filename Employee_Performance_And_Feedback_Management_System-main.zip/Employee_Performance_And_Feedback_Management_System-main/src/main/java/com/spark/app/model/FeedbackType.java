package com.spark.app.model;

public enum FeedbackType {
    PEER,
    SUPERIOR, 
    SUBORDINATE 
}
