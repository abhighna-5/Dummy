package com.spark.app.security;

import com.spark.app.model.Role;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class EndUser {
/**
 * Class that represents End User interacting with the application
 */
	@Id
	private String emailAddress;
	private String password;
	private boolean isActivated;
	@Enumerated(value = EnumType.STRING)
	private Role role;
	
}
