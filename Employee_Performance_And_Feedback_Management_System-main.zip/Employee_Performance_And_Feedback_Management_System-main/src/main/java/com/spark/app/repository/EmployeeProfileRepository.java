package com.spark.app.repository;

import com.spark.app.model.Department;
import com.spark.app.model.EmployeeProfile;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeProfileRepository extends JpaRepository<EmployeeProfile, Long> {

	List<EmployeeProfile> findByDepartment(Department department);

	Optional<EmployeeProfile> findByContactDetails(String contactDetails);
	
}
