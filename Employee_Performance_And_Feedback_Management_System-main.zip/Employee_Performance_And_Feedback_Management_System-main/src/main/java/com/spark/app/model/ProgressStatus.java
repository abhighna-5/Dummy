package com.spark.app.model;

public enum ProgressStatus {
	NOT_STARTED,IN_PROGRESS,COMPLETED,UNDER_REVIEW
}
