package com.spark.app.mapper;

import org.springframework.stereotype.Component;

import com.spark.app.dto.ReportResponseDTO;
import com.spark.app.model.Report;

@Component
public class ReportResponseDTOMapper 
{

	public ReportResponseDTO convertToDTO(Report report)
	{
		 ReportResponseDTO responseDTO = new ReportResponseDTO();
		 
	     responseDTO.setReportId(report.getReportId());
	     responseDTO.setEmployeeId(report.getEmployeeId().getEmployeeId());
	     responseDTO.setPerformanceSummary(report.getPerformanceSummary());
	     responseDTO.setFeedbackSummary(report.getFeedbackSummary());
	     responseDTO.setReportDate(report.getReportDate());
	     return responseDTO;
		
	}
}
