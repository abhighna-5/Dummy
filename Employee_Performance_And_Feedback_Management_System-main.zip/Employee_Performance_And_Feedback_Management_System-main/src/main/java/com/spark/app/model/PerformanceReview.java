package com.spark.app.model;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Data
@Entity
public class PerformanceReview {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long reviewId;
	@ManyToOne
	@JoinColumn(name = "employee_id")
	private EmployeeProfile employeeId;
	@ManyToOne
	@JoinColumn(name = "manager_id")
	private EmployeeProfile managerId;
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private LocalDate date;
	private float performanceScore;
	private String feedback;
}
