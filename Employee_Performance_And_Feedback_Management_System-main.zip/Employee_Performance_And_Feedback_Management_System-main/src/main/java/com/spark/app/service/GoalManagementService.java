package com.spark.app.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.spark.app.dto.GoalManagementRequestDTO;
import com.spark.app.dto.GoalManagementResponseDTO;

import com.spark.app.model.GoalManagement;

@Service
public interface GoalManagementService {
	
	
	GoalManagementResponseDTO createGoal(GoalManagementRequestDTO goalManagementDTO);
	//GoalManagementResponseDTO assignGoal(GoalManagementRequestDTO goalManagementDTO);
	List<GoalManagementResponseDTO> getGoalsByEmployeeId(Long employeeId);
	GoalManagementResponseDTO updateGoalDeadline(Long goalId,LocalDate newDeadLine);
	void deleteGoalById(Long goalId);
	//GoalManagementResponseDTO updateProgressStatus(Long goalId,GoalManagementRequestDTO requestDTO);
	GoalManagementResponseDTO markAsComplete(long goalId);
	Optional<GoalManagement> findGoalById(long goalId);
	List<GoalManagementResponseDTO> getAllGoalsUnderReview();
	//List<GoalManagementResponseDTO> approvePendingRequest();

	List<GoalManagementResponseDTO> getGoalsByEmployeeAndDateRange(long employeeId, LocalDate startDate,
			LocalDate endDate);
	List<GoalManagementResponseDTO> getAllGoals();
	GoalManagementResponseDTO approveOrRejectGoal(Long goalId, boolean approve);
	

}
