package com.spark.app.model;

public enum FeedbackCommentType {
    GOOD, BAD, AVERAGE
}
