package com.spark.app.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.spark.app.dto.GoalManagementRequestDTO;
import com.spark.app.dto.GoalManagementResponseDTO;
import com.spark.app.exception.goal_management.GoalNotFoundException;
import com.spark.app.model.GoalManagement;
import com.spark.app.service.GoalManagementService;

@RestController
@CrossOrigin("*")
@RequestMapping("/goalManagement")
public class GoalManagementController {
	@Autowired
	private GoalManagementService goalManagementService;
	

	
	@PostMapping("/createGoal")
	public ResponseEntity<GoalManagementResponseDTO> assignGoal(@RequestBody GoalManagementRequestDTO goalManagementDTO) {
	
		GoalManagementResponseDTO response=goalManagementService.createGoal(goalManagementDTO);
		return new ResponseEntity<>(response,HttpStatus.CREATED);
	}
	
	@GetMapping("/getGoalsForEmployee/{employeeId}")
	public ResponseEntity<List<GoalManagementResponseDTO>> getEmployeeGoals(@PathVariable Long employeeId){
		List<GoalManagementResponseDTO> goals=goalManagementService.getGoalsByEmployeeId(employeeId);
		return ResponseEntity.ok(goals);
	}
	
	
	@PutMapping("/updateDeadline/{goalId}")
	public ResponseEntity<GoalManagementResponseDTO> updateGoalDeadline(@PathVariable Long goalId,@RequestBody Map<String,String> request){
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate newDeadline=LocalDate.parse(request.get("newDeadLine"),formatter);
		GoalManagementResponseDTO response=goalManagementService.updateGoalDeadline(goalId, newDeadline);
		return ResponseEntity.ok(response);
	}
	
	@DeleteMapping("/deleteGoal/{goalId}")
	public ResponseEntity<String> deleteGoal(@PathVariable Long goalId){
		goalManagementService.deleteGoalById(goalId);
		return ResponseEntity.ok("Goal deleted successfully");

	}
	@GetMapping("/getAllGoals")
	public ResponseEntity<List<GoalManagementResponseDTO>> getAllGoals(){
		List<GoalManagementResponseDTO> goals=goalManagementService.getAllGoals();
		return ResponseEntity.ok(goals);
	}
	

	@PutMapping("/markAsComplete/{goalId}")
	public ResponseEntity<GoalManagementResponseDTO> markGoalAsComplete(@PathVariable Long goalId){
		Optional<GoalManagement> container = goalManagementService.findGoalById(goalId);
		if(container.isEmpty()) throw new GoalNotFoundException("Goal Not Found");
		// Goal Exists
		GoalManagementResponseDTO updatedGoal = goalManagementService.markAsComplete(goalId);
		return new ResponseEntity<GoalManagementResponseDTO>(updatedGoal,HttpStatus.NO_CONTENT);
	}
	
	
	@GetMapping("/getAllGoalsUnderReview")
	public ResponseEntity<List<GoalManagementResponseDTO>> getAllGoalsUnderReview(){
		List<GoalManagementResponseDTO> container = goalManagementService.getAllGoals();
		if(container.isEmpty()) throw new GoalNotFoundException("Goal Not Found");
		// Goal Exists
		List<GoalManagementResponseDTO> updatedGoals = goalManagementService.getAllGoalsUnderReview();
		return ResponseEntity.ok(updatedGoals);
	}


	@PutMapping("/approveOrRejectGoal/{goalId}")
    public ResponseEntity<GoalManagementResponseDTO> approveOrRejectGoal(
            @PathVariable Long goalId,
            @RequestParam boolean approve) {
        
        GoalManagementResponseDTO updatedGoal = goalManagementService.approveOrRejectGoal(goalId, approve);
        
        return new ResponseEntity<>(updatedGoal, HttpStatus.OK);
    }
}
