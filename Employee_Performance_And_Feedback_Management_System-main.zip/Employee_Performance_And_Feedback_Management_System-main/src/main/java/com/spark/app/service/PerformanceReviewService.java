package com.spark.app.service;
 
import java.time.LocalDate;

import java.util.List;
 
import com.spark.app.dto.PerformanceReviewRequestDTO;

import com.spark.app.dto.PerformanceReviewResponseDTO;
 
 
public interface PerformanceReviewService {

	/**
	 * 
	 * Methods need to be implemented in DAO
	 * 
	 */

	PerformanceReviewResponseDTO addPerformanceReview(PerformanceReviewRequestDTO performanceReviewRequestDTO);
	
	List<PerformanceReviewResponseDTO> viewReviewsEmployee(long employeeId);
	
	List<PerformanceReviewResponseDTO> viewReviewsManager(long managerId);
	
	void deleteReview(long reviewId, long managerId);
	
	PerformanceReviewResponseDTO updateReview(long reviewId, long managerId, LocalDate date);
	
	PerformanceReviewResponseDTO providePerformanceScoreAndFeedback(long reviewId, long managerId, float productivity, float teamwork, float skillProficiency, String feedback);

}
 