package com.spark.app.security;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EndUserRepository extends JpaRepository<EndUser, String>{
	/**
	 * Repository for End User Entity
	 */
}
