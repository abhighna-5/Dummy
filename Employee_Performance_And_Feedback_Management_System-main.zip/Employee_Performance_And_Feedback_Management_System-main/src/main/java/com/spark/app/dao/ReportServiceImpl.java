package com.spark.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spark.app.repository.ReportRepository;
import com.spark.app.dto.EmployeeProfileResponseDTO;
import com.spark.app.dto.FeedbackResponseDTO;
import com.spark.app.dto.GoalManagementResponseDTO;
import com.spark.app.dto.PerformanceReviewResponseDTO;
import com.spark.app.dto.ReportHRResponseDTO;
import com.spark.app.dto.ReportResponseDTO;
import com.spark.app.exception.employee_profile.EmployeeProfileNotFoundException;
import com.spark.app.exception.report.NotHRManagerException;
import com.spark.app.exception.report.NotProjectManagerException;
import com.spark.app.mapper.ReportResponseDTOMapper;
import com.spark.app.model.FeedbackCommentType;
import com.spark.app.model.PerformanceReview;
import com.spark.app.model.ProgressStatus;
import com.spark.app.model.Report;
import com.spark.app.model.Role;
import com.spark.app.service.ReportService;

import lombok.extern.slf4j.Slf4j;

import com.spark.app.service.EmployeeProfileService;
import com.spark.app.service.FeedbackService;
import com.spark.app.service.GoalManagementService;
import com.spark.app.service.PerformanceReviewService;

@Slf4j
@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    private ReportRepository reportRepository;
    
    @Autowired
    private PerformanceReviewService performanceReviewService;
	
    @Autowired
    private ReportResponseDTOMapper responseDTOMapper;

    @Autowired 
    private GoalManagementService goalManagementService;
    
    @Autowired
    private FeedbackService feedbackService;
    
    @Autowired
    private EmployeeProfileService employeeProfileService;
    
    public ReportResponseDTO createReport(PerformanceReview performanceReview)
    {
    	long employeeId = performanceReview.getEmployeeId().getEmployeeId();
    	LocalDate reviewDate = performanceReview.getDate();
         
    	double goalCompletionScore = calculateGoalCompletionScore(employeeId, reviewDate);

        Report report = new Report();
        report.setEmployeeId(performanceReview.getEmployeeId());
        report.setPerformanceSummary("Performance Score: " + performanceReview.getPerformanceScore() + " ; "+"Review Feedback: " + performanceReview.getFeedback() +" ; "+"Goal Completion Score: " + goalCompletionScore + "%");
        report.setFeedbackSummary(summarizeFeedback(employeeId,reviewDate));
        reportRepository.save(report);
        
        log.info("Report created and saved for employeeId: {}",employeeId);
        
        return responseDTOMapper.convertToDTO(report);
        
    }
    
    
    @Override
    public String summarizeFeedback(long employeeId, LocalDate reviewDate) 
    {
    	log.debug("Starting feedback summarization for employeeId: {}, reviewDate: {}", employeeId, reviewDate);
    	
        List<FeedbackResponseDTO> feedbacks;

        Report latestReport = reportRepository.findTopByEmployeeIdEmployeeIdOrderByReportDateDesc(employeeId);

        LocalDate startDate = (latestReport != null) 
            ? latestReport.getReportDate() 
            : LocalDate.MIN; //first report: consider all reports up to reviewDate

        log.debug("Feedback date range: {} to {}", startDate, reviewDate);
        
        feedbacks = feedbackService.getFeedbackByDateRange(employeeId, startDate, reviewDate);
		
		long goodCount = feedbacks.stream().filter(feedback-> feedback.getComments().equals(feedbackEnumToString(FeedbackCommentType.GOOD))).count();
		long averageCount = feedbacks.stream().filter(feedback-> feedback.getComments().equals(feedbackEnumToString(FeedbackCommentType.AVERAGE))).count();
		long badCount = feedbacks.stream().filter(feedback->feedback.getComments().equals(feedbackEnumToString(FeedbackCommentType.BAD))).count();
		
		String result = "Good: "+goodCount+", Average: "+averageCount+", Bad: "+badCount;
		
		log.info("Feedback summary generated for employeeId: {}", employeeId);
		
    	return result;
    }


    private String feedbackEnumToString(FeedbackCommentType type) 
    {
    	String ans = null;
    	if(type==FeedbackCommentType.GOOD) ans = "GOOD";
    	else if(type==FeedbackCommentType.AVERAGE) ans = "AVERAGE";
    	else if(type==FeedbackCommentType.BAD) ans = "BAD";
    	
    	return ans;
    }
   
	
    @Override
    public double calculateGoalCompletionScore(long employeeId, LocalDate reviewDate) 
    {
    	log.debug("Calculating goal completion score for employeeId: {}, reviewDate: {}", employeeId, reviewDate);
    	
        Report latestReport = reportRepository.findTopByEmployeeIdEmployeeIdOrderByReportDateDesc(employeeId);
        
        LocalDate startDate = (latestReport != null) 
            ? latestReport.getReportDate() 
            : LocalDate.MIN; // First review: consider all goals up to reviewDate

        log.debug("Goal evaluation date range: {} to {}", startDate, reviewDate);
        
        // Fetch goals in the date range
        List<GoalManagementResponseDTO> goals = goalManagementService.getGoalsByEmployeeAndDateRange(employeeId, startDate, reviewDate);

        long totalGoals = goals.size();
        
        //for debugging
    
        for (GoalManagementResponseDTO goal : goals) 
    	{
    		System.out.println("Goal ID: " + goal.getGoalId() + ", Status: " + goal.getProgressStatus());
    	}
    	
  		System.out.println("Total Goals: " + goals.size());
        long completedGoals = goals.stream()
            .filter(goal -> goal.getProgressStatus() == ProgressStatus.COMPLETED)
            .count();
        
        log.debug("Total goals found: {}, Completed goals: {}", totalGoals, completedGoals);

        double goalScore = totalGoals == 0 ? 0 : (double) completedGoals / totalGoals * 100;
        goalScore = Math.round(goalScore*100.0)/100.0;
        
        log.info("Goal completion score generated for employeeId: {}", employeeId);
        
        return goalScore;
    }

    @Override
   	public List<ReportResponseDTO> viewReportsByEmployee(long employeeId)
   	{
    	log.debug("Fetching reports for employeeId: {}", employeeId);
    	
       	Optional<EmployeeProfileResponseDTO> container= employeeProfileService.findEmployeeProfileById(employeeId);
       	if(container.isEmpty())
       	{	
       		log.error("Employee profile not found for employeeId: {}", employeeId);
       		throw new EmployeeProfileNotFoundException("Employee doesn't exist");
       	}
       	
   		List<ReportResponseDTO> reports = reportRepository.findByEmployeeIdEmployeeId(employeeId)
   				.stream()
   				.map(report->responseDTOMapper.convertToDTO(report))
   				.collect(Collectors.toList());
   		
   		log.info("Found {} reports for employeeId: {}", reports.size(), employeeId);
   		
   		return reports;
   	}
	
	@Override
	public List<ReportHRResponseDTO> viewReportsByHRId(long employeeId) 
	{

		log.debug("HR with employeeId {} requested to view reports of all other employees.", employeeId);

		Optional<EmployeeProfileResponseDTO> container= employeeProfileService.findEmployeeProfileById(employeeId);
		EmployeeProfileResponseDTO hr = container.orElseThrow(()-> new EmployeeProfileNotFoundException("Employee doesn't exist"));
	

		if (hr.getRole() != Role.HR_MANAGER) 
		{
			log.error("Access denied: Employee with ID {} attempted to view reports but is not an HR Manager.", employeeId);
			throw new NotHRManagerException("Not an HR Manager. Access not allowed.");
		}
		
		log.info("HR Manager with employeeId {} verified.", employeeId);
		
		List<EmployeeProfileResponseDTO> employees = employeeProfileService.retrieveAllTheEmployeeProfiles();
		
		// Fetch reports for all employees
	    List<ReportHRResponseDTO> reportList = employees.stream()
	    		.filter(employee -> employee.getEmployeeId() != employeeId) 
	            .map(employee -> {
	                List<PerformanceReviewResponseDTO> reviewResponses = performanceReviewService.viewReviewsEmployee(employee.getEmployeeId());
	                double averageScore = reviewResponses.stream()
	                 
	                        .mapToDouble(review -> review.getPerformanceScore())
	                        .average()
	                        .orElse(0.0);

	                return new ReportHRResponseDTO(employee.getEmployeeId(), employee.getName(), averageScore);
	            })
	            .sorted((r1, r2) -> Double.compare(r2.getAverageScore(), r1.getAverageScore()))
	            .collect(Collectors.toList());
	    
	    log.info("HR with employeeId {} successfully retrieved {} employee reports.", employeeId, reportList.size());

	    return reportList;
	}
	
	
	@Override
	public List<ReportResponseDTO> viewReportsByManagerId(long employeeId) 
	{

		log.debug("Project Manager with employeeId {} requested to view team member reports.", employeeId);

		Optional<EmployeeProfileResponseDTO> container= employeeProfileService.findEmployeeProfileById(employeeId);
		EmployeeProfileResponseDTO manager = container.orElseThrow(()-> new EmployeeProfileNotFoundException("Employee doesn't exist"));

		if (manager.getRole() != Role.PROJECT_MANAGER) 
		{
			log.error("Access denied: Employee with ID {} attempted to view team reports but is not a Project Manager.", employeeId);
			throw new NotProjectManagerException("Not an HR Manager. Access not allowed.");
		}

		log.info("Project Manager with employeeId {} verified.", employeeId);

		List<EmployeeProfileResponseDTO> teamMembers = employeeProfileService.findEmployeesByDepartment(manager.getDepartment());

		List<Long> idList =  teamMembers.stream()
				.filter(employee -> employee.getEmployeeId() != employeeId)
				.map(employee-> employee.getEmployeeId()).
				collect(Collectors.toList());
				
		List<Report> reports = reportRepository.findByEmployeeIdEmployeeIdIn(idList);
		
		log.info("Retrieved {} reports for Project Manager with employeeId {}", reports.size(), employeeId);

		return reports.stream()
				.map(report -> responseDTOMapper.convertToDTO(report))
				.collect(Collectors.toList());
	}
	
	
	
}

/*
 * 
 		long totalCount = feedbacks.size();
		double oldRating = (goodCount - badCount)/totalCount;
		double scaledRating = ((oldRating+1)/2)*5; //to scale the rating between 1 to 5
		
		String result = "";

		if (scaledRating >= 0 && scaledRating < 1) {
		    result = "Very Bad";
		} else if (scaledRating >= 1 && scaledRating < 2) {
		    result = "Bad";
		} else if (scaledRating >= 2 && scaledRating < 3) {
		    result = "Average";
		} else if (scaledRating >= 3 && scaledRating < 4) {
		    result = "Good";
		} else if (scaledRating >= 4 && scaledRating <= 5) {
		    result = "Excellent";
		} 
 */
/*
 Map<String,Long> result =  new TreeMap<String,Long>();
		result.put("Good Feedbacks Count", goodCount);
		result.put("Average Feedbacks Count",averageCount);
		result.put("Bad Feedbacks Count",badCount);
*/
