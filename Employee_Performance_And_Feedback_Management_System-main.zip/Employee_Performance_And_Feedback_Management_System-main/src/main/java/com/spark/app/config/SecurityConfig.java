package com.spark.app.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.spark.app.security.EndUserUtil;
import com.spark.app.security.jwt.JWTFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	/**
	 * Class Responsible for Authentication and Authorization
	 */
	
	// Declaring String literals as constants for better coding standard
	private static final String HR_MANAGER = "HR_MANAGER";
	private static final String EMPLOYEE = "EMPLOYEE";
	private static final String PROJECT_MANAGER = "PROJECT_MANAGER";
	
	private EndUserUtil endUserUtilService;
	
	private JWTFilter jwtFilter;
	
	public SecurityConfig(EndUserUtil endUserUtilService, JWTFilter jwtFilter) {
		this.endUserUtilService = endUserUtilService;
		this.jwtFilter = jwtFilter;
	}
    @Bean
	SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
		/**
		 * Creates a Security Filter Chain which allow/block requests for an End User based on Authorities
		 */
		// Configuring HttpSecurity
		httpSecurity.csrf(
				csrf->csrf.disable())
		.authorizeHttpRequests(
				auth -> auth
				.requestMatchers("/auth/**").permitAll()
				.requestMatchers("/employee-profile/addMultiple").permitAll()//only for testing
				.requestMatchers("/employee-profile/updateOne").permitAll()
				.requestMatchers("/employee-profile/**").hasRole(HR_MANAGER)
				.requestMatchers("/reviews/getReviewsEmployee").hasRole(EMPLOYEE)
				.requestMatchers("/reviews/**").hasRole(PROJECT_MANAGER)
				.requestMatchers("/goalManagement/getGoalsForEmployee").hasAnyRole(EMPLOYEE,HR_MANAGER)
				.requestMatchers("/goalManagement/markAsComplete").hasRole(EMPLOYEE)
				.requestMatchers("/goalManagement/**").hasRole(PROJECT_MANAGER)
				.requestMatchers("/reports/employee").permitAll()
				.requestMatchers("/reports/hr").hasRole(HR_MANAGER)
				.requestMatchers("/reports/manager").hasRole(PROJECT_MANAGER)
				.requestMatchers("/feedback/**").permitAll()

				.anyRequest().authenticated()
				).sessionManagement(
						sm->sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
						);
		httpSecurity.addFilterBefore(jwtFilter,UsernamePasswordAuthenticationFilter.class);
		return httpSecurity.build();
		
	}
	
    @Bean
	AuthenticationManager authenticationManager(HttpSecurity httpSecurity, PasswordEncoder encoder) throws Exception{
		/**
		 * Creates an Authentication Manager with configuration Set
		 */
    	
    	return httpSecurity.getSharedObject(AuthenticationManagerBuilder.class)
				.userDetailsService(endUserUtilService)
				.passwordEncoder(encoder)
				.and()
				.build();		
	}
	
	@Bean
	PasswordEncoder passwordEncoder() {
		/**
		 * Returns Bean of PasswordEncoder to encode password using cryptographic algorithms
		 */
		return new BCryptPasswordEncoder();
	}

}