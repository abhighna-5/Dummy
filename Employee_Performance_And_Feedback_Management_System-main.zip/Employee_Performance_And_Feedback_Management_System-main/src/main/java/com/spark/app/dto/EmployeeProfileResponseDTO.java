package com.spark.app.dto;

import com.spark.app.model.Department;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.Role;

import lombok.Data;

@Data
public class EmployeeProfileResponseDTO {
/**
 * DTO For Employee Profile Response
 */
	private long employeeId;
	private String name;
	private String contactDetails;
	private Department department;
	private Role role;
	
	public EmployeeProfile toEntity() {
		EmployeeProfile entity = new EmployeeProfile();
		entity.setContactDetails(contactDetails);
		entity.setDepartment(department);
		entity.setEmployeeId(employeeId);
		entity.setName(name);
		entity.setRole(role);
		return entity;
	}
}
