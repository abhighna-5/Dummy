package com.spark.app.service;

import java.util.List;
import java.util.Optional;

import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.UpdateRequest;
import com.spark.app.model.UpdateRequestId;

public interface UpdateRequestService {
	
	UpdateRequest createUpdateRequest(EmployeeProfile updatedProfile);
	Optional<UpdateRequest> findByRequestId(UpdateRequestId reqId);
	List<UpdateRequest> viewAllUpdateRequests();
	boolean approveUpdateRequest(UpdateRequestId requestId);
	boolean rejectUpdateRequest(UpdateRequestId requestId);
	List<UpdateRequest> viewPendingUpdateRequests();

}
