package com.spark.app.model;

public enum Role {

	HR_MANAGER, PROJECT_MANAGER, EMPLOYEE
}
