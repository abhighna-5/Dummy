package com.spark.app.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
public class DeleteFeedbackRequestDTO {
    @NotNull
    private Long feedbackId;

    @NotNull
    private Long fromEmployeeId;

}
