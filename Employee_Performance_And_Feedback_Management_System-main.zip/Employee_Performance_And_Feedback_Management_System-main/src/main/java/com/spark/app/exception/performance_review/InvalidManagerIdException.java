package com.spark.app.exception.performance_review;

public class InvalidManagerIdException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public InvalidManagerIdException(String message) {
		super(message);
	}
}
