package com.spark.app.service;

import java.time.LocalDate;
import java.util.List;
import com.spark.app.dto.ReportHRResponseDTO;
import com.spark.app.dto.ReportResponseDTO;
import com.spark.app.model.PerformanceReview;

public interface ReportService {
	
	ReportResponseDTO createReport(PerformanceReview performanceReview);

	String summarizeFeedback(long employeeId, LocalDate reviewDate);
	
	double calculateGoalCompletionScore(long employeeId, LocalDate reviewDate);
	
	List<ReportResponseDTO> viewReportsByEmployee(long employeeId); 

	List<ReportHRResponseDTO> viewReportsByHRId(long employeeId);

	List<ReportResponseDTO> viewReportsByManagerId(long employeeId);
	
}
