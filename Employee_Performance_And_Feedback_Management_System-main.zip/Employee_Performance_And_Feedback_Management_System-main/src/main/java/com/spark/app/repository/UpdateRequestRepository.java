package com.spark.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spark.app.model.UpdateRequest;
import com.spark.app.model.UpdateRequestId;

@Repository
public interface UpdateRequestRepository extends JpaRepository<UpdateRequest,UpdateRequestId>{

}
