package com.spark.app.dto;
 
import java.time.LocalDate;
 
import org.springframework.format.annotation.DateTimeFormat;
 
import com.fasterxml.jackson.annotation.JsonFormat;
 
 
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
 
@Data
public class PerformanceReviewRequestDTO {
	@NotNull(message = "Employee ID is required")
	private long employeeId;
	@NotNull(message = "Manager ID is required")
	private long managerId;
	@NotNull(message = "Date is required")
	@FutureOrPresent
	@JsonFormat(pattern="dd-MM-yyyy")
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private LocalDate date;
}