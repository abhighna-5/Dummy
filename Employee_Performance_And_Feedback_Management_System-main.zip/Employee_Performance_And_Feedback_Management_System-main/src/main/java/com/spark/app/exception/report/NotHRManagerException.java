package com.spark.app.exception.report;

public class NotHRManagerException extends RuntimeException {

	public NotHRManagerException(String message)
	{
		super(message);
	}
}
