package com.spark.app.exception.report;

public class NotProjectManagerException extends RuntimeException
{
	public NotProjectManagerException(String message)
	{
		super(message);
	}
}
