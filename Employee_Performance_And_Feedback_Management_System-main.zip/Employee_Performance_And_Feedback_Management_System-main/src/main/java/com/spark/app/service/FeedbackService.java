package com.spark.app.service;

import java.time.LocalDate;
import java.util.List;

import com.spark.app.dto.FeedbackRequestDTO;
import com.spark.app.dto.FeedbackResponseDTO;

public interface FeedbackService {

    public FeedbackResponseDTO addFeedback(FeedbackRequestDTO feedbackRequestDTO);
    
    public List<FeedbackResponseDTO> viewReceivedFeedback(long employeeId);
    
    public List<FeedbackResponseDTO> viewGivenFeedback(long fromEmployeeId);
    
    public void deleteFeedback(long feedbackId, long fromEmployeeId);
    
   // public FeedbackResponseDTO retrieveRecentFeedback(long employeeId);

    
    public List<FeedbackResponseDTO> getFeedbackByDateRange(long employeeId, LocalDate startDate, LocalDate endDate);

	//public FeedbackResponseDTO updateFeedback(long feedbackId, String comments);

}
