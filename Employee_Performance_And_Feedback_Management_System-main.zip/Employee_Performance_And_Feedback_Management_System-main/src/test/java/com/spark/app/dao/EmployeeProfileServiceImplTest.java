package com.spark.app.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.function.Function;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.spark.app.dto.EmployeeProfileRequestDTO;
import com.spark.app.dto.EmployeeProfileResponseDTO;
import com.spark.app.mapper.EmployeeProfileMapper;
import com.spark.app.model.Department;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.Role;
import com.spark.app.repository.EmployeeProfileRepository;
import com.spark.app.security.EndUser;
import com.spark.app.security.EndUserService;

@SpringBootTest
public class EmployeeProfileServiceImplTest {
	
	@Mock
	private EmployeeProfileRepository employeeProfileRepository;
	
	@Mock
	private EndUserService endUserService;
	
	@Mock
	private EmployeeProfileMapper employeeProfileMapper;
	
	@InjectMocks
	private EmployeeProfileServiceImpl employeeProfileService;
	
	
	private EmployeeProfileRequestDTO profile = null;
	
	private EmployeeProfile entity = null;
	
	private EmployeeProfileResponseDTO response = null;
	
	private EndUser endUser = null;
	
	
		
	@BeforeEach
	public void init() {
		profile = constructEPRequestDTO();
		entity = constructEntity(profile);
		endUser = constructEndUser(entity);
		response = constructEPResponseDTO(entity);
	}
	
	@AfterEach
	public void del() {
		profile = null;
		entity = null;
		endUser = null;
		response = null;
	}
	
	private EmployeeProfileRequestDTO constructEPRequestDTO() {
		EmployeeProfileRequestDTO profile = new EmployeeProfileRequestDTO();
		profile.setContactDetails("test@gmail.com");
		profile.setDepartment(Department.ADM);
		profile.setName("Test");
		profile.setRole(Role.HR_MANAGER);
		return profile;
	}
	private EmployeeProfile constructEntity(EmployeeProfileRequestDTO profile) {
		EmployeeProfile entity = new EmployeeProfile();
		entity.setContactDetails(profile.getContactDetails());
		entity.setDepartment(profile.getDepartment());
		entity.setEmployeeId(1);
		entity.setName(profile.getName());
		entity.setRole(profile.getRole());
		return entity;
	}
	
	private EndUser constructEndUser(EmployeeProfile entity) {
		EndUser endUser = new EndUser();
		endUser.setActivated(false);
		endUser.setEmailAddress(entity.getContactDetails());
		endUser.setPassword(entity.getName());
		endUser.setRole(entity.getRole());
		return endUser;
	}
	
	private EmployeeProfileResponseDTO constructEPResponseDTO(EmployeeProfile entity) {
		EmployeeProfileResponseDTO obj = new EmployeeProfileResponseDTO();
		obj.setContactDetails(entity.getContactDetails());
		obj.setDepartment(entity.getDepartment());
		obj.setEmployeeId(entity.getEmployeeId());
		obj.setName(entity.getName());
		obj.setRole(entity.getRole());
		return obj;
	}
	
	
	@Test
	public void addValidEmployeeProfile() {
		/**
		 * Save Employee Profile
		 * Register Employee Profile
		 * Return Saved Employee Profile
		 */
		when(employeeProfileRepository.save(entity)).thenReturn(entity);
		when(employeeProfileMapper.toEntity(profile)).thenReturn(entity);
		when(employeeProfileMapper.toDTO(entity)).thenReturn(response);
		var savedEntity = employeeProfileService.addEmployeeProfile(profile);
		var expected = response;
		verify(endUserService).registerEndUser(endUser);
		assertEquals(expected,savedEntity);
	}

	
	
}
