package com.spark.app.controller;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import com.spark.app.service.EmployeeProfileService;
import com.spark.app.service.UpdateRequestService;

public class EmployeeControllerTest {

	@Mock
	private EmployeeProfileService employeeProfileService;
	
	@Mock
	private UpdateRequestService updateRequestService;
	
//	@Test
//	public void addValidEmployee
	
	
	
	
}
