package com.spark.app.dao;

import com.spark.app.dto.*;
import com.spark.app.model.Department;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.PerformanceReview;
import com.spark.app.model.ProgressStatus;
import com.spark.app.model.Report;
import com.spark.app.model.Role;
import com.spark.app.exception.employee_profile.EmployeeProfileNotFoundException;
import com.spark.app.exception.report.NotHRManagerException;
import com.spark.app.exception.report.NotProjectManagerException;
import com.spark.app.mapper.ReportResponseDTOMapper;
import com.spark.app.repository.ReportRepository;
import com.spark.app.service.EmployeeProfileService;
import com.spark.app.service.FeedbackService;
import com.spark.app.service.GoalManagementService;
import com.spark.app.service.PerformanceReviewService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;	

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

public class ReportServiceImplTest {

    @Mock
    private ReportRepository reportRepository;

    @Mock
    private EmployeeProfileService employeeProfileService;

    @Mock
    private ReportResponseDTOMapper responseDTOMapper;

    @Mock
    private PerformanceReviewService performanceReviewService;
	
    @Mock
    private GoalManagementService goalManagementService;
    
    @Mock
    private FeedbackService feedbackService;
    
    @Spy
    @InjectMocks
    private ReportServiceImpl reportService;
    
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    
    // ::::::::::::::::::Test Case for method createReport(PerformanceReview performanceReview::::::::::::::::::
    @Test
    public void testCreateReport_Success() {
        // Arrange
        PerformanceReview review = new PerformanceReview();
        review.setDate(LocalDate.of(2024, 12, 31));
        review.setPerformanceScore(8);
        review.setFeedback("Consistent performer");

        EmployeeProfile employee = new EmployeeProfile();
        employee.setEmployeeId(1L);
        review.setEmployeeId(employee);

        // Mock internal method calls using spy
        doReturn(90.0).when(reportService).calculateGoalCompletionScore(1L, LocalDate.of(2024, 12, 31));
        doReturn("Good Feedbacks:2, Average Feedbacks: 1, Bad Feedbacks :0")
                .when(reportService).summarizeFeedback(1L, LocalDate.of(2024, 12, 31));

        // Expected report to be saved
        Report savedReport = new Report();
        savedReport.setEmployeeId(employee);
        savedReport.setPerformanceSummary("Performance Score: 8.0 Review Feedback: Consistent performer, Goal Completion Score: 90.0%");
        savedReport.setFeedbackSummary("Good Feedbacks:2, Average Feedbacks: 1, Bad Feedbacks :0");

        ReportResponseDTO responseDTO = new ReportResponseDTO();
        responseDTO.setEmployeeId(1L);
        responseDTO.setPerformanceSummary(savedReport.getPerformanceSummary());
        responseDTO.setFeedbackSummary(savedReport.getFeedbackSummary());

        when(reportRepository.save(any(Report.class))).thenReturn(savedReport);
        when(responseDTOMapper.convertToDTO(any(Report.class))).thenReturn(responseDTO);

        // Act
        ReportResponseDTO result = reportService.createReport(review);

        // Assert
        assertNotNull(result);
        assertEquals(1L, result.getEmployeeId());
        assertEquals("Performance Score: 8.0 Review Feedback: Consistent performer, Goal Completion Score: 90.0%", result.getPerformanceSummary());
        assertEquals("Good Feedbacks:2, Average Feedbacks: 1, Bad Feedbacks :0", result.getFeedbackSummary());

        verify(reportService).calculateGoalCompletionScore(1L, LocalDate.of(2024, 12, 31));
        verify(reportService).summarizeFeedback(1L, LocalDate.of(2024, 12, 31));
        verify(reportRepository).save(any(Report.class));
        verify(responseDTOMapper).convertToDTO(any(Report.class));
    }

    
    // ::::::::::::::::::Test Cases for method summarizeFeedback(long employeeId, LocalDate reviewDate)::::::::::::::::::
    @Test
    public void testSummarizeFeedback_WithAllTypes() {
        long employeeId = 1L;
        LocalDate reviewDate = LocalDate.of(2024, 12, 31);

        // Mock latest report
        Report latestReport = new Report();
        latestReport.setReportDate(LocalDate.of(2024, 1, 1));

        // Mock feedbacks
        FeedbackResponseDTO fb1 = new FeedbackResponseDTO();
        fb1.setComments("GOOD");

        FeedbackResponseDTO fb2 = new FeedbackResponseDTO();
        fb2.setComments("AVERAGE");

        FeedbackResponseDTO fb3 = new FeedbackResponseDTO();
        fb3.setComments("BAD");

        FeedbackResponseDTO fb4 = new FeedbackResponseDTO();
        fb4.setComments("GOOD");

        when(reportRepository.findTopByEmployeeIdEmployeeIdOrderByReportDateDesc(employeeId)).thenReturn(latestReport);
        when(feedbackService.getFeedbackByDateRange(employeeId, LocalDate.of(2024, 1, 1), reviewDate))
            .thenReturn(Arrays.asList(fb1, fb2, fb3, fb4));

        String result = reportService.summarizeFeedback(employeeId, reviewDate);

        assertEquals("Good Feedbacks:2, Average Feedbacks: 1, Bad Feedbacks :1", result);
    }

    @Test
    public void testSummarizeFeedback_NoPreviousReport() {
        long employeeId = 2L;
        LocalDate reviewDate = LocalDate.of(2024, 12, 31);

        // No previous report
        when(reportRepository.findTopByEmployeeIdEmployeeIdOrderByReportDateDesc(employeeId)).thenReturn(null);

        FeedbackResponseDTO fb = new FeedbackResponseDTO();
        fb.setComments("GOOD");

        when(feedbackService.getFeedbackByDateRange(employeeId, LocalDate.MIN, reviewDate))
            .thenReturn(Collections.singletonList(fb));

        String result = reportService.summarizeFeedback(employeeId, reviewDate);

        assertEquals("Good Feedbacks:1, Average Feedbacks: 0, Bad Feedbacks :0", result);
    }

    @Test
    public void testSummarizeFeedback_NoFeedbacks() {
        long employeeId = 3L;
        LocalDate reviewDate = LocalDate.of(2024, 12, 31);

        Report latestReport = new Report();
        latestReport.setReportDate(LocalDate.of(2024, 1, 1));

        when(reportRepository.findTopByEmployeeIdEmployeeIdOrderByReportDateDesc(employeeId)).thenReturn(latestReport);
        when(feedbackService.getFeedbackByDateRange(employeeId, LocalDate.of(2024, 1, 1), reviewDate))
            .thenReturn(Collections.emptyList());

        String result = reportService.summarizeFeedback(employeeId, reviewDate);

        assertEquals("Good Feedbacks:0, Average Feedbacks: 0, Bad Feedbacks :0", result);
    }

    
    // ::::::::::::::::::Test Cases for method calculateGoalCompletionScore(long employeeId, LocalDate reviewDate)::::::::::::::::::
    
    @Test
    public void testCalculateGoalCompletionScore_WithCompletedAndPendingGoals() {
        long employeeId = 1L;
        LocalDate reviewDate = LocalDate.of(2024, 12, 31);

        // Mock latest report
        Report latestReport = new Report();
        latestReport.setReportDate(LocalDate.of(2024, 1, 1));

        // Mock goals
        GoalManagementResponseDTO goal1 = new GoalManagementResponseDTO();
        goal1.setGoalId(101L);
        goal1.setProgressStatus(ProgressStatus.COMPLETED);

        GoalManagementResponseDTO goal2 = new GoalManagementResponseDTO();
        goal2.setGoalId(102L);
        goal2.setProgressStatus(ProgressStatus.IN_PROGRESS);

        when(reportRepository.findTopByEmployeeIdEmployeeIdOrderByReportDateDesc(employeeId)).thenReturn(latestReport);
        when(goalManagementService.getGoalsByEmployeeAndDateRange(employeeId, LocalDate.of(2024, 1, 1), reviewDate))
            .thenReturn(Arrays.asList(goal1, goal2));

        double score = reportService.calculateGoalCompletionScore(employeeId, reviewDate);

        assertEquals(50.0, score);
    }

    @Test
    public void testCalculateGoalCompletionScore_AllGoalsCompleted() {
        long employeeId = 2L;
        LocalDate reviewDate = LocalDate.of(2024, 12, 31);

        Report latestReport = new Report();
        latestReport.setReportDate(LocalDate.of(2024, 6, 1));

        GoalManagementResponseDTO goal1 = new GoalManagementResponseDTO();
        goal1.setProgressStatus(ProgressStatus.COMPLETED);

        GoalManagementResponseDTO goal2 = new GoalManagementResponseDTO();
        goal2.setProgressStatus(ProgressStatus.COMPLETED);

        when(reportRepository.findTopByEmployeeIdEmployeeIdOrderByReportDateDesc(employeeId)).thenReturn(latestReport);
        when(goalManagementService.getGoalsByEmployeeAndDateRange(employeeId, LocalDate.of(2024, 6, 1), reviewDate))
            .thenReturn(Arrays.asList(goal1, goal2));

        double score = reportService.calculateGoalCompletionScore(employeeId, reviewDate);

        assertEquals(100.0, score);
    }

    @Test
    public void testCalculateGoalCompletionScore_NoGoals() {
        long employeeId = 3L;
        LocalDate reviewDate = LocalDate.of(2024, 12, 31);

        Report latestReport = new Report();
        latestReport.setReportDate(LocalDate.of(2024, 1, 1));

        when(reportRepository.findTopByEmployeeIdEmployeeIdOrderByReportDateDesc(employeeId)).thenReturn(latestReport);
        when(goalManagementService.getGoalsByEmployeeAndDateRange(employeeId, LocalDate.of(2024, 1, 1), reviewDate))
            .thenReturn(Collections.emptyList());

        double score = reportService.calculateGoalCompletionScore(employeeId, reviewDate);

        assertEquals(0.0, score);
    }

    @Test
    public void testCalculateGoalCompletionScore_NoPreviousReport() {
        long employeeId = 4L;
        LocalDate reviewDate = LocalDate.of(2024, 12, 31);

        // No previous report
        when(reportRepository.findTopByEmployeeIdEmployeeIdOrderByReportDateDesc(employeeId)).thenReturn(null);

        GoalManagementResponseDTO goal = new GoalManagementResponseDTO();
        goal.setProgressStatus(ProgressStatus.COMPLETED);

        when(goalManagementService.getGoalsByEmployeeAndDateRange(employeeId, LocalDate.MIN, reviewDate))
            .thenReturn(Collections.singletonList(goal));

        double score = reportService.calculateGoalCompletionScore(employeeId, reviewDate);

        assertEquals(100.0, score);
    }


    // ::::::::::::::::::Test Cases for method viewReportsByEmployee(long employeeId)::::::::::::::::::
    @Test
    public void testViewReportsByEmployee_Success() {
        EmployeeProfileResponseDTO profile = new EmployeeProfileResponseDTO();
        long employeeId = 1;
        profile.setEmployeeId(employeeId);
        profile.setRole(Role.EMPLOYEE);
        when(employeeProfileService.findEmployeeProfileById(employeeId)).thenReturn(Optional.of(profile));

        // Mock reports
        Report report1 = new Report();
        Report report2 = new Report();
        when(reportRepository.findByEmployeeIdEmployeeId(employeeId)).thenReturn(Arrays.asList(report1, report2));

        // Mock DTO mapping
        ReportResponseDTO dto1 = new ReportResponseDTO();
        ReportResponseDTO dto2 = new ReportResponseDTO();
        when(responseDTOMapper.convertToDTO(report1)).thenReturn(dto1);
        when(responseDTOMapper.convertToDTO(report2)).thenReturn(dto2);

        List<ReportResponseDTO> result = reportService.viewReportsByEmployee(employeeId);

        assertEquals(2, result.size());
        verify(employeeProfileService).findEmployeeProfileById(employeeId);
        verify(reportRepository).findByEmployeeIdEmployeeId(employeeId);
    }

    @Test
    public void testViewReportsByEmployee_EmployeeNotFound() {
        long employeeId = 2;

        when(employeeProfileService.findEmployeeProfileById(employeeId)).thenReturn(Optional.empty());

        Exception exception = assertThrows(EmployeeProfileNotFoundException.class, () -> {
            reportService.viewReportsByEmployee(employeeId);
        });

        assertEquals("Employee doesn't exist", exception.getMessage());
        verify(employeeProfileService).findEmployeeProfileById(employeeId);
        verify(reportRepository, never()).findByEmployeeIdEmployeeId(anyLong());
    }

    // ::::::::::::::::::Test Cases for method viewReportsByHRId(long employeeId)::::::::::::::::::

    @Test
    public void testViewReportsByHRId_Success() {
        long hrId = 1L;

        // Mock HR profile
        EmployeeProfileResponseDTO hr = new EmployeeProfileResponseDTO();
        hr.setEmployeeId(hrId);
        hr.setRole(Role.HR_MANAGER);

        // Mock employee profiles
        EmployeeProfileResponseDTO emp1 = new EmployeeProfileResponseDTO();
        emp1.setEmployeeId(2L);
        emp1.setName("John");

        EmployeeProfileResponseDTO emp2 = new EmployeeProfileResponseDTO();
        emp2.setEmployeeId(3L);
        emp2.setName("Jane");

        // Mock performance reviews
        PerformanceReviewResponseDTO review1 = new PerformanceReviewResponseDTO();
        review1.setPerformanceScore(9);

        PerformanceReviewResponseDTO review2 = new PerformanceReviewResponseDTO();
        review2.setPerformanceScore(8);

        PerformanceReviewResponseDTO review3 = new PerformanceReviewResponseDTO();
        review3.setPerformanceScore(8);

        when(employeeProfileService.findEmployeeProfileById(hrId)).thenReturn(Optional.of(hr));
        when(employeeProfileService.retrieveAllTheEmployeeProfiles()).thenReturn(Arrays.asList(hr, emp1, emp2));
        when(performanceReviewService.viewReviewsEmployee(2L)).thenReturn(Arrays.asList(review1, review2));
        when(performanceReviewService.viewReviewsEmployee(3L)).thenReturn(Arrays.asList(review3));

        List<ReportHRResponseDTO> result = reportService.viewReportsByHRId(hrId);

        assertEquals(2, result.size());
        assertEquals(2L, result.get(0).getEmployeeId()); // Higher average
        assertEquals(3L, result.get(1).getEmployeeId());
    }

    @Test
    public void testViewReportsByHRId_NotHRManager() {
        long empId = 2L;

        EmployeeProfileResponseDTO emp = new EmployeeProfileResponseDTO();
        emp.setEmployeeId(empId);
        emp.setRole(Role.EMPLOYEE);

        when(employeeProfileService.findEmployeeProfileById(empId)).thenReturn(Optional.of(emp));

        assertThrows(NotHRManagerException.class, () -> reportService.viewReportsByHRId(empId));
    }

    @Test
    public void testViewReportsByHRId_EmployeeNotFound() {
        long empId = 99L;

        when(employeeProfileService.findEmployeeProfileById(empId)).thenReturn(Optional.empty());

        assertThrows(EmployeeProfileNotFoundException.class, () -> reportService.viewReportsByHRId(empId));
    }

    @Test
    public void testViewReportsByHRId_EmployeesWithNoReviews() {
        long hrId = 1L;

        EmployeeProfileResponseDTO hr = new EmployeeProfileResponseDTO();
        hr.setEmployeeId(hrId);
        hr.setRole(Role.HR_MANAGER);

        EmployeeProfileResponseDTO emp = new EmployeeProfileResponseDTO();
        emp.setEmployeeId(2L);
        emp.setName("John");

        when(employeeProfileService.findEmployeeProfileById(hrId)).thenReturn(Optional.of(hr));
        when(employeeProfileService.retrieveAllTheEmployeeProfiles()).thenReturn(Arrays.asList(hr, emp));
        when(performanceReviewService.viewReviewsEmployee(2L)).thenReturn(Collections.emptyList());

        List<ReportHRResponseDTO> result = reportService.viewReportsByHRId(hrId);

        assertEquals(1, result.size());
        assertEquals(0.0, result.get(0).getAverageScore());
    }
    
    // ::::::::::::::::::Test Cases for method viewReportsByManagerId(long employeeId)::::::::::::::::::

    @Test
    public void testViewReportsByManagerId_Success() {
        long managerId = 1L;

        // Mock manager profile
        EmployeeProfileResponseDTO manager = new EmployeeProfileResponseDTO();
        manager.setEmployeeId(managerId);
        manager.setRole(Role.PROJECT_MANAGER);
        manager.setDepartment(Department.ADM);

        // Mock team members
        EmployeeProfileResponseDTO emp1 = new EmployeeProfileResponseDTO();
        emp1.setEmployeeId(2L);

        EmployeeProfileResponseDTO emp2 = new EmployeeProfileResponseDTO();
        emp2.setEmployeeId(3L);

        // Mock reports
        Report report1 = new Report();
        Report report2 = new Report();

        ReportResponseDTO dto1 = new ReportResponseDTO();
        ReportResponseDTO dto2 = new ReportResponseDTO();

        when(employeeProfileService.findEmployeeProfileById(managerId)).thenReturn(Optional.of(manager));
        when(employeeProfileService.findEmployeesByDepartment(Department.ADM)).thenReturn(Arrays.asList(manager, emp1, emp2));
        when(reportRepository.findByEmployeeIdEmployeeIdIn(Arrays.asList(2L, 3L))).thenReturn(Arrays.asList(report1, report2));
        when(responseDTOMapper.convertToDTO(report1)).thenReturn(dto1);
        when(responseDTOMapper.convertToDTO(report2)).thenReturn(dto2);

        List<ReportResponseDTO> result = reportService.viewReportsByManagerId(managerId);

        assertEquals(2, result.size());
        verify(employeeProfileService).findEmployeeProfileById(managerId);
        verify(reportRepository).findByEmployeeIdEmployeeIdIn(Arrays.asList(2L, 3L));
    }

    @Test
    public void testViewReportsByManagerId_NotProjectManager() {
        long empId = 2L;

        EmployeeProfileResponseDTO emp = new EmployeeProfileResponseDTO();
        emp.setEmployeeId(empId);
        emp.setRole(Role.EMPLOYEE);

        when(employeeProfileService.findEmployeeProfileById(empId)).thenReturn(Optional.of(emp));

        assertThrows(NotProjectManagerException.class, () -> reportService.viewReportsByManagerId(empId));
    }

    @Test
    public void testViewReportsByManagerId_EmployeeNotFound() {
        long empId = 99L;

        when(employeeProfileService.findEmployeeProfileById(empId)).thenReturn(Optional.empty());

        assertThrows(EmployeeProfileNotFoundException.class, () -> reportService.viewReportsByManagerId(empId));
    }

    @Test
    public void testViewReportsByManagerId_NoReportsFound() {
        long managerId = 1L;

        EmployeeProfileResponseDTO manager = new EmployeeProfileResponseDTO();
        manager.setEmployeeId(managerId);
        manager.setRole(Role.PROJECT_MANAGER);
        manager.setDepartment(Department.ADM);

        EmployeeProfileResponseDTO emp = new EmployeeProfileResponseDTO();
        emp.setEmployeeId(2L);

        when(employeeProfileService.findEmployeeProfileById(managerId)).thenReturn(Optional.of(manager));
        when(employeeProfileService.findEmployeesByDepartment(Department.ADM)).thenReturn(Arrays.asList(manager, emp));
        when(reportRepository.findByEmployeeIdEmployeeIdIn(Arrays.asList(2L))).thenReturn(Collections.emptyList());

        List<ReportResponseDTO> result = reportService.viewReportsByManagerId(managerId);

        assertTrue(result.isEmpty());
    }


}
