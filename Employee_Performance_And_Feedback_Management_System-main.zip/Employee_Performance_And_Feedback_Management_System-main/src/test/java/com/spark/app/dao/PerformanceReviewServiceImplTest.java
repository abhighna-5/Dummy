package com.spark.app.dao;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.spark.app.dto.PerformanceReviewRequestDTO;
import com.spark.app.dto.PerformanceReviewResponseDTO;
import com.spark.app.exception.performance_review.DuplicateReviewException;
import com.spark.app.exception.performance_review.IncompleteReviewException;
import com.spark.app.exception.performance_review.InsufficientDaysBetweenReviewsException;
import com.spark.app.exception.performance_review.InvalidEmployeeIdException;
import com.spark.app.exception.performance_review.InvalidManagerIdException;
import com.spark.app.exception.performance_review.NullRequestDTOException;
import com.spark.app.exception.performance_review.ReviewNotFoundException;
import com.spark.app.exception.performance_review.UnauthorizedException;
import com.spark.app.exception.performance_review.UpdateFailedException;
import com.spark.app.mapper.PerformanceReviewMapper;
import com.spark.app.model.Department;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.PerformanceReview;
import com.spark.app.model.Role;
import com.spark.app.repository.EmployeeProfileRepository;
import com.spark.app.repository.PerformanceReviewRepository;

@SpringBootTest
public class PerformanceReviewServiceImplTest {

	
	@Mock
	private PerformanceReviewRepository performanceReviewRepository;
	
	@Mock
	private EmployeeProfileRepository employeeProfileRepository;
	
	@Mock
	private PerformanceReviewMapper performanceReviewMapper ;
	
	
	@InjectMocks
	private PerformanceReviewServiceImpl performanceReviewServiceImpl;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	public void testAddPerformanceReview_Success() {
		
		EmployeeProfile employee = new EmployeeProfile();
		employee.setEmployeeId(5L);
		employee.setName("Rohit");
		employee.setDepartment(Department.ADM);
		employee.setRole(Role.EMPLOYEE);
		employee.setContactDetails("rohit@gmail.com");
		
		
		
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		PerformanceReviewRequestDTO request = new PerformanceReviewRequestDTO();
		request.setEmployeeId(5L);
		request.setManagerId(10L);
		request.setDate(LocalDate.now().plusDays(5));
		
		when(employeeProfileRepository.findById(5L)).thenReturn(Optional.of(employee));
		
		when(employeeProfileRepository.findById(10L)).thenReturn(Optional.of(manager));
		
		when(performanceReviewRepository.existsByEmployeeIdEmployeeIdAndManagerIdEmployeeIdAndDate(5L, 10L, LocalDate.now().plusDays(5))).thenReturn(false);
		
		when(performanceReviewRepository.recentReview(5L)).thenReturn(null);
		

		when(performanceReviewMapper.toEntity(request)).thenReturn(new PerformanceReview());
		when(performanceReviewRepository.save(any(PerformanceReview.class))).thenReturn(new PerformanceReview());
		when(performanceReviewMapper.toDto(any(PerformanceReview.class))).thenReturn(new PerformanceReviewResponseDTO());

		PerformanceReviewResponseDTO responseDTO = performanceReviewServiceImpl.addPerformanceReview(request);

		assertNotNull(responseDTO);

	}
	
	@Test
	public void testAddPerformanceReview_RequestDTONull() {
		
		PerformanceReviewRequestDTO request = null;
		
		assertThrows(NullRequestDTOException.class, ()->{
			performanceReviewServiceImpl.addPerformanceReview(request);
		});
	}
	
	@Test
	public void testAddPerformanceReview_InvalidEmployeeId() {
		
		PerformanceReviewRequestDTO request = new PerformanceReviewRequestDTO();
		
		request.setEmployeeId(5L);
		request.setManagerId(10L);
		request.setDate(LocalDate.now().plusDays(5));
		
		
		when(employeeProfileRepository.findById(5L)).thenReturn(Optional.empty());
		
		assertThrows(InvalidEmployeeIdException.class, ()->{
			performanceReviewServiceImpl.addPerformanceReview(request);
		});
	}
	
	@Test
	public void testAddPerformanceReview_InvalidManagerId() {
		
		EmployeeProfile employee = new EmployeeProfile();
		employee.setEmployeeId(5L);
		employee.setName("Rohit");
		employee.setDepartment(Department.ADM);
		employee.setRole(Role.EMPLOYEE);
		employee.setContactDetails("rohit@gmail.com");
		
		PerformanceReviewRequestDTO request = new PerformanceReviewRequestDTO();
		
		request.setEmployeeId(5L);
		request.setManagerId(10L);
		request.setDate(LocalDate.now().plusDays(5));
		
		when(employeeProfileRepository.findById(5L)).thenReturn(Optional.of(employee));
		
		when(employeeProfileRepository.findById(10L)).thenReturn(Optional.empty());
		
		assertThrows(InvalidManagerIdException.class, ()->{
			performanceReviewServiceImpl.addPerformanceReview(request);
		});
	}
	
	@Test
	public void testAddPerformanceReview_Unauthorized1() {
		
		EmployeeProfile employee = new EmployeeProfile();
		employee.setEmployeeId(5L);
		employee.setName("Rohit");
		employee.setDepartment(Department.ADM);
		employee.setRole(Role.EMPLOYEE);
		employee.setContactDetails("rohit@gmail.com");
		
		
		
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.EMPLOYEE);
		manager.setContactDetails("karthik@gmail.com");
		
		PerformanceReviewRequestDTO request = new PerformanceReviewRequestDTO();
		request.setEmployeeId(5L);
		request.setManagerId(10L);
		request.setDate(LocalDate.now().plusDays(5));
		
		when(employeeProfileRepository.findById(5L)).thenReturn(Optional.of(employee));
		
		when(employeeProfileRepository.findById(10L)).thenReturn(Optional.of(manager));
		
		assertThrows(UnauthorizedException.class, () -> {
	            performanceReviewServiceImpl.addPerformanceReview(request);
	        });
	}
	
	@Test
	public void testAddPerformanceReview_Unauthorized2() {
		
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		PerformanceReviewRequestDTO request = new PerformanceReviewRequestDTO();
		request.setEmployeeId(10L);
		request.setManagerId(10L);
		request.setDate(LocalDate.now().plusDays(5));
		
		when(employeeProfileRepository.findById(10L)).thenReturn(Optional.of(manager));
		
		when(employeeProfileRepository.findById(10L)).thenReturn(Optional.of(manager));
		
		assertThrows(UnauthorizedException.class, () -> {
	            performanceReviewServiceImpl.addPerformanceReview(request);
	        });
	}
	
	@Test
	public void testAddPerformanceReview_DuplicateReview() {
		
		EmployeeProfile employee = new EmployeeProfile();
		employee.setEmployeeId(5L);
		employee.setName("Rohit");
		employee.setDepartment(Department.ADM);
		employee.setRole(Role.EMPLOYEE);
		employee.setContactDetails("rohit@gmail.com");
		
		
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		PerformanceReviewRequestDTO request = new PerformanceReviewRequestDTO();
		request.setEmployeeId(5L);
		request.setManagerId(10L);
		request.setDate(LocalDate.now().plusDays(5));
		
		when(employeeProfileRepository.findById(5L)).thenReturn(Optional.of(employee));
		
		when(employeeProfileRepository.findById(10L)).thenReturn(Optional.of(manager));
		
		when(performanceReviewRepository.existsByEmployeeIdEmployeeIdAndManagerIdEmployeeIdAndDate(5L, 10L, LocalDate.now().plusDays(5))).thenReturn(true);
		
		assertThrows(DuplicateReviewException.class, () -> {
            performanceReviewServiceImpl.addPerformanceReview(request);
        });
	}
	
	@Test
	public void testAddPerformanceReview_IncompleteReview() {
		
		EmployeeProfile employee = new EmployeeProfile();
		employee.setEmployeeId(5L);
		employee.setName("Rohit");
		employee.setDepartment(Department.ADM);
		employee.setRole(Role.EMPLOYEE);
		employee.setContactDetails("rohit@gmail.com");
		
		
		
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		PerformanceReviewRequestDTO request = new PerformanceReviewRequestDTO();
		request.setEmployeeId(5L);
		request.setManagerId(10L);
		request.setDate(LocalDate.now().plusDays(25));
		
		when(employeeProfileRepository.findById(5L)).thenReturn(Optional.of(employee));
		
		when(employeeProfileRepository.findById(10L)).thenReturn(Optional.of(manager));
		
		when(performanceReviewRepository.existsByEmployeeIdEmployeeIdAndManagerIdEmployeeIdAndDate(5L, 10L, LocalDate.now().plusDays(5))).thenReturn(false);
		
		when(performanceReviewRepository.recentReview(5L)).thenReturn(LocalDate.now().plusDays(5));
		
		when(performanceReviewRepository.recentFeedback(5L, LocalDate.now().plusDays(5))).thenReturn(null);
		
		
		assertThrows(IncompleteReviewException.class, () -> {
            performanceReviewServiceImpl.addPerformanceReview(request);
        });
	}
	
	@Test
	public void testAddPerformanceReview_InsufficientDaysBetweenReviews() {
		
		EmployeeProfile employee = new EmployeeProfile();
		employee.setEmployeeId(5L);
		employee.setName("Rohit");
		employee.setDepartment(Department.ADM);
		employee.setRole(Role.EMPLOYEE);
		employee.setContactDetails("rohit@gmail.com");
		
		
		
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		PerformanceReviewRequestDTO request = new PerformanceReviewRequestDTO();
		request.setEmployeeId(5L);
		request.setManagerId(10L);
		request.setDate(LocalDate.now().plusDays(5));
		
		when(employeeProfileRepository.findById(5L)).thenReturn(Optional.of(employee));
		
		when(employeeProfileRepository.findById(10L)).thenReturn(Optional.of(manager));
		
		when(performanceReviewRepository.existsByEmployeeIdEmployeeIdAndManagerIdEmployeeIdAndDate(5L, 10L, LocalDate.now().plusDays(5))).thenReturn(false);
		
		when(performanceReviewRepository.recentReview(5L)).thenReturn(LocalDate.now().minusDays(1));
		
		when(performanceReviewRepository.recentFeedback(5L, LocalDate.now().minusDays(1))).thenReturn("Good");
		
		
		assertThrows(InsufficientDaysBetweenReviewsException.class, () -> {
            performanceReviewServiceImpl.addPerformanceReview(request);
        });
	}
	
	@Test
	public void testViewReviewsEmployee_Success() {
		
		EmployeeProfile employee = new EmployeeProfile();
		employee.setEmployeeId(5L);
		employee.setName("Rohit");
		employee.setDepartment(Department.ADM);
		employee.setRole(Role.EMPLOYEE);
		employee.setContactDetails("rohit@gmail.com");
		
		when(employeeProfileRepository.findById(5L)).thenReturn(Optional.of(employee));
		

		when(performanceReviewRepository.findByEmployeeIdEmployeeId(5L)).thenReturn(Collections.singletonList(new PerformanceReview()));
		when(performanceReviewMapper.toDto(any(PerformanceReview.class))).thenReturn(new PerformanceReviewResponseDTO());

		List<PerformanceReviewResponseDTO> response = performanceReviewServiceImpl.viewReviewsEmployee(5L);

		assertNotNull(response);
		assertEquals(1, response.size());

		
	}
	
	@Test
	public void testViewReviewsEmployee_InvalidEmployeeId() {
		
		when(employeeProfileRepository.findById(1L)).thenReturn(Optional.empty());
		
		assertThrows(InvalidEmployeeIdException.class, ()->{
			performanceReviewServiceImpl.viewReviewsEmployee(1L);
		});
	}
	
	@Test
	public void testViewReviewsManager_Success() {
		
		EmployeeProfile manager = new EmployeeProfile();
		
		manager.setEmployeeId(1L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		when(employeeProfileRepository.findById(1L)).thenReturn(Optional.of(manager));
		

		when(performanceReviewRepository.findByManagerIdEmployeeId(1L)).thenReturn(Collections.singletonList(new PerformanceReview()));
		when(performanceReviewMapper.toDto(any(PerformanceReview.class))).thenReturn(new PerformanceReviewResponseDTO());

		List<PerformanceReviewResponseDTO> response = performanceReviewServiceImpl.viewReviewsManager(1L);
		

		assertNotNull(response);
		assertEquals(1, response.size());

	}
	
	@Test
	public void testViewReviewsManager_InvalidManagerId() {
		
		when(employeeProfileRepository.findById(1L)).thenReturn(Optional.empty());
		
		assertThrows(InvalidManagerIdException.class, ()->{
			performanceReviewServiceImpl.viewReviewsManager(1L);
		});
	}
	
	@Test
	public void testViewReviewsManager_Unauthorized() {
		
		EmployeeProfile manager = new EmployeeProfile();
		
		manager.setEmployeeId(1L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.EMPLOYEE);
		manager.setContactDetails("karthik@gmail.com");
		
		when(employeeProfileRepository.findById(1L)).thenReturn(Optional.of(manager));
		
		assertThrows(UnauthorizedException.class, () -> {
	            performanceReviewServiceImpl.viewReviewsManager(1L);
	        });
	}
	
	@Test
	public void testDeleteReview_Success() {
		
		PerformanceReview review = new PerformanceReview();
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(1L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		review.setReviewId(1L);
		review.setManagerId(manager);
		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.of(review));
		performanceReviewServiceImpl.deleteReview(1L, 1L);
		
		verify(performanceReviewRepository, times(1)).delete(review);
	}


	@Test
	public void testDeleteReview_ReviewNotFound() {
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.empty());
		
		assertThrows(ReviewNotFoundException.class, ()->{
			performanceReviewServiceImpl.deleteReview(1L, 2L);
		});
	}

	@Test
	public void testDeleteReview_Unauthorized() {
		
		PerformanceReview review = new PerformanceReview();
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		review.setReviewId(1L);
		review.setManagerId(manager);
		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.of(review));
		
		assertThrows(UnauthorizedException.class, () -> {
            performanceReviewServiceImpl.deleteReview(1L, 2L);
        });
		
	}
	
	@Test
	public void testUpdateReview_Success() {
		
		PerformanceReview review = new PerformanceReview();
		
		EmployeeProfile manager = new EmployeeProfile();
		EmployeeProfile employee = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		employee.setEmployeeId(2L);
		employee.setName("Rohit");
		employee.setDepartment(Department.ADM);
		employee.setRole(Role.EMPLOYEE);
		employee.setContactDetails("rohit@gmail.com");
		
		review.setReviewId(1L);
		review.setEmployeeId(employee);
		review.setManagerId(manager);
		review.setDate(LocalDate.now().plusDays(20));
		
		
		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.of(review));
		
		when(performanceReviewRepository.recentCompletedReview(2L)).thenReturn(LocalDate.now().minusDays(15));
		
		when(performanceReviewMapper.toDto(any(PerformanceReview.class))).thenReturn(new PerformanceReviewResponseDTO());

		PerformanceReviewResponseDTO response = performanceReviewServiceImpl.updateReview(1L, 10L, LocalDate.now().plusDays(10));

		assertNotNull(response);
	
	}
	
	@Test
	public void testUpdateReview_ReviewNotFound() {
		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.empty());
		
		assertThrows(ReviewNotFoundException.class, ()->{
			performanceReviewServiceImpl.updateReview(1L, 2L,LocalDate.now());
		});
	}
	
	@Test
	public void testUpdateReview_Unauthorized() {
		
		PerformanceReview review = new PerformanceReview();
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		review.setReviewId(1L);
		review.setManagerId(manager);
		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.of(review));
		
		assertThrows(UnauthorizedException.class, () -> {
            performanceReviewServiceImpl.updateReview(1L, 2L, LocalDate.now());
        });
		
	}
	
	@Test
	public void testUpdateReview_UpdateFailed1() {
		
		PerformanceReview review = new PerformanceReview();
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(1L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		review.setReviewId(1L);
		review.setManagerId(manager);
		review.setDate(LocalDate.now().minusDays(5));
		review.setFeedback("Good");
		review.setPerformanceScore(8);
		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.of(review));
		
		assertThrows(UpdateFailedException.class, () -> {
            performanceReviewServiceImpl.updateReview(1L, 1L, LocalDate.now());
        });
	}
	
	@Test
	public void testUpdateReview_UpdateFailed2() {
		
		PerformanceReview review = new PerformanceReview();
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(1L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		review.setReviewId(1L);
		review.setManagerId(manager);
		review.setDate(LocalDate.now().plusDays(5));

		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.of(review));
		
		assertThrows(UpdateFailedException.class, () -> {
            performanceReviewServiceImpl.updateReview(1L, 1L, LocalDate.now().plusDays(5));
        });
	}
	
	@Test
	public void testUpdateReview_InsufficientDaysBetweenReviews() {
		
		PerformanceReview review = new PerformanceReview();
		
		EmployeeProfile manager = new EmployeeProfile();
		EmployeeProfile employee = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		employee.setEmployeeId(2L);
		employee.setName("Rohit");
		employee.setDepartment(Department.ADM);
		employee.setRole(Role.EMPLOYEE);
		employee.setContactDetails("rohit@gmail.com");
		
		review.setReviewId(1L);
		review.setEmployeeId(employee);
		review.setManagerId(manager);
		review.setDate(LocalDate.now().plusDays(20));
		
		
		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.of(review));
		
		when(performanceReviewRepository.recentCompletedReview(2L)).thenReturn(LocalDate.now().minusDays(5));
		
		assertThrows(InsufficientDaysBetweenReviewsException.class, () -> {
            performanceReviewServiceImpl.updateReview(1L, 10L, LocalDate.now());
        });
		
	}
	

	
	@Test 
	public void testProvidePerformanceScoreAndFeedback_ReviewNotFound() {
		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.empty());
		
		assertThrows(ReviewNotFoundException.class, ()->{
			performanceReviewServiceImpl.providePerformanceScoreAndFeedback(1L, 10L, 8, 8, 8, "Good");
		});
	}
	
	@Test
	public void testProvidePerformanceScoreAndFeedback_Unauthorized() {
		
		PerformanceReview review = new PerformanceReview();
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		review.setReviewId(1L);
		review.setManagerId(manager);
		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.of(review));
		
		assertThrows(UnauthorizedException.class, () -> {
            performanceReviewServiceImpl.providePerformanceScoreAndFeedback(1L, 5L, 8, 8, 9, "Good");
        });
		
	}
	
	@Test
	public void testProvidePerformanceScoreAndFeedback_IncompleteReview() {
		
		PerformanceReview review = new PerformanceReview();
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		review.setReviewId(1L);
		review.setManagerId(manager);
		review.setDate(LocalDate.now().plusDays(5));
		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.of(review));
		
		assertThrows(IncompleteReviewException.class, () -> {
            performanceReviewServiceImpl.providePerformanceScoreAndFeedback(1L, 10L, 8, 8, 9, "Good");
        });
	}
	
	@Test
	public void testProvidePerformanceScoreAndFeedback_UpdateFailed1() {
		
		PerformanceReview review = new PerformanceReview();
		EmployeeProfile manager = new EmployeeProfile();
		manager.setEmployeeId(10L);
		manager.setName("Karthik");
		manager.setDepartment(Department.ADM);
		manager.setRole(Role.PROJECT_MANAGER);
		manager.setContactDetails("karthik@gmail.com");
		
		review.setReviewId(1L);
		review.setManagerId(manager);
		review.setDate(LocalDate.now().minusDays(5));
		review.setFeedback("Good");
		review.setPerformanceScore(8);
		
		when(performanceReviewRepository.findById(1L)).thenReturn(Optional.of(review));
		
		assertThrows(UpdateFailedException.class, () -> {
            performanceReviewServiceImpl.providePerformanceScoreAndFeedback(1L, 10L, 8, 8, 9, "Good");
        });
	}
}
