package com.spark.app.dao;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.spark.app.dto.FeedbackRequestDTO;
import com.spark.app.dto.FeedbackResponseDTO;
import com.spark.app.exception.*;
import com.spark.app.exception.feedback.DuplicateFeedbackException;
import com.spark.app.exception.feedback.FeedbackNotFoundException;
import com.spark.app.exception.performance_review.InvalidEmployeeIdException;
import com.spark.app.exception.performance_review.UnauthorizedException;
import com.spark.app.mapper.FeedbackDTOMapper;
import com.spark.app.mapper.FeedbackMapper;
import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.Feedback;
import com.spark.app.model.FeedbackCommentType;
import com.spark.app.repository.FeedbackRepository;
import com.spark.app.repository.EmployeeProfileRepository;

class FeedbackServiceImplTest {

    @Mock
    private FeedbackRepository feedbackRepository; // Mocked repository for feedback operations

    @Mock
    private EmployeeProfileRepository employeeProfileRepository; // Mocked repository for employee validation

    @Mock
    private FeedbackMapper feedbackMapper; // Mocked mapper for entity conversion

    @Mock
    private FeedbackDTOMapper feedbackDTOMapper; // Mocked mapper for DTO conversion

    @InjectMocks
    private FeedbackServiceImpl feedbackService; // Injects mocked dependencies into service

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initializes mocks before each test
    }
    
    @Test
    void testAddFeedback_InvalidEmployeeId() {
        // Create a request DTO with non-existent employee IDs
        FeedbackRequestDTO requestDTO = new FeedbackRequestDTO();
        requestDTO.setFromEmployeeId(999L); // Invalid ID
        requestDTO.setToEmployeeId(888L);   // Invalid ID

        // Mock repository responses to simulate missing employees
        when(employeeProfileRepository.findById(999L)).thenReturn(Optional.empty());
        when(employeeProfileRepository.findById(888L)).thenReturn(Optional.empty());

        // Validate that the exception is thrown for invalid IDs
        assertThrows(InvalidEmployeeIdException.class, () -> feedbackService.addFeedback(requestDTO));
    }
    @Test
    void testAddFeedback_InvalidToEmployeeId() {
        // Create request DTO with valid fromEmployeeId and invalid toEmployeeId
        FeedbackRequestDTO requestDTO = new FeedbackRequestDTO();
        requestDTO.setFromEmployeeId(1L); // Valid ID
        requestDTO.setToEmployeeId(999L); // Invalid ID

        // Mock valid 'fromEmployeeId' but invalid 'toEmployeeId'
        when(employeeProfileRepository.findById(1L)).thenReturn(Optional.of(new EmployeeProfile()));
        when(employeeProfileRepository.findById(999L)).thenReturn(Optional.empty());

        // Validate that InvalidEmployeeIdException is thrown
        assertThrows(InvalidEmployeeIdException.class, () -> feedbackService.addFeedback(requestDTO));
    }

    @Test
    void testAddFeedback_InvalidFromEmployeeId() {
        // Create request DTO with invalid fromEmployeeId and valid toEmployeeId
        FeedbackRequestDTO requestDTO = new FeedbackRequestDTO();
        requestDTO.setFromEmployeeId(999L); // Invalid ID
        requestDTO.setToEmployeeId(2L); // Valid ID

        // Mock valid 'toEmployeeId' but invalid 'fromEmployeeId'
        when(employeeProfileRepository.findById(999L)).thenReturn(Optional.empty());
        when(employeeProfileRepository.findById(2L)).thenReturn(Optional.of(new EmployeeProfile()));

        // Validate that InvalidEmployeeIdException is thrown
        assertThrows(InvalidEmployeeIdException.class, () -> feedbackService.addFeedback(requestDTO));
    }@Test
    void testAddFeedback_Success() {
        // Sets up request DTO
        FeedbackRequestDTO requestDTO = new FeedbackRequestDTO();
        requestDTO.setFromEmployeeId(1L);
        requestDTO.setToEmployeeId(2L);
        requestDTO.setComments(FeedbackCommentType.GOOD); // ✅ Use ENUM instead of String

        // Mocks employee profiles
        EmployeeProfile fromEmployee = new EmployeeProfile();
        EmployeeProfile toEmployee = new EmployeeProfile();

        // Mocks feedback entity and response DTO
        Feedback feedback = new Feedback();
        feedback.setDate(LocalDate.now());
        feedback.setComments(FeedbackCommentType.GOOD); // ✅ Ensure feedback stores ENUM
        FeedbackResponseDTO responseDTO = new FeedbackResponseDTO();

        // Mocks repository and mapper interactions
        when(employeeProfileRepository.findById(1L)).thenReturn(Optional.of(fromEmployee));
        when(employeeProfileRepository.findById(2L)).thenReturn(Optional.of(toEmployee));
        when(feedbackRepository.existsByFromEmployeeEmployeeIdAndToEmployeeEmployeeIdAndDate(1L, 2L, LocalDate.now())).thenReturn(false);
        when(feedbackMapper.toEntity(requestDTO)).thenReturn(feedback);
        when(feedbackRepository.save(feedback)).thenReturn(feedback);
        when(feedbackDTOMapper.toDto(feedback)).thenReturn(responseDTO);

        // Calls service method
        FeedbackResponseDTO result = feedbackService.addFeedback(requestDTO);

        // Validates the result
        assertNotNull(result);
        verify(feedbackRepository, times(1)).save(feedback);
    }


    @Test
    void testAddFeedback_DuplicateEntry() {
        // Sets up request DTO
        FeedbackRequestDTO requestDTO = new FeedbackRequestDTO();
        requestDTO.setFromEmployeeId(1L);
        requestDTO.setToEmployeeId(2L);

        // Mocks employee profiles
        EmployeeProfile fromEmployee = new EmployeeProfile();
        EmployeeProfile toEmployee = new EmployeeProfile();

        // Mocks repository check for duplicate feedback
        when(employeeProfileRepository.findById(1L)).thenReturn(Optional.of(fromEmployee));
        when(employeeProfileRepository.findById(2L)).thenReturn(Optional.of(toEmployee));
        when(feedbackRepository.existsByFromEmployeeEmployeeIdAndToEmployeeEmployeeIdAndDate(1L, 2L, LocalDate.now())).thenReturn(true);

        // Validates that exception is thrown
        assertThrows(DuplicateFeedbackException.class, () -> feedbackService.addFeedback(requestDTO));
    }

    @Test
    void testViewGivenFeedback_Success() {
        // Ensures employee exists
        when(employeeProfileRepository.existsById(1L)).thenReturn(true);

        // Mocks feedback retrieval
        when(feedbackRepository.findByFromEmployeeEmployeeId(1L)).thenReturn(List.of(new Feedback()));

        // Executes method
        List<FeedbackResponseDTO> result = feedbackService.viewGivenFeedback(1L);

        // Validates response is not empty
        assertFalse(result.isEmpty());
    }
    @Test
    void testViewGivenFeedback_EmptyList() {
        // Mock employee existence
        when(employeeProfileRepository.existsById(1L)).thenReturn(true);

        // Mock empty feedback response
        when(feedbackRepository.findByFromEmployeeEmployeeId(1L)).thenReturn(List.of());

        // Execute service method
        List<FeedbackResponseDTO> result = feedbackService.viewGivenFeedback(1L);

        // Validate that the returned list is empty
        assertTrue(result.isEmpty());
    }
    @Test
    void testViewGivenFeedback_InvalidEmployeeId() {
        // Mock employee does not exist
        when(employeeProfileRepository.existsById(999L)).thenReturn(false);

        // Validate that the exception is thrown when an invalid ID is used
        assertThrows(InvalidEmployeeIdException.class, () -> feedbackService.viewGivenFeedback(999L));
    }



    @Test
    void testGetFeedbackByDateRange_Success() {
        // Sets up date range
        LocalDate startDate = LocalDate.of(2025, 5, 1);
        LocalDate endDate = LocalDate.of(2025, 5, 15);

        // Mocks feedback entities
        Feedback feedback1 = new Feedback();
        feedback1.setDate(LocalDate.of(2025, 5, 5));
        Feedback feedback2 = new Feedback();
        feedback2.setDate(LocalDate.of(2025, 5, 10));

        // Ensures employee exists and mocks feedback retrieval
        when(employeeProfileRepository.existsById(1L)).thenReturn(true);
        when(feedbackRepository.findByToEmployeeEmployeeId(1L)).thenReturn(List.of(feedback1, feedback2));
        when(feedbackDTOMapper.toDto(any())).thenReturn(new FeedbackResponseDTO());

        // Calls method
        List<FeedbackResponseDTO> result = feedbackService.getFeedbackByDateRange(1L, startDate, endDate);

        // Validates expected feedback count
        assertEquals(2, result.size());
    }

    @Test
    void testGetFeedbackByDateRange_EmptyList() {
        // Sets up date range
        LocalDate startDate = LocalDate.of(2025, 5, 1);
        LocalDate endDate = LocalDate.of(2025, 5, 15);

        // Ensures employee exists and mocks empty feedback list
        when(employeeProfileRepository.existsById(1L)).thenReturn(true);
        when(feedbackRepository.findByToEmployeeEmployeeId(1L)).thenReturn(List.of());

        // Calls method
        List<FeedbackResponseDTO> result = feedbackService.getFeedbackByDateRange(1L, startDate, endDate);

        // Validates empty result
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetFeedbackByDateRange_InvalidEmployeeId() {
        // Sets up date range
        LocalDate startDate = LocalDate.of(2025, 5, 1);
        LocalDate endDate = LocalDate.of(2025, 5, 15);

        // Ensures employee does not exist
        when(employeeProfileRepository.existsById(999L)).thenReturn(false);

        // Validates exception is thrown
        assertThrows(InvalidEmployeeIdException.class, () -> feedbackService.getFeedbackByDateRange(999L, startDate, endDate));
    }

    @Test
    void testGetFeedbackByDateRange_InvalidDateRange() {
        LocalDate startDate = LocalDate.of(2025, 5, 15);
        LocalDate endDate = LocalDate.of(2025, 5, 1); // ❌ Invalid: Start Date is after End Date

        when(employeeProfileRepository.existsById(1L)).thenReturn(true);

        assertThrows(IllegalArgumentException.class, () -> feedbackService.getFeedbackByDateRange(1L, startDate, endDate));
    }

    
    @Test
    void testDeleteFeedback_Success() {
        // Mock feedback entity with the correct sender
        Feedback feedback = new Feedback();
        EmployeeProfile sender = new EmployeeProfile();
        sender.setEmployeeId(1L); // Correct sender ID
        feedback.setFromEmployee(sender);

        // Mock repository to return feedback
        when(feedbackRepository.findById(1L)).thenReturn(Optional.of(feedback));

        // Call method
        feedbackService.deleteFeedback(1L, 1L);

        // Verify feedback deletion
        verify(feedbackRepository, times(1)).delete(feedback);
    }

    @Test
    void testDeleteFeedback_InvalidFeedbackId() {
        // Mock feedback does not exist
        when(feedbackRepository.findById(999L)).thenReturn(Optional.empty());

        // Validate that the exception is thrown when trying to delete a non-existent feedback
        assertThrows(FeedbackNotFoundException.class, () -> feedbackService.deleteFeedback(999L, 1L));
    }
    
    
    @Test
    void testDeleteFeedback_Unauthorized() {
        // Mock feedback entity with a different sender ID
        Feedback feedback = new Feedback();
        EmployeeProfile sender = new EmployeeProfile();
        sender.setEmployeeId(2L); // Wrong sender ID
        feedback.setFromEmployee(sender);

        // Mock repository to return feedback
        when(feedbackRepository.findById(1L)).thenReturn(Optional.of(feedback));

        // Validate that an unauthorized exception is thrown when the wrong user tries to delete feedback
        assertThrows(UnauthorizedException.class, () -> feedbackService.deleteFeedback(1L, 1L));
    }


}
