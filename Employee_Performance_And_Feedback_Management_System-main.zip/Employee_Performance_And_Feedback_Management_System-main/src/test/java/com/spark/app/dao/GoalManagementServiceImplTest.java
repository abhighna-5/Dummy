package com.spark.app.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;


import com.spark.app.dto.GoalManagementRequestDTO;
import com.spark.app.dto.GoalManagementResponseDTO;

import com.spark.app.exception.goal_management.GoalNotFoundException;
import com.spark.app.exception.performance_review.InvalidEmployeeIdException;

import com.spark.app.exception.goal_management.GoalAlreadyAssignedException;


import com.spark.app.mapper.GoalManagementMapper;

import com.spark.app.model.EmployeeProfile;
import com.spark.app.model.GoalManagement;
import com.spark.app.model.ProgressStatus;

import com.spark.app.repository.EmployeeProfileRepository;
import com.spark.app.repository.GoalManagementRepository;



public class GoalManagementServiceImplTest {
	
	@InjectMocks
	private GoalManagementServiceImpl goalManagementService;
	
	@Mock
    private GoalManagementRepository goalManagementRepository;
	
	@Mock
    private EmployeeProfileRepository employeeProfileRepository;


  

    @Mock
    private GoalManagementMapper goalManagementMapper;
    
    @Mock
    private ModelMapper modelMapper;
    
    @BeforeEach
    void setUp() {
    	MockitoAnnotations.openMocks(this);
    }
    
    @Test
    void testCreateGoal_EmployeeExists() {
        
        EmployeeProfile employee = new EmployeeProfile();
        employee.setEmployeeId(1L);

        GoalManagementRequestDTO requestDTO = new GoalManagementRequestDTO();
        requestDTO.setEmployeeId(1L);


        GoalManagement goalManagement = new GoalManagement();

  
        when(employeeProfileRepository.findById(1L)).thenReturn(Optional.of(employee));
        when(goalManagementMapper.toEntity(requestDTO)).thenReturn(goalManagement);
        when(goalManagementRepository.save(goalManagement)).thenReturn(goalManagement);
        when(goalManagementMapper.toDTO(goalManagement)).thenReturn(new GoalManagementResponseDTO());


        GoalManagementResponseDTO responseDTO = goalManagementService.createGoal(requestDTO);

        assertNotNull(responseDTO);
        verify(employeeProfileRepository, times(1)).findById(1L);
        verify(goalManagementRepository, times(1)).save(goalManagement);
    }

    
    @Test
    void testCreateGoal_EmployeeNotFound() {
        GoalManagementRequestDTO requestDTO = new GoalManagementRequestDTO();
        requestDTO.setEmployeeId(999L); 

        when(employeeProfileRepository.findById(999L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(InvalidEmployeeIdException.class, () -> {
            goalManagementService.createGoal(requestDTO);
        });

        assertEquals("Employee not found", exception.getMessage());
        verify(employeeProfileRepository, times(1)).findById(999L);
    }
    
    @Test
    void testCreateGoal_EmployeeAlreadyAssignedSameGoal() {
        GoalManagementRequestDTO requestDTO = new GoalManagementRequestDTO();
        requestDTO.setEmployeeId(101L);
        requestDTO.setGoalDescription("Java Completion");

        EmployeeProfile mockEmployee = new EmployeeProfile();
        mockEmployee.setEmployeeId(101L);

        when(employeeProfileRepository.findById(requestDTO.getEmployeeId()))
                .thenReturn(Optional.of(mockEmployee));

        when(goalManagementRepository.existsByEmployeeId_EmployeeIdAndGoalDescription(
                requestDTO.getEmployeeId(), requestDTO.getGoalDescription()))
                .thenReturn(true); 

        Exception exception = assertThrows(GoalAlreadyAssignedException.class, () -> {
            goalManagementService.createGoal(requestDTO);
        });

        assertEquals("Employee already has the same goal: Java Completion", exception.getMessage());
        verify(goalManagementRepository, times(1)).existsByEmployeeId_EmployeeIdAndGoalDescription(requestDTO.getEmployeeId(), requestDTO.getGoalDescription());
    }

    @Test
    void testGetGoalsByEmployeeId_EmployeeNotFound() {
        Long employeeId = 100L; 

        when(employeeProfileRepository.existsById(employeeId)).thenReturn(false);

        Exception exception = assertThrows(InvalidEmployeeIdException.class, () -> {
            goalManagementService.getGoalsByEmployeeId(employeeId);
        });

        assertEquals("Employee not found with ID: 100", exception.getMessage());
        verify(employeeProfileRepository, times(1)).existsById(employeeId);
    }
    
    @Test
    void testGetGoalsByEmployeeId_GoalsFound() {
        Long employeeId = 1L;

    
        when(employeeProfileRepository.existsById(employeeId)).thenReturn(true);

        GoalManagement goal1 = new GoalManagement();
        GoalManagement goal2 = new GoalManagement();
        List<GoalManagement> goals = List.of(goal1, goal2);

        when(goalManagementRepository.findByEmployeeId_EmployeeId(employeeId)).thenReturn(goals);
        when(goalManagementMapper.toDTO(goal1)).thenReturn(new GoalManagementResponseDTO());
        when(goalManagementMapper.toDTO(goal2)).thenReturn(new GoalManagementResponseDTO());

       
        List<GoalManagementResponseDTO> responseDTOs = goalManagementService.getGoalsByEmployeeId(employeeId);

        
        assertFalse(responseDTOs.isEmpty());
        verify(employeeProfileRepository, times(1)).existsById(employeeId); 
        verify(goalManagementRepository, times(1)).findByEmployeeId_EmployeeId(employeeId); 
    }


    

    @Test
    void testUpdateGoalDeadline_GoalExists() {
        Long goalId = 1L;
        LocalDate newDeadline = LocalDate.now().plusDays(30);
        GoalManagement goal = new GoalManagement();
        
        when(goalManagementRepository.findById(goalId)).thenReturn(Optional.of(goal));
        when(goalManagementRepository.save(goal)).thenReturn(goal);
        when(goalManagementMapper.toDTO(goal)).thenReturn(new GoalManagementResponseDTO());

        GoalManagementResponseDTO responseDTO = goalManagementService.updateGoalDeadline(goalId, newDeadline);

        assertNotNull(responseDTO); 
        verify(goalManagementRepository, times(1)).findById(goalId); 
        verify(goalManagementRepository, times(1)).save(goal); 
    }

    @Test
    void testUpdateGoalDeadline_GoalNotFound() {
        Long goalId = 2L;
        LocalDate newDeadline = LocalDate.now().plusDays(30);

        when(goalManagementRepository.findById(goalId)).thenReturn(Optional.empty());

        Exception exception = assertThrows(GoalNotFoundException.class, () -> {
            goalManagementService.updateGoalDeadline(goalId, newDeadline);
        });

        assertEquals("Goal not found with id: 2", exception.getMessage());
        verify(goalManagementRepository, times(1)).findById(goalId); // Verify retrieval attempt
    }
    
    @Test
    void testDeleteGoalById_GoalExists() {
        Long goalId = 1L;

        when(goalManagementRepository.existsById(goalId)).thenReturn(true);

        goalManagementService.deleteGoalById(goalId);
        verify(goalManagementRepository, times(1)).existsById(goalId);
        verify(goalManagementRepository, times(1)).deleteById(goalId);
    }

    @Test
    void testDeleteGoalById_GoalNotFound() {
        Long goalId = 2L;

        when(goalManagementRepository.existsById(goalId)).thenReturn(false);

        Exception exception = assertThrows(GoalNotFoundException.class, () -> {
            goalManagementService.deleteGoalById(goalId);
        });

        assertEquals("Goal not found with id: 2", exception.getMessage());
        verify(goalManagementRepository, times(1)).existsById(goalId); 
        verify(goalManagementRepository, never()).deleteById(goalId); 
    }

    @Test
    void testGetAllGoals_GoalsFound() {
        List<GoalManagement> goals = List.of(new GoalManagement(), new GoalManagement());

        when(goalManagementRepository.findAll()).thenReturn(goals);
        when(goalManagementMapper.toDTO(any(GoalManagement.class))).thenReturn(new GoalManagementResponseDTO());

        List<GoalManagementResponseDTO> responseDTOs = goalManagementService.getAllGoals();

        assertFalse(responseDTOs.isEmpty()); 
        verify(goalManagementRepository, times(1)).findAll(); 
    }

    
    @Test
    void testMarkAsComplete_GoalExists() {
        Long goalId = 1L;
        GoalManagement goal = new GoalManagement();
        goal.setProgressStatus(ProgressStatus.COMPLETED);

        when(goalManagementRepository.findById(goalId)).thenReturn(Optional.of(goal));
        when(goalManagementRepository.save(goal)).thenReturn(goal);
        when(goalManagementMapper.toDTO(goal)).thenReturn(new GoalManagementResponseDTO());

        GoalManagementResponseDTO responseDTO = goalManagementService.markAsComplete(goalId);

        assertNotNull(responseDTO);
        assertEquals(ProgressStatus.UNDER_REVIEW, goal.getProgressStatus()); 
        verify(goalManagementRepository, times(1)).findById(goalId);
        verify(goalManagementRepository, times(1)).save(goal);
    }

    @Test
    void testMarkAsComplete_GoalNotFound() {
        Long goalId = 2L;

        when(goalManagementRepository.findById(goalId)).thenReturn(Optional.empty());

        Exception exception = assertThrows(GoalNotFoundException.class, () -> {
            goalManagementService.markAsComplete(goalId);
        });

        assertEquals("Goal not found with id: 2", exception.getMessage());
        verify(goalManagementRepository, times(1)).findById(goalId); 
    }

    @Test
    void testFindGoalById_GoalExists() {
        Long goalId = 1L;
        GoalManagement goal = new GoalManagement();

        when(goalManagementRepository.findById(goalId)).thenReturn(Optional.of(goal));

        Optional<GoalManagement> foundGoal = goalManagementService.findGoalById(goalId);

        assertTrue(foundGoal.isPresent()); 
        assertEquals(goal, foundGoal.get()); 
        verify(goalManagementRepository, times(1)).findById(goalId);
    }

    @Test
    void testFindGoalById_GoalNotFound() {
        Long goalId = 2L;

        when(goalManagementRepository.findById(goalId)).thenReturn(Optional.empty());

        Exception exception = assertThrows(GoalNotFoundException.class, () -> {
            goalManagementService.findGoalById(goalId);
        });

        assertEquals("Goal not found with id: 2", exception.getMessage());
        verify(goalManagementRepository, times(1)).findById(goalId);
    }
    
    @Test
    void testGetAllGoalsUnderReview_GoalsFound() {

        GoalManagement goal1 = new GoalManagement();
        goal1.setProgressStatus(ProgressStatus.UNDER_REVIEW);

        GoalManagement goal2 = new GoalManagement();
        goal2.setProgressStatus(ProgressStatus.COMPLETED); 

        List<GoalManagement> goals = List.of(goal1, goal2);

      
        when(goalManagementRepository.findAll()).thenReturn(goals);
        when(goalManagementMapper.toDTO(goal1)).thenReturn(new GoalManagementResponseDTO());

      
        List<GoalManagementResponseDTO> responseDTOs = goalManagementService.getAllGoalsUnderReview();

        assertFalse(responseDTOs.isEmpty()); 
        assertEquals(1, responseDTOs.size()); 
        verify(goalManagementRepository, times(1)).findAll(); 
    }

   

    @Test
    void testApproveGoal_Success() {
        Long goalId = 1L;
        GoalManagement goal = new GoalManagement();
        goal.setGoalId(goalId);
        goal.setProgressStatus(ProgressStatus.UNDER_REVIEW);

        when(goalManagementRepository.findById(goalId)).thenReturn(Optional.of(goal));
        when(goalManagementMapper.toDTO(goal)).thenReturn(new GoalManagementResponseDTO());

        GoalManagementResponseDTO response = goalManagementService.approveOrRejectGoal(goalId, true);

        assertNotNull(response);
        assertEquals(ProgressStatus.COMPLETED, goal.getProgressStatus());
        verify(goalManagementRepository).save(goal);
    }

    @Test
    void testRejectGoal_Success() {
        Long goalId = 1L;
        GoalManagement goal = new GoalManagement();
        goal.setGoalId(goalId);
        goal.setProgressStatus(ProgressStatus.UNDER_REVIEW);

        when(goalManagementRepository.findById(goalId)).thenReturn(Optional.of(goal));
        when(goalManagementMapper.toDTO(goal)).thenReturn(new GoalManagementResponseDTO());

        GoalManagementResponseDTO response = goalManagementService.approveOrRejectGoal(goalId, false);

        assertNotNull(response);
        assertEquals(ProgressStatus.IN_PROGRESS, goal.getProgressStatus());
        verify(goalManagementRepository).save(goal);
    }

    @Test
    void testGoalNotFound() {
        Long goalId = 1L;
        when(goalManagementRepository.findById(goalId)).thenReturn(Optional.empty());

        assertThrows(GoalNotFoundException.class, () -> goalManagementService.approveOrRejectGoal(goalId, true));
    }

    
    
    @Test
    void testGetGoalsByEmployeeAndDateRange_GoalsFound() {
        long employeeId = 101L;
        LocalDate startDate = LocalDate.of(2024, 5, 1);
        LocalDate endDate = LocalDate.of(2024, 5, 31);

        GoalManagement goal1 = new GoalManagement();
        goal1.setEmployeeId(new EmployeeProfile());
        goal1.setTargetDate(LocalDate.of(2024, 5, 10));
        goal1.setGoalDescription("Complete Java Certification");

        GoalManagementResponseDTO responseDTO1 = new GoalManagementResponseDTO();
        responseDTO1.setGoalDescription("Complete Java Certification");
        responseDTO1.setDate(LocalDate.of(2024, 5, 10));
        
        List<GoalManagement> goals = List.of(goal1);

        
        when(goalManagementRepository.findByEmployeeIdEmployeeIdAndTargetDateBetween(employeeId, startDate, endDate))
                .thenReturn(goals);

        when(goalManagementMapper.toDTO(goal1)).thenReturn(responseDTO1);

        
        List<GoalManagementResponseDTO> result = goalManagementService.getGoalsByEmployeeAndDateRange(employeeId, startDate, endDate);

        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals("Complete Java Certification", result.get(0).getGoalDescription());

        verify(goalManagementRepository, times(1)).findByEmployeeIdEmployeeIdAndTargetDateBetween(employeeId, startDate, endDate);
    }

    @Test
    void testGetGoalsByEmployeeAndDateRange_NoGoalsFound() {
        long employeeId = 102L;
        LocalDate startDate = LocalDate.of(2024, 5, 1);
        LocalDate endDate = LocalDate.of(2024, 5, 31);

        when(goalManagementRepository.findByEmployeeIdEmployeeIdAndTargetDateBetween(employeeId, startDate, endDate))
                .thenReturn(Collections.emptyList()); 

        Exception exception = assertThrows(GoalNotFoundException.class, () -> {
            goalManagementService.getGoalsByEmployeeAndDateRange(employeeId, startDate, endDate);
        });

        assertEquals("Goals not assigned to employee: 102", exception.getMessage());

        verify(goalManagementRepository, times(1)).findByEmployeeIdEmployeeIdAndTargetDateBetween(employeeId, startDate, endDate);
    }

    
    
}
